<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:82:"/var/www/html/shengteng-group/public/../application/index/view/index/activity.html";i:1524012892;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>开业大酬宾！-盛腾家装工厂店</title>
    <link href="https://cdn.bootcss.com/bootstrap/4.0.0-alpha/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/static/index/static/css/activity_index.css">
    

</head>
<body>

    <img src="/static/index/static/images/activity/activity_01.jpg">
    <img class="lazy" data-original="/static/index/static/images/activity/activity_02.jpg">


    <div class="user-from user-from1">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <h1 class="align-center">预约报名</h1>
                    <p class="align-center">百平米全包豪装仅需 129800 元！ 名额仅限 68 户！</p>
                    <p class="align-center">请留下你的联系方式，我们会在第一时间为你报名！</p>
                </div>
            </div>

            <div class="row">
                <form role="form" class="form-inline col-sm-12" onsubmit="return order1();" id="form1">
                    <div class="form-group col-sm-6 align-right">
                        <label>称呼：</label>
                        <input type="input" name="name" class="form-control" required>
                    </div>

                    <div class="form-group col-sm-6 align-left">
                        <label>电话：</label>
                        <input type="input" name="tel" class="form-control" required>
                    </div>
                    <br><br><br>
                    <div class="form-group col-sm-6 align-right">
                        <label>地址：</label>
                        <input type="input" name="address" class="form-control" required>
                    </div>

                    <div class="form-group col-sm-6 align-left">
                        <label>面积：</label>
                        <input type="input" name="area" class="form-control" required>
                    </div>

                    <input type="hidden" name="from" value="PC">
                    <input type="hidden" name="remark" value="宿州(5.1)活动落地页">
                    <br><br><br>
                    <div class="form-group col-sm-12 align-left">
                        <div align="center"><button class="btn" type="submit"></button></div>
                    </div>
                    
                </form>
            </div>
        </div>  
    </div>


    <img class="lazy" data-original="/static/index/static/images/activity/activity_04.jpg">
    <img class="lazy" data-original="/static/index/static/images/activity/activity_05.jpg" onClick="scrollEnd();">
    <img class="lazy" data-original="/static/index/static/images/activity/activity_06.jpg">
    <img class="lazy" data-original="/static/index/static/images/activity/activity_07.jpg">
    <img class="lazy" data-original="/static/index/static/images/activity/activity_08.jpg">
    <img class="lazy" data-original="/static/index/static/images/activity/activity_09.jpg">

<div class="user-from user-from2">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <h1 class="align-center">预约报名</h1>
                    <p class="align-center">百平米全包豪装仅需 129800 元！ 名额仅限 68 户！</p>
                    <p class="align-center">请留下你的联系方式，我们会在第一时间为你报名！</p>
                </div>
            </div>

            <div class="row">
                <form role="form" class="form-inline col-sm-12" onsubmit="return order1();" id="form1">
                    <div class="form-group col-sm-6 align-right">
                        <label>称呼：</label>
                        <input type="input" name="name" class="form-control" required>
                    </div>

                    <div class="form-group col-sm-6 align-left">
                        <label>电话：</label>
                        <input type="input" name="tel" class="form-control" required>
                    </div>
                    <br><br><br>
                    <div class="form-group col-sm-6 align-right">
                        <label>地址：</label>
                        <input type="input" name="address" class="form-control" required>
                    </div>

                    <div class="form-group col-sm-6 align-left">
                        <label>面积：</label>
                        <input type="input" name="area" class="form-control" required>
                    </div>

                    <input type="hidden" name="from" value="PC">
                    <input type="hidden" name="remark" value="宿州(5.1)活动落地页">
                    <br><br><br>
                    <div class="form-group col-sm-12 align-left">
                        <div align="center"><button class="btn" type="submit"></button></div>
                    </div>
                    
                </form>
            </div>
        </div>  
    </div>

<script src="https://cdn.bootcss.com/jquery/3.3.1/jquery.min.js"></script>

<script src="https://cdn.bootcss.com/jquery_lazyload/1.9.7/jquery.lazyload.min.js"></script>

<script class="lazy" src="/static/index/static/js/activity_index.js"></script>
<script>
    // 滚动到底部

function scrollEnd(){
    var h = $(document).height()-$(window).height();
    $('html,body').animate({scrollTop: h}, 800);
}
</script>

</body>
</html>