<?php if (!defined('THINK_PATH')) exit(); /*a:6:{s:79:"/var/www/html/shengteng-group/public/../application/admin/view/index/index.html";i:1517642688;s:66:"/var/www/html/shengteng-group/application/admin/view/tpl/base.html";i:1509871811;s:66:"/var/www/html/shengteng-group/application/admin/view/tpl/head.html";i:1515575344;s:68:"/var/www/html/shengteng-group/application/admin/view/tpl/header.html";i:1515635950;s:66:"/var/www/html/shengteng-group/application/admin/view/tpl/menu.html";i:1517038467;s:68:"/var/www/html/shengteng-group/application/admin/view/tpl/footer.html";i:1517038417;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <!--头部区 开始-->
    <meta charset="utf-8">
<meta name="renderer" content="webkit|ie-comp|ie-stand">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no" />
<meta http-equiv="Cache-Control" content="no-siteapp" />

<LINK rel="Bookmark" href="/static/index/static/images/comm/favicon.ico" >
<LINK rel="Shortcut Icon" href="/static/index/static/images/comm/favicon.ico" />
<link href="/static/index/static/images/comm/favicon.ico" rel="icon" type="image/x-icon" />
<!--[if lt IE 9]>
<script type="text/javascript" src="/static/admin/lib/html5.js"></script>
<script type="text/javascript" src="/static/admin/lib/respond.min.js"></script>
<![endif]-->
<link rel="stylesheet" type="text/css" href="/static/admin/static/h-ui/css/H-ui.min.css" />
<link rel="stylesheet" type="text/css" href="/static/admin/static/h-ui.admin/css/H-ui.admin.css" />
<link rel="stylesheet" type="text/css" href="/static/admin/lib/Hui-iconfont/1.0.8/iconfont.css" />

<link rel="stylesheet" type="text/css" href="/static/admin/static/h-ui.admin/skin/default/skin.css" id="skin" />
<link rel="stylesheet" type="text/css" href="/static/admin/static/h-ui.admin/css/style.css" />

<!--自定义样式-->
<link rel="stylesheet" type="text/css" href="/static/admin/static/h-ui.admin/css/style.css" />




<!--[if IE 6]>
<script type="text/javascript" src="http://lib.h-ui.net/DD_belatedPNG_0.0.8a-min.js" ></script>
<script>DD_belatedPNG.fix('*');</script><![endif]-->


    <!--头部区 结束-->
    <title>后台管理</title>
</head>
<body>
<!--header 开始-->
<header class="navbar-wrapper">
    <div class="navbar navbar-fixed-top">
        <div class="container-fluid cl"> <a class="logo navbar-logo f-l mr-10 hidden-xs" href="<?php echo url('Index/index'); ?>">盛腾家装后台管理</a> <a class="logo navbar-logo-m f-l mr-10 visible-xs" href="<?php echo url('Index/index'); ?>">盛腾家装后台管理</a> <span class="logo navbar-slogan f-l mr-10 hidden-xs">v1.0</span> <a aria-hidden="false" class="nav-toggle Hui-iconfont visible-xs" href="javascript:;">&#xe667;</a>
            <nav class="nav navbar-nav">
                <ul class="cl">
                    <li class="dropDown dropDown_hover"><a href="javascript:;" class="dropDown_A"><i class="Hui-iconfont">&#xe600;</i> 新增 <i class="Hui-iconfont">&#xe6d5;</i></a>
                        <ul class="dropDown-menu menu radius box-shadow">
                            <li><a href="<?php echo url('NewsManager/article_add_page'); ?>?action=add_news" ><i class="Hui-iconfont">&#xe616;</i> 新闻</a></li>
                            <li><a href="<?php echo url('WebsiteSetting/add_decoration_case'); ?>" onclick="picture_add('添加资讯','picture-add.html')"><i class="Hui-iconfont">&#xe613;</i> 案例</a></li>
                            <li><a href="<?php echo url('WebsiteSetting/add_designer'); ?>" onclick="product_add('添加资讯','product-add.html')"><i class="Hui-iconfont">&#xe620;</i> 设计师</a></li>
                            <li><a href="javascript:;" onclick="admin_role_add('添加角色','<?php echo url('AdminManager/admin_role_add'); ?>','800')"><i class="Hui-iconfont">&#xe60d;</i> 管理员</a></li>
                        </ul>
                    </li>
                </ul>
            </nav>
            <nav id="Hui-userbar" class="nav navbar-nav navbar-userbar hidden-xs">
                <ul class="cl">
                    <li class="dropDown dropDown_hover"> <a href="#" class="dropDown_A"><?php echo \think\Session::get('curUser'); ?> <i class="Hui-iconfont">&#xe6d5;</i></a>
                        <ul class="dropDown-menu menu radius box-shadow">
                            <li><a href="javascript:;" onClick="myselfinfo()">个人信息</a></li>
                            <li><a href="<?php echo url('User/logout'); ?>">切换账户</a></li>
                            <li><a href="<?php echo url('User/logout'); ?>">退出</a></li>
                        </ul>
                    </li>
                    <li id="Hui-msg"> <a href="#" title="消息"><span class="badge badge-danger">1</span><i class="Hui-iconfont" style="font-size:18px">&#xe68a;</i></a> </li>
                    <li id="Hui-skin" class="dropDown right dropDown_hover"> <a href="javascript:;" class="dropDown_A" title="换肤"><i class="Hui-iconfont" style="font-size:18px">&#xe62a;</i></a>
                        <ul class="dropDown-menu menu radius box-shadow">
                            <li><a href="javascript:;" data-val="default" title="默认（黑色）">默认（黑色）</a></li>
                            <li><a href="javascript:;" data-val="blue" title="蓝色">蓝色</a></li>
                            <li><a href="javascript:;" data-val="green" title="绿色">绿色</a></li>
                            <li><a href="javascript:;" data-val="red" title="红色">红色</a></li>
                            <li><a href="javascript:;" data-val="yellow" title="黄色">黄色</a></li>
                            <li><a href="javascript:;" data-val="orange" title="橙色">橙色</a></li>
                        </ul>
                    </li>
                </ul>
            </nav>
        </div>
    </div>
</header>
<!--header 结束-->

<!--左侧菜单 开始-->
<!--_menu 作为公共模版分离出去-->
<aside class="Hui-aside">

    <div class="menu_dropdown bk_2">
        <dl id="menu-article">
            <dt><i class="Hui-iconfont">&#xe616;</i> 资讯管理<i class="Hui-iconfont menu_dropdown-arrow">&#xe6d5;</i></dt>
            <dd>
                <ul>
                    <li><a href="<?php echo url('NewsManager/menu_manager_news'); ?>" title="新闻动态">新闻动态</a></li>

                </ul>
            </dd>
        </dl>
        <!--数据中心 开始-->
        <dl id="data-center">
            <dt><i class="Hui-iconfont">&#xe620;</i> 数据中心<i class="Hui-iconfont menu_dropdown-arrow">&#xe6d5;</i></dt>
            <dd>
                <ul>
                    <li><a href="<?php echo url('DataCenter/order_manager'); ?>" title="预约装修">预约装修</a></li>

                </ul>
            </dd>
        </dl>
        <!--数据中心 结束-->
        <dl id="menu-website">
            <dt><i class="Hui-iconfont">&#xe613;</i> 网站资源管理<i class="Hui-iconfont menu_dropdown-arrow">&#xe6d5;</i></dt>
            <dd>
                <ul>
                    <li><a href="<?php echo url('WebsiteSetting/website_seo'); ?>" title="基本信息">SEO信息优化</a></li>
                    <li><a href="<?php echo url('WebsiteSetting/all_shops_list'); ?>" title="盛腾子公司">全国门店列表</a></li>
                    <li><a href="<?php echo url('WebsiteSetting/decoration_case_list'); ?>" title="装修案例">装修案例列表</a></li>
                    <li><a href="<?php echo url('WebsiteSetting/designer_list'); ?>" title="装修案例">设计师列表</a></li>
                </ul>
            </dd>
        </dl>
        <!--网站banner 开始-->

        <!--网站banner 结束-->

        <dl id="menu-comments">
            <dt><i class="Hui-iconfont">&#xe622;</i> 评论管理<i class="Hui-iconfont menu_dropdown-arrow">&#xe6d5;</i></dt>
            <dd>
                <ul>
                    <li><a href="<?php echo url('Comment/index'); ?>" title="评论列表">评论列表</a></li>
                    <li><a href="feedback-list.html" title="意见反馈">意见反馈</a></li>
                </ul>
            </dd>
        </dl>
        <dl id="menu-member">
            <dt><i class="Hui-iconfont">&#xe60d;</i> 会员管理<i class="Hui-iconfont menu_dropdown-arrow">&#xe6d5;</i></dt>
            <dd>
                <ul>
                    <li><a href="member-list.html" title="会员列表">会员列表</a></li>
                    <li><a href="member-del.html" title="删除的会员">删除的会员</a></li>
                    <li><a href="member-level.html" title="等级管理">等级管理</a></li>
                    <li><a href="member-scoreoperation.html" title="积分管理">积分管理</a></li>
                    <li><a href="member-record-browse.html" title="浏览记录">浏览记录</a></li>
                    <li><a href="member-record-download.html" title="下载记录">下载记录</a></li>
                    <li><a href="member-record-share.html" title="分享记录">分享记录</a></li>
                </ul>
            </dd>
        </dl>
        <dl id="menu-admin">
            <dt><i class="Hui-iconfont">&#xe62d;</i> 管理员管理<i class="Hui-iconfont menu_dropdown-arrow">&#xe6d5;</i></dt>
            <dd>
                <ul>
                    <li><a href="<?php echo url('AdminManager/admin_role'); ?>" title="角色管理">角色管理</a></li>
                    <li><a href="<?php echo url('AdminManager/admin_list'); ?>" title="管理员列表">管理员列表</a></li>
                </ul>
            </dd>
        </dl>
        <dl id="menu-tongji">
            <dt><i class="Hui-iconfont">&#xe61a;</i> 系统统计<i class="Hui-iconfont menu_dropdown-arrow">&#xe6d5;</i></dt>
            <dd>
                <ul>
                    <li><a href="charts-1.html" title="折线图">折线图</a></li>
                    <li><a href="charts-2.html" title="时间轴折线图">时间轴折线图</a></li>
                    <li><a href="charts-3.html" title="区域图">区域图</a></li>
                    <li><a href="charts-4.html" title="柱状图">柱状图</a></li>
                    <li><a href="charts-5.html" title="饼状图">饼状图</a></li>
                    <li><a href="charts-6.html" title="3D柱状图">3D柱状图</a></li>
                    <li><a href="charts-7.html" title="3D饼状图">3D饼状图</a></li>
                </ul>
            </dd>
        </dl>
        <dl id="menu-system">
            <dt><i class="Hui-iconfont">&#xe62e;</i> 系统管理<i class="Hui-iconfont menu_dropdown-arrow">&#xe6d5;</i></dt>
            <dd>
                <ul>
                    <li><a href="system-base.html" title="系统设置">系统设置</a></li>
                    <li><a href="system-category.html" title="栏目管理">栏目管理</a></li>
                    <li><a href="system-data.html" title="数据字典">数据字典</a></li>
                    <li><a href="system-shielding.html" title="屏蔽词">屏蔽词</a></li>
                    <li><a href="system-log.html" title="系统日志">系统日志</a></li>
                </ul>
            </dd>
        </dl>
    </div>
</aside>
<div class="dislpayArrow hidden-xs"><a class="pngfix" href="javascript:void(0);" onClick="displaynavbar(this)"></a></div>
<!--/_menu 作为公共模版分离出去-->
<!--左侧菜单 结束-->

<!--内容区 开始-->

<style>
    .card{
        height: 130px;
        margin: 5px 10px;
        color: white;
        border-radius: 4px;
        padding: 3vw 1vw;
        font-size: 1.2rem;
    }
    .quick_enter .title,.quick_enter .total{
        float: right;
    }
    .quick_enter .total{
        font-size: 1.6rem;
    }

    .clearfix{
        clear: both;
    }
</style>
<section class="Hui-article-box">
    <nav class="breadcrumb"><i class="Hui-iconfont"></i> <a href="<?php echo url('Index/index'); ?>" class="maincolor">首页</a>
        <span class="c-999 en">&gt;</span>
        <span class="c-666">我的桌面</span>
        <a class="btn btn-success radius r" style="line-height:1.6em;margin-top:3px" href="javascript:location.replace(location.href);" title="刷新" ><i class="Hui-iconfont">&#xe68f;</i></a></nav>
    <div class="Hui-article">
        <article class="cl pd-20">
            <p class="f-20 text-success">欢迎登陆盛腾
                <span class="f-14">v1.0</span>
                后台管理系统！</p>
            <p>登录次数：18 </p>
            <p>上次登录IP：<?php echo $ip; ?> &nbsp; 上次登录时间：<?php echo date('Y-m-d H:i:s',$curTime); ?></p>

            <h3 style="border-bottom: 1px solid #cccccc">快捷入口</h3>
            <div class="quick_enter">
                <a href="<?php echo url('NewsManager/menu_manager_news'); ?>" title="新闻动态">
                    <div class="col-md-2 card" style="background-color: #10AEF7">
                        <img src="/static/index/static/images/comm/news.png" alt="新闻管理">
                        <span class="title">新闻管理</span>
                        <div class="clearfix total"><?php echo $news_count; ?></div>
                    </div></a>
                <a href="<?php echo url('WebsiteSetting/decoration_case_list'); ?>"><div class="col-md-2 card" style="background-color: #7CC422">
                    <img src="/static/index/static/images/comm/house.png" alt="新闻管理" >
                    <span class="title">案例管理</span>
                    <div class="clearfix total"><?php echo $decoration_case_count; ?></div>

                </div></a>
                <a href="<?php echo url('DataCenter/order_manager'); ?>" title="预约装修"><div class="col-md-2 card" style="background-color: #FFA060">
                    <img src="/static/index/static/images/comm/order.png" alt="报名管理" >
                    <span class="title">报名管理</span>
                    <div class="clearfix total"><?php echo $order_count; ?></div>
                    </div></a>
                <a href="<?php echo url('WebsiteSetting/designer_list'); ?>"><div class="col-md-2 card" style="background-color: #FEC107">
                    <img src="/static/index/static/images/comm/designer.png" alt="设计师" >
                    <span class="title">设计师</span>
                    <div class="clearfix total"><?php echo $designer_count; ?></div>
                    </div></a>
                <a href="javascript:void(0)" onClick="modify_banner()"><div class="col-md-2 card" style="background-color: #46D1E4">
                    <img src="/static/index/static/images/comm/pic.png" alt="banner" >
                    <span class="title">banner</span>
                    <div class="clearfix total">4</div>
                    </div></a>
            </div>


            <table class="table table-border table-bordered table-bg">
                <thead>
                <tr>
                    <th colspan="7" scope="col">信息统计</th>
                </tr>
                <tr class="text-c">
                    <th>统计</th>
                    <th>资讯库</th>
                    <th>图片库</th>
                    <th>产品库</th>
                    <th>用户</th>
                    <th>管理员</th>
                </tr>
                </thead>
                <tbody>
                <tr class="text-c">
                    <td>总数</td>
                    <td>92</td>
                    <td>9</td>
                    <td>0</td>
                    <td>8</td>
                    <td>20</td>
                </tr>
                <tr class="text-c">
                    <td>今日</td>
                    <td>0</td>
                    <td>0</td>
                    <td>0</td>
                    <td>0</td>
                    <td>0</td>
                </tr>
                <tr class="text-c">
                    <td>昨日</td>
                    <td>0</td>
                    <td>0</td>
                    <td>0</td>
                    <td>0</td>
                    <td>0</td>
                </tr>
                <tr class="text-c">
                    <td>本周</td>
                    <td>2</td>
                    <td>0</td>
                    <td>0</td>
                    <td>0</td>
                    <td>0</td>
                </tr>
                <tr class="text-c">
                    <td>本月</td>
                    <td>2</td>
                    <td>0</td>
                    <td>0</td>
                    <td>0</td>
                    <td>0</td>
                </tr>
                </tbody>
            </table>
            <table class="table table-border table-bordered table-bg mt-20">
                <thead>
                <tr>
                    <th colspan="2" scope="col">服务器信息</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <th width="30%">服务器计算机名</th>
                    <td><span id="lbServerName">http://127.0.0.1/</span></td>
                </tr>
                <tr>
                    <td>服务器IP地址</td>
                    <td>192.168.1.1</td>
                </tr>
                <tr>
                    <td>服务器域名</td>
                    <td><?php echo $serverMsg['SERVER_NAME']; ?></td>
                </tr>
                <tr>
                    <td>服务器端口 </td>
                    <td><?php echo $serverMsg['SERVER_PORT']; ?></td>
                </tr>
                <tr>
                    <td>服务器环境 </td>
                    <td><?php echo $serverMsg['SERVER_SOFTWARE']; ?></td>
                </tr>
                <tr>
                    <td>服务器管理员</td>
                    <td>{SERVER_ADMIN}</td>
                </tr>
                <tr>
                    <td>服务器操作系统 </td>
                    <td>Microsoft Windows NT 5.2.3790 Service Pack 2</td>
                </tr>
                <tr>
                    <td>系统所在文件夹 </td>
                    <td><?php echo $serverMsg['DOCUMENT_ROOT']; ?></td>
                </tr>
                <tr>
                    <td>服务器脚本超时时间 </td>
                    <td>30000秒</td>
                </tr>
                <tr>
                    <td>服务器的语言种类 </td>
                    <td>Chinese (People's Republic of China)</td>
                </tr>
                <tr>
                    <td>.NET Framework 版本 </td>
                    <td>2.050727.3655</td>
                </tr>
                <tr>
                    <td>服务器当前时间 </td>
                    <td><?php echo date('Y-m-d H:i:s',$curTime); ?></td>
                </tr>
                <tr>
                    <td>服务器IE版本 </td>
                    <td>6.0000</td>
                </tr>
                <tr>
                    <td>服务器上次启动到现在已运行 </td>
                    <td>7210分钟</td>
                </tr>
                <tr>
                    <td>逻辑驱动器 </td>
                    <td>C:\D:\</td>
                </tr>
                <tr>
                    <td>CPU 总数 </td>
                    <td>4</td>
                </tr>
                <tr>
                    <td>CPU 类型 </td>
                    <td>x86 Family 6 Model 42 Stepping 1, GenuineIntel</td>
                </tr>
                <tr>
                    <td>虚拟内存 </td>
                    <td>52480M</td>
                </tr>
                <tr>
                    <td>当前程序占用内存 </td>
                    <td>3.29M</td>
                </tr>
                <tr>
                    <td>Asp.net所占内存 </td>
                    <td>51.46M</td>
                </tr>
                <tr>
                    <td>当前Session数量 </td>
                    <td>8</td>
                </tr>
                <tr>
                    <td>当前SessionID </td>
                    <td>gznhpwmp34004345jz2q3l45</td>
                </tr>
                <tr>
                    <td>当前系统用户名 </td>
                    <td>NETWORK SERVICE</td>
                </tr>
                </tbody>
            </table>
        </article>
        <footer class="footer">
            <p>技术支持：企划部 王恒 电话：17601322524</p>
        </footer>
    </div>
</section>
<!--修改banner 弹出层-->
<div id="modify_banner" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <form action="<?php echo url('WebsiteSetting/modify_banner'); ?>" enctype="multipart/form-data" method="post">
        <div class="modal-dialog">
            <?php if(is_array($banners_list) || $banners_list instanceof \think\Collection || $banners_list instanceof \think\Paginator): $i = 0; $__LIST__ = $banners_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title">修改banner图片</h3>
                    <a class="close" data-dismiss="modal" aria-hidden="true" href="javascript:void();">×</a>
                </div>
                <div class="modal-body">
                    <table class="table table-border table-bordered">
                        <tr>
                            <th><img src="/uploads/<?php echo $vo['banner1']; ?>" alt="banner1" class="img-responsive" style="max-height: 110px; max-width: 600px"></th>
                            <th><input type="file" name="banner1" accept="image/*"></th>
                        </tr>
                        <tr>
                            <th><img src="/uploads/<?php echo $vo['banner2']; ?>" alt="banner2" class="img-responsive" style="max-height: 110px; max-width: 600px"></th>
                            <th><input type="file" name="banner2" accept="image/*"></th>
                        </tr>
                        <tr>
                            <th><img src="/uploads/<?php echo $vo['banner3']; ?>" alt="banner3" class="img-responsive" style="max-height: 110px; max-width: 600px"></th>
                            <th><input type="file" name="banner3" accept="image/*"></th>
                        </tr>
                        <tr>
                            <th><img src="/uploads/<?php echo $vo['banner4']; ?>" alt="banner4" class="img-responsive" style="max-height: 110px; max-width: 600px"></th>
                            <th><input type="file" name="banner4" accept="image/*"></th>
                        </tr>
                    </table>
                </div>
                <div class="modal-footer" style="padding: 0">
                    <button class="btn btn-danger submit" type="submit" name="submit" style="width: 100%; height: 100%; padding: 13px"><strong>确定修改</strong></button>
                </div>
            </div>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </div>
    </form>
</div>


<!--内容区 结束-->

<!--footer 区 开始-->

<!--_footer 作为公共模版分离出去-->
<script type="text/javascript" src="/static/admin/lib/jquery/1.9.1/jquery.min.js"></script>
<script type="text/javascript" src="/static/admin/lib/layer/2.4/layer.js"></script>

<script type="text/javascript" src="/static/admin/lib/jquery.validation/1.14.0/jquery.validate.js"></script>
<script type="text/javascript" src="/static/admin/lib/jquery.validation/1.14.0/validate-methods.js"></script>
<script type="text/javascript" src="/static/admin/lib/jquery.validation/1.14.0/messages_zh.js"></script>
<script type="text/javascript" src="/static/admin/static/h-ui/js/H-ui.js"></script>
<script type="text/javascript" src="/static/admin/static/h-ui.admin/js/H-ui.admin.page.js"></script>
<!--/_footer /作为公共模版分离出去-->
<script>
    /*管理员-角色-添加*/
    function admin_role_add(title, url, w, h) {
        layer_show(title, url, w, h);
    }


</script>


<!--footer 区 结束-->

<!--自定义JS 开始-->

<script>
    //    修改banner
    function modify_banner(){
        $("#modify_banner").modal("show")
    }

    $(".submit").click(function () {
        $(".submit").hide();
    });
</script>

<!--自定义JS 结束-->
</body>
</html>