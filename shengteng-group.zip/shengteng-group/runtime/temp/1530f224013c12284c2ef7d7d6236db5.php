<?php if (!defined('THINK_PATH')) exit(); /*a:5:{s:93:"/var/www/html/shengteng-group/public/../application/index/view/decoration_strategy/index.html";i:1519782086;s:66:"/var/www/html/shengteng-group/application/index/view/tpl/base.html";i:1516261299;s:66:"/var/www/html/shengteng-group/application/index/view/tpl/head.html";i:1519789057;s:68:"/var/www/html/shengteng-group/application/index/view/tpl/header.html";i:1516330618;s:68:"/var/www/html/shengteng-group/application/index/view/tpl/footer.html";i:1522052971;}*/ ?>
<!DOCTYPE html>
<html lang="zh">

<!--公共模板 head 开始-->
    <head>
    <meta charset="utf-8">
    <!--响应式等比例缩放-->
    <meta name="viewport" content="initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <link href="/static/index/static/images/comm/favicon.ico" rel="icon" type="image/x-icon" />
    <meta name="keywords" content="盛腾家装科技集团官网|盛腾集团官网|盛腾集团|盛腾|盛腾家装科技|盛腾家装怎么样|装修效果图" />
    <meta name="description" content="盛腾家装科技集团是一家大全包装修装饰公司！公司的使命是让家装更透明，给百姓更省钱。公司愿景是打造中国最大的“互联网+实体店”家装平台。" />

    <!--动画-->
    <link href="https://cdn.bootcss.com/animate.css/3.5.2/animate.min.css" rel="stylesheet">
    <!--banner 插件 css-->
    <link rel="stylesheet" href="/static/index/lib/css/slide_banner.css">
    <!--bootstrap-->
    <link rel="stylesheet" href="http://cdn.static.runoob.com/libs/bootstrap/3.3.7/css/bootstrap.min.css">
    <!--自定义css-->
    <link rel="stylesheet" href="/static/index/static/css/comm.css">


<!--公共模板 head 结束-->

<!--引入业务相关css 开始-->

<link rel="stylesheet" href="/static/index/static/css/decoration_strategy.css">

<!--引入业务相关css 结束-->

<!--自定义当前页面title-->
<title>装修攻略-盛腾家装科技集团</title>
</head>
<body>

<!--公共模块 header 开始-->
    <header>
    <nav class="navbar navbar-inverse nav_bg hidden-xs" role="navigation">

        <div class="container-fluid">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse"
                            data-target="#example-navbar-collapse">
                        <span class="sr-only">切换导航</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand hidden-sm hidden-lg hidden-md" href="<?php echo url('index/index'); ?>">盛腾家装工厂店</a>
                </div>
                <div class="collapse navbar-collapse" id="example-navbar-collapse">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="<?php echo url('index/index'); ?>">HOME首页</a></li>
                        <li><a href="<?php echo url('SelectedCase/index'); ?>">案例精选</a></li>
                        <li><a href="<?php echo url('TeamServices/index'); ?>">团队服务</a></li>
                        <li><a href="<?php echo url('DecorationStrategy/index'); ?>">家装攻略</a></li>
                        <li><a href="<?php echo url('QualityEngineering/index'); ?>">品质工程</a></li>
                        <li><a href="<?php echo url('AllShops/index'); ?>">各大工厂店</a></li>
                        <li><a href="<?php echo url('Comments/index'); ?>">业主评价</a></li>
                        <li><a href="<?php echo url('AboutUs/about_us'); ?>">关于盛腾</a></li>
                        <li><a href="<?php echo url('AboutUs/contact_us'); ?>">联系我们</a></li>
                        <!--<li class="dropdown">-->
                            <!--<a href="#" class="dropdown-toggle" data-toggle="dropdown">-->
                                <!--关于我们 <b class="caret"></b>-->
                            <!--</a>-->
                            <!--<ul class="dropdown-menu">-->
                                <!--<li><a href="<?php echo url('AboutUs/about_us'); ?>">关于盛腾</a></li>-->
                                <!--<li class="divider"></li>-->
                                <!--<li><a href="<?php echo url('AboutUs/contact_us'); ?>">联系我们</a></li>-->
                            <!--</ul>-->
                        <!--</li>-->
                    </ul>
                </div>
            </div>
        </div>
    </nav>
</header>

<!--公共模块 header 结束-->

<!--公共模块 section 开始-->
    
<div class="top-full-img">
    <img src="/static/index/static/images/decoration_strategy/index/top-banner.png" alt="">
</div>

<div class="container">
    <!--新闻分类 TAB 切换-->
    <div class="row">
        <div class="col-sm-12">
            <ul class="category_box clearfix">
                <li class="active"><a href="javascript:void(0);">家装指南</a></li>
                <li><a href="javascript:void(0);">家具配饰</a></li>
                <li><a href="javascript:void(0);">家具风水</a></li>
                <li><a href="javascript:void(0);">家装设计</a></li>
            </ul>
        </div>
    </div>

    <div class="row">
        <!--左侧 开始-->
        <div class="category_tab_content selected_case">
            <div class="col-sm-8 category_tab_content_item active">
                <div class="news_box">
                    <?php if(is_array($list1) || $list1 instanceof \think\Collection || $list1 instanceof \think\Paginator): $i = 0; $__LIST__ = $list1;if( count($__LIST__)==0 ) : echo "暂时没有数据..." ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                    <div class="row">
                        <!--新闻缩略图-->
                        <div class="col-sm-6">
                            <a href="<?php echo url('news_detail'); ?>?id=<?php echo $vo['id']; ?>"><img src="/uploads/<?php echo $vo['thumbnail']; ?>" alt="新闻缩略图" class="thumbnail"></a>
                        </div>
                        <!--新闻简介-->
                        <div class="col-sm-6">
                            <a href="<?php echo url('news_detail'); ?>?id=<?php echo $vo['id']; ?>"><h2 class="news_title"><?php echo $vo['title']; ?></h2></a>
                            <p class="description"><?php echo $vo['description']; ?><b><a href="<?php echo url('news_detail'); ?>?id=<?php echo $vo['id']; ?>"></a></b></p>
                            <p class="publish_time">发布时间：<?php echo $vo['time']; ?></p>
                        </div>
                    </div>
                    <hr>
                    <?php endforeach; endif; else: echo "暂时没有数据..." ;endif; ?>
                    <!--分页-->
                    <div class="row">
                        <div class="col-sm-12 center"><?php echo $list1->render(); ?></div>
                    </div>
                </div>

            </div>
        </div>
        <div class="category_tab_content">
            <div class="col-sm-8 category_tab_content_item">
                <div class="news_box">
                    <?php if(is_array($list2) || $list2 instanceof \think\Collection || $list2 instanceof \think\Paginator): $i = 0; $__LIST__ = $list2;if( count($__LIST__)==0 ) : echo "暂时没有数据..." ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                    <div class="row">
                        <!--新闻缩略图-->
                        <div class="col-sm-6">
                            <a href="<?php echo url('news_detail'); ?>?id=<?php echo $vo['id']; ?>"><img src="/uploads/<?php echo $vo['thumbnail']; ?>" alt="新闻缩略图" class="thumbnail"></a>
                        </div>
                        <!--新闻简介-->
                        <div class="col-sm-6">
                            <a href="<?php echo url('news_detail'); ?>?id=<?php echo $vo['id']; ?>"><h3 class="news_title"><?php echo $vo['title']; ?></h3></a>
                            <p class="description"><?php echo $vo['description']; ?><b><a href="<?php echo url('news_detail'); ?>?id=<?php echo $vo['id']; ?>"></a></b></p>
                            <p class="publish_time">发布时间：<?php echo $vo['time']; ?></p>
                        </div>
                    </div>
                    <hr>
                    <?php endforeach; endif; else: echo "暂时没有数据..." ;endif; ?>
                </div>
                <!--分页-->
                <?php echo $list2->render(); ?>
            </div>
        </div>
        <div class="category_tab_content">
            <div class="col-sm-8 category_tab_content_item">
                <div class="news_box">
                    <?php if(is_array($list3) || $list3 instanceof \think\Collection || $list3 instanceof \think\Paginator): $i = 0; $__LIST__ = $list3;if( count($__LIST__)==0 ) : echo "暂时没有数据..." ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                    <div class="row">
                        <!--新闻缩略图-->
                        <div class="col-sm-6">
                            <a href="<?php echo url('news_detail'); ?>?id=<?php echo $vo['id']; ?>"><img src="/uploads/<?php echo $vo['thumbnail']; ?>" alt="新闻缩略图" class="thumbnail"></a>
                        </div>
                        <!--新闻简介-->
                        <div class="col-sm-6">
                            <a href="<?php echo url('news_detail'); ?>?id=<?php echo $vo['id']; ?>"><h2 class="news_title"><?php echo $vo['title']; ?></h2></a>
                            <p class="description"><?php echo $vo['description']; ?><b><a href="<?php echo url('news_detail'); ?>?id=<?php echo $vo['id']; ?>">[详情]</a></b></p>
                            <p class="publish_time">发布时间：<?php echo $vo['time']; ?></p>
                        </div>
                    </div>
                    <hr>
                    <?php endforeach; endif; else: echo "暂时没有数据..." ;endif; ?>
                </div>
                <!--分页-->
                <?php echo $list3->render(); ?>
            </div>
        </div>
        <div class="category_tab_content">
            <div class="col-sm-8 category_tab_content_item">
                <div class="news_box">
                    <?php if(is_array($list4) || $list4 instanceof \think\Collection || $list4 instanceof \think\Paginator): $i = 0; $__LIST__ = $list4;if( count($__LIST__)==0 ) : echo "暂时没有数据..." ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                    <div class="row">
                        <!--新闻缩略图-->
                        <div class="col-sm-6">
                            <a href="<?php echo url('news_detail'); ?>?id=<?php echo $vo['id']; ?>"><img src="/uploads/<?php echo $vo['thumbnail']; ?>" alt="新闻缩略图" class="thumbnail"></a>
                        </div>
                        <!--新闻简介-->
                        <div class="col-sm-6">
                            <a href="<?php echo url('news_detail'); ?>?id=<?php echo $vo['id']; ?>"><h3 class="news_title"><?php echo $vo['title']; ?></h3></a>
                            <p class="description"><?php echo $vo['description']; ?><b><a href="<?php echo url('news_detail'); ?>?id=<?php echo $vo['id']; ?>">[详情]</a></b></p>
                            <p class="publish_time">发布时间：<?php echo $vo['time']; ?></p>
                        </div>
                    </div>
                    <hr>
                    <?php endforeach; endif; else: echo "暂时没有数据..." ;endif; ?>
                </div>
                <!--分页-->
                <div class="row page">
                    <?php echo $list4->render(); ?>
                </div>

            </div>
        </div>

        <!--左侧 结束-->

        <!--右侧 开始-->
        <div class="col-sm-4 selected_case content" id="right_box">
            <div class="row">
                <div class="col-sm-12">
                    <div id="right_form">
                        <form onsubmit="return submit_form()" class="form-horizontal" role="form" id="selected_case_detail_form">
                            <div class="row">
                                <div class="col-sm-12">
                                    <img src="/static/index/static/images/comm/right_order_form_banner.png" alt="右侧预约设计" id="order_design_img">
                                </div>
                            </div>
                            <br>
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label for="name" class="col-sm-4 control-label">您的姓名：</label>
                                        <div class="col-sm-7">
                                            <input type="text" class="form-control" id="name" placeholder="您的姓名" name="name" required>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="name" class="col-sm-4 control-label">小区名称：</label>
                                        <div class="col-sm-7">
                                            <input type="text" class="form-control" id="address" placeholder="小区名称" name="address" required>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="name" class="col-sm-4 control-label">装修面积：</label>
                                        <div class="col-sm-7">
                                            <input type="text" class="form-control" id="area" placeholder="装修面积" name="area" required>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="name" class="col-sm-4 control-label">联系电话：</label>
                                        <div class="col-sm-7">
                                            <input type="text" class="form-control" id="tel" placeholder="联系电话" name="tel" required>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <br>
                            <div class="row">
                                <div class="col-sm-12">
                                    <p class="text"><button type="submit" class="btn btn-lg btn-danger btn-block" id="selected_case_detail_btn_order">预约设计</button></p>
                                </div>
                            </div>
                            <input type="hidden" name="from" value="PC">
                            <input type="hidden" name="remark" value="设计师详情">
                        </form>
                    </div>
                </div>
            </div>
            <!--推荐设计师-->
            <div class="row">
                <?php if(is_array($suggest_designer) || $suggest_designer instanceof \think\Collection || $suggest_designer instanceof \think\Paginator): $i = 0; $__LIST__ = $suggest_designer;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$suggest_designer): $mod = ($i % 2 );++$i;?>
                <div class="col-sm-12">
                    <div class="case">
                        <ul class="suggest_title">
                            <li><h4>推荐设计师</h4></li>
                        </ul>

                        <div class="thumbnail-img">
                            <a href="<?php echo url('TeamServices/designer_info'); ?>?id=<?php echo $suggest_designer['id']; ?>"><img src="/uploads/<?php echo $suggest_designer['avatar']; ?>" alt="设计师头像"></a>
                        </div>
                        <div class="text">
                            <p class="center"><span class="designer_name"><?php echo $suggest_designer['name']; ?></span> &nbsp;<?php echo $suggest_designer['position']; ?></p>
                            <p class="center">案例作品：<?php echo $suggest_designer['numbers']; ?> 套&nbsp;&nbsp; 从业经验：<?php echo $suggest_designer['years']; ?> 年</p>
                            <!--设计理念-->
                            <h5 class="designer_introduction center"><?php echo $suggest_designer['introduction']; ?></h5>
                        </div>
                    </div>
                </div>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </div>
            <!--推荐案例-->
            <div class="row">
                <div class="col-sm-12">
                    <?php if(is_array($suggest_case) || $suggest_case instanceof \think\Collection || $suggest_case instanceof \think\Paginator): $i = 0; $__LIST__ = $suggest_case;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                    <div class="case">
                        <ul class="suggest_title">
                            <li><h4>推荐案例</h4></li>
                        </ul>
                        <div class="thumbnail-img">
                            <a href="<?php echo url('SelectedCase/selected_case_detail'); ?>?case_id=<?php echo $vo['case_id']; ?>"><img src="/uploads/<?php echo $vo['case_photo1']; ?>" alt="<?php echo $vo['style']; ?>"></a>
                        </div>
                        <div class="text clearfix">
                            <p class="center title">
                                <span class="proprietor_address"><?php echo $vo['community_name']; ?>&nbsp;<?php echo $vo['area']; ?> ㎡</span>
                                <span class="design_style pull-right"><?php echo $vo['style']; ?></span>
                            </p>
                            <div class="btn-group">
                                <h3 class="inline pull-left"><span class="look_detail label"><a href="<?php echo url('SelectedCase/selected_case_detail'); ?>?case_id=<?php echo $vo['case_id']; ?>">查看详情</a></span></h3>
                                <h3 class="inline pull-right"><span class="order_design  label"><a href="">预约设计</a></span></h3>
                            </div>
                            <span><img src="/uploads/<?php echo $vo['avatar']; ?>" alt="设计师" class="designer"></span>
                        </div>
                    </div>

                    <?php endforeach; endif; else: echo "" ;endif; ?>
                </div>
            </div>

        </div>
        <!--右侧 结束-->

    </div>

</div>

<!--公共模块 section 结束-->

<!--公共模块 footer 开始-->
    <footer class="hidden-xs">
    <div class="container">
        <div class="row">
            <div class="col-sm-6 col-xs-12 clearfix">
                <div class="col-sm-4 col-xs-6">
                    <ul>
                        <li>服务流程</li>
                        <li><a href="">免费预约</a></li>
                        <li><a href="">到店体验</a></li>
                        <li><a href="">量房设计</a></li>
                        <li><a href="">签订合同</a></li>
                        <li><a href="">精准施工</a></li>
                        <li><a href="">竣工验收</a></li>
                        <li><a href="">无忧售后</a></li>
                    </ul>
                </div>
                <div class="col-sm-4 col-xs-6">
                    <ul>
                        <li>服务流程</li>
                        <li><a href="">免费预约</a></li>
                        <li><a href="">到店体验</a></li>
                        <li><a href="">量房设计</a></li>
                        <li><a href="">签订合同</a></li>
                        <li><a href="">精准施工</a></li>
                        <li><a href="">竣工验收</a></li>
                        <li><a href="">无忧售后</a></li>
                    </ul>
                </div>
                <div class="col-sm-4 col-xs-6 hidden-xs">
                    <ul>
                        <li>服务流程</li>
                        <li><a href="">免费预约</a></li>
                        <li><a href="">到店体验</a></li>
                        <li><a href="">量房设计</a></li>
                        <li><a href="">签订合同</a></li>
                        <li><a href="">精准施工</a></li>
                        <li><a href="">竣工验收</a></li>
                        <li><a href="">无忧售后</a></li>
                        </ul>
                </div>
            </div>
            <div class="col-sm-6 col-xs-12">
                <div class="col-sm-4 col-xs-6">
                    <img src="/static/index/static/images/index/wechat01.png" alt="">
                    <p class="center">官方微信</p>
                </div>
                <div class="col-sm-4 col-xs-6">
                    <img src="/static/index/static/images/index/wechat02.png" alt="">
                    <p class="center">盛腾家装商城</p>
                </div>
            </div>
        </div>
        <hr>
        <p class="center">版权所有© 安徽盛腾装饰设计有限公司  皖ICP备17004315号 <script type="text/javascript">var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.write(unescape("%3Cspan id='cnzz_stat_icon_1272836750'%3E%3C/span%3E%3Cscript src='" + cnzz_protocol + "s13.cnzz.com/z_stat.php%3Fid%3D1272836750%26show%3Dpic' type='text/javascript'%3E%3C/script%3E"));</script></p>

    </div>

</footer>

<!--<a class="livechat-girl animated hidden-xs" href="#">-->
    <!--<img class="girl" src="/static/index/static/images/comm/notify.png" alt="点击这里给我发消息" title="点击这里给我发消息" border="0">-->
    <!--<div class="livechat-hint rd-notice-tooltip hide_hint">-->
        <!--<div class="rd-notice-content">嘿！有什么能帮到您的吗？</div>-->
    <!--</div>-->
    <!--<div class="animated-circles ">-->
        <!--<div class="circle c-1"></div>-->
        <!--<div class="circle c-2"></div>-->
        <!--<div class="circle c-3"></div>-->
    <!--</div>-->
<!--</a>-->
<!--手机端底部tab 开始-->
    <div class="visible-xs">
            <div class="col-xs-12 center bottom_tab">
                <ul class="clearfix">
                    <li class="pull-left active"><a href="<?php echo url('Index/index'); ?>"><div><img src="/static/index/static/images/index/home.png" alt=""></div><div class="center title">首页</div></a></li>
                    <li class="pull-left"><a href="#"><div><img src="/static/index/static/images/index/gift.png" alt=""></div><div class="center title">活动</div></a></li>
                    <li class="pull-left"><a href="#"><div class="message img-circle"><img class="animated flash" src="/static/index/static/images/index/message.png" alt="消息"><span class="point"></span></div></a></li>
                    <li class="pull-left"><a href="<?php echo url('Index/free_design'); ?>"><div><img src="/static/index/static/images/index/design.png" alt=""></div><div class="center title">免费设计</div></a></li>
                    <li class="pull-left"><a href="tel:0551-65660788"><div><img src="/static/index/static/images/index/tel.png" alt=""></div><div class="center title">拨打电话</div></a></li>
                </ul>
            </div>
    </div>
<!--手机端底部tab 结束-->

<!--底部悬浮 点击可弹出报价 结束-->
<!--底部弹出报价 开始-->
<div class="quotation hidden-xs">
    <div class="container">
        <div class="row center">
            <img src="/static/index/static/images/comm/quotation_down.png" alt="" class="animated infinite bounce close_quotation">
            <p class="center"><span class="red-font">0</span>&nbsp;元 预约设计免费抢</p>
        </div>
        <br>
        <div class="row">
            <form onsubmit="return footer_submit_form()" class="form-horizontal clearfix text-c" role="form" id="footer_form">
                <div class="col-sm-2 col-sm-offset-1">
                    <select class="form-control input-lg" name="address" required title="选择城市" style="width: 100%">
                        <option>选择城市</option>
                        <option value="合肥">合肥</option>
                        <option value="蚌埠">蚌埠</option>
                        <option value="石家庄">石家庄</option>
                        <option value="杭州">杭州</option>
                        <option value="呼和浩特">呼和浩特</option>
                        <option value="西安">西安</option>
                        <option value="石家庄">石家庄</option>
                        <option value="其他">其他</option>
                    </select>
                </div>

                <div class="col-sm-2">
                    <div class="input-group input-group-lg">
                        <input type="text" minlength="2" class="form-control" placeholder="房屋面积&nbsp;m2" name="area" required>
                    </div>
                </div>
                <div class="col-sm-2">
                    <div class="input-group input-group-lg">
                        <input type="text" minlength="2" class="form-control" placeholder="您的姓名" name="name" required>
                    </div>
                </div>
                <div class="col-sm-2">
                    <div class="input-group input-group-lg">
                        <input type="text" minlength="11" class="form-control" placeholder="您的电话" name="tel" required>
                    </div>
                </div>


                <div class="col-sm-2">
                    <button  class="btn btn-lg btn-danger" type="submit" id="footer_btn_order">立即报名</button>
                </div>
                <input type="hidden" name="from" value="PC">
                <input type="hidden" name="remark" value="底部报价">
            </form>
        </div>
    </div>


</div>
<!--底部弹出报价 结束-->

<!--右侧侧边栏 开始-->
<div class="float_right_menu hidden-xs">
    <div id="logo">
        <img src="/static/index/static/images/comm/logo.png" alt="盛腾logo">
    </div>
    <ul class="clearfix">
        <li>快速导航</li>
        <li id="OnlineConsultation"><div class="center"><img src="/static/index/static/images/comm/slide_right-item02.png" alt="在线咨询"></div>在线咨询</li>
        <li data-toggle="modal" data-target="#myModal"><div class="center"><img src="/static/index/static/images/comm/slide_right-item03.png" alt="预约装修"></div>预约装修</li>
        <li data-toggle="modal" data-target="#myModal"><div class="center"><img src="/static/index/static/images/comm/slide_right-item04.png" alt="免费报价"></div>免费报价</li>
        <li><div class="center"><img src="/static/index/static/images/comm/slide_right-item05.png" alt="返回顶部"></div>返回顶部</li>

    </ul>
</div>
<!--右侧侧边栏 结束-->

<!--弹出模态框 开始-->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                    &times;
                </button>
                <h2 class="modal-title center" id="myModalLabel">
                    预约报名
                </h2>
            </div>
            <div class="modal-body">
                    <form onsubmit="return modal_form()" class="form-horizontal" role="form" id="modal_form" method="post">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label for="name"  type="name" class="col-sm-3 control-label">您的姓名：</label>
                                    <div class="col-sm-8">
                                        <input type="text" minlength="2" class="form-control" id="name" placeholder="您的姓名" name="name" required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="name" class="col-sm-3 control-label">小区名称：</label>
                                    <div class="col-sm-8">
                                        <input type="text" minlength="2"   class="form-control" id="address" placeholder="小区名称" name="address" required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="name" class="col-sm-3 control-label">装修面积：</label>
                                    <div class="col-sm-8">
                                        <input type="text" minlength="2"  class="form-control" id="area" placeholder="装修面积 ㎡" name="area" required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="name" class="col-sm-3 control-label">联系电话：</label>
                                    <div class="col-sm-8">
                                        <input type="tel" minlength="11"   class="form-control" id="tel" placeholder="联系电话" name="tel" required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-md-12">
                                        <p class="bg-success" style="padding: 5px;">我们将会对您的信息进行严格保密，请放心提交!</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <br>
                        <div class="row">
                            <div class="col-sm-12">
                                <p class="text"><button type="submit" class="btn btn-lg btn-danger btn-block" id="modal_form_btn">马上预约</button></p>
                            </div>
                        </div>
                        <input type="hidden" name="from" value="PC">
                        <input type="hidden" name="remark" value="弹出模态框">
                    </form>
            </div>

        </div>
    </div>
</div>
    <!--弹出模态框 结束-->
<!--引入CDN-->
<script src="https://cdn.bootcss.com/jquery/3.2.1/jquery.min.js"></script>
<script src="http://cdn.static.runoob.com/libs/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<!--wow.js 依赖animated.css 滑动位置触发动画库-->
<script src="https://cdn.bootcss.com/wow/1.1.2/wow.min.js"></script>
<script src="http://static.runoob.com/assets/jquery-validation-1.14.0/dist/jquery.validate.min.js"></script>
<script src="http://static.runoob.com/assets/jquery-validation-1.14.0/dist/localization/messages_zh.js"></script>
<!--图标css-->
<link href="https://cdn.bootcss.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
<!--百度商桥 开始-->
<script>
    var _hmt = _hmt || [];
    (function() {
        var hm = document.createElement("script");
        hm.src = "https://hm.baidu.com/hm.js?5cbf9a484044f67aa33310ccaab66f91";
        var s = document.getElementsByTagName("script")[0];
        s.parentNode.insertBefore(hm, s);
    })();
</script>

<!--百度商桥 结束-->

<!--百度推送 开始-->
<script>
    (function(){
        var bp = document.createElement('script');
        var curProtocol = window.location.protocol.split(':')[0];
        if (curProtocol === 'https') {
            bp.src = 'https://zz.bdstatic.com/linksubmit/push.js';
        }
        else {
            bp.src = 'http://push.zhanzhang.baidu.com/push.js';
        }
        var s = document.getElementsByTagName("script")[0];
        s.parentNode.insertBefore(bp, s);
    })();
</script>
<!--百度推送 结束-->
<!--360推送-->
<script>(function(){
    var src = (document.location.protocol == "http:") ? "http://js.passport.qihucdn.com/11.0.1.js?36f8e7ad6866e1a44dab6f0af5ac4de7":"https://jspassport.ssl.qhimg.com/11.0.1.js?36f8e7ad6866e1a44dab6f0af5ac4de7";
    document.write('<script src="' + src + '" id="sozz"><\/script>');
})();
</script>

<!--公共页面通用js-->
<!--顶部 banner 动画-->
<script src="/static/index/lib/js/slide_banner.js"></script>

<script>
    // 底部弹出报价
    $('#alert-order-btn').click(function () {
        $('#alert-order-btn').hide();
        $('.quotation').fadeIn();
    });

    // 隐藏底部报价
    $('.quotation .close_quotation').click(function () {
        $('.quotation').fadeOut();
        $('#alert-order-btn').show();
    });

    //返回顶部
    $('.float_right_menu ul li:last').click(function () {
        $("html,body").animate({scrollTop:0}, 800);
    });

    //底部提交用户预约设计信息
    function footer_submit_form() {
        $.ajax({
            type: "POST",
            url: "<?php echo url('Index/orderAdd'); ?>",
            data : $("#footer_form").serialize(),
            beforeSend:function(){
                $('#footer_form').attr('onsubmit','return false;');
                $('#footer_btn_order').html("数据提交中...");
            },
            success: function(data) {
                alert(data.msg);
                $('#footer_btn_order').html("预约成功").removeClass('btn-danger').addClass('btn-success');
            },
            error:function (data) {
                alert(data.msg);
            }
        });
        return false;
    }


    //右侧提交用户预约设计信息
    function submit_form() {
        $.ajax({
            type: "POST",
            url: "<?php echo url('Index/orderAdd'); ?>",
            data : $("#selected_case_detail_form").serialize(),
            beforeSend:function(){
                $('#selected_case_detail_form').attr('onsubmit','return false;');
                $('#selected_case_detail_btn_order').html("数据提交中...");
            },
            success: function(data) {
                alert(data.msg);
                $('#selected_case_detail_btn_order').html("预约成功").removeClass('btn-danger').addClass('btn-success');
            },
            error:function (data) {
                alert(data.msg);
            }
        });
        return false;
    }

    //模态框表单验证
    $('#myModal').validate();
    //模态框提交预约信息
    function modal_form() {
        $.ajax({
            type: "POST",
            url: "<?php echo url('Index/orderAdd'); ?>",
            data : $("#modal_form").serialize(),
            beforeSend:function(){
                $('#modal_form').attr('onsubmit','return false;');
                $('#modal_form_btn').html("数据提交中...");
            },
            success: function(data) {
                alert(data.msg);
                $('#modal_form_btn').html("预约成功").removeClass('btn-danger').addClass('btn-success');
            },
            error:function (data) {
                alert(data.msg);
            }
        });
        return false;
    }

    /**
     * 截取url参数方法
     * @description 参数 name 为url 参数名
     */
    function getQueryString(name) {
        var reg = new RegExp('(^|&)' + name + '=([^&]*)(&|$)', 'i');
        var r = window.location.search.substr(1).match(reg);
        if (r != null) {
            return unescape(r[2]);
        }
        return null;
    }

    //点击在线咨询
    $('#OnlineConsultation, .livechat-girl , .message, .get-ticket,.order_design').click(function () {
        $('#nb_icon_wrap').click();
    });

    $('#nb_icon_wrap').css('opacity','0');


    $('.livechat-girl').hover(function () {
        $('.livechat-hint').removeClass('hide_hint').addClass('show_hint');
    },function () {
        $('.livechat-hint').addClass('hide_hint').removeClass('show_hint');
    });

    //    左侧咨询按钮动画
    $(function(){
        function hide() {
            $('.animated-circles').removeClass('animated');
        }
        function show(){
            $('.animated-circles').addClass('animated');
        }
        setInterval(show,3000);
        setInterval(hide,6000);
    });
    
//    返回上一页
    $('.go-back').click(function () {
        history.back();
    });

//    底部点击active 样式
    $('.bottom_tab ul li').click(function () {
        var i = $(this).index();
        localStorage.setItem('cur-bottom_tab',i);
    });

    if (localStorage.getItem('cur-bottom_tab') !== null){
        var i = localStorage.getItem('cur-bottom_tab');
        $('.bottom_tab ul li').eq(i).addClass('active').siblings().removeClass('active');
    }
</script>
<!--公共模块 footer 结束-->

<!--业务相关 js 开始-->
    
<script>
    <!--导航菜单-->
    $('header nav ul li').removeClass('active');
    $('header nav ul li:eq(3)').addClass('active');

    //新闻分类 tab 切换
    $('.category_box li').click(function () {
        var  i = $(this).index();
        $('.category_tab_content .category_tab_content_item').removeClass('active').eq(i).addClass('active');
        $(this).addClass('active').siblings().removeClass('active');
    });


</script>

<!--业务相关 js 结束-->
</body>
</html>