<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:78:"/var/www/html/shengteng-group/public/../application/admin/view/user/login.html";i:1514598006;}*/ ?>
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="utf-8">
    <meta name="renderer" content="webkit|ie-comp|ie-stand">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <!--响应式等比例缩放-->
    <meta name="viewport" content="initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>后台管理中心 - 盛腾集团</title>

    <link href="/static/login/css/style.css" rel="stylesheet" type="text/css" media="all" />

    <script type="text/javascript" src="/static/login/js/jquery.min.js"></script>
    <script>

        /**
         * 判断是否为谷歌浏览器
         */
        var isChrome = navigator.userAgent.toLowerCase().match(/chrome/) != null;
        if (!isChrome) {
            alert('请使用谷歌浏览器或开启360浏览器极速模式后再访问！');
            location.href = "http://rj.baidu.com/soft/detail/14744.html"
        }else {
//            alert('系统维护中！请稍后再试');
//            location.href = "http://rj.baidu.com/soft/detail/14744.html"
        }
    </script>

</head>
<body>

<div class="message warning">
    <div class="inset">
        <div class="login-head">
            <h1>管理员登录</h1>
        </div>

        <form action="<?php echo url('User/doLogin'); ?>" method="post">
            <ul>
                <li><input type="text" class="text" name="id" placeholder="登录ID" required /><i class=" icon user"></i></li>
                <li><input type="password" name="pass" value="" placeholder="登录密码" required /> <i class="icon lock"></i></li>
            </ul>

            <div class="submit">
                <input type="submit" name="submit" value="登录" >
                <div class="clear">  </div>
            </div>
        </form>
    </div>
</div>

<!--- footer --->
<div class="footer">
    <p>Copyright &copy;盛腾集团 2017.</p>
</div>



<script src="https://cdn.bootcss.com/canvas-nest.js/1.0.1/canvas-nest.min.js"></script>
</body>
</html>