<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:83:"/var/www/html/shengteng-group/public/../application/index/view/activity/mobile.html";i:1524019771;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>宿州盛腾开业促销！-盛腾家装工厂店</title>
    <link href="https://cdn.bootcss.com/bootstrap/4.0.0-alpha/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/static/index/static/css/index_mobile.css">
    
    <meta name="viewport" content="initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
</head>
<body>

<div class="mobile-wrapper">
    <img src="/static/index/static/images/activity/mobile/activity_01.jpg">
    <img class="lazy" data-original="/static/index/static/images/activity/mobile/activity_02.jpg">

    <div class="user-from user-from1">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <h1 class="align-center">预约报名</h1>
                    <p class="align-center">百平米全包豪装仅需 129800 元！ 名额仅限 68 户！</p>
                    <p class="align-center">请留下你的联系方式，我们会在第一时间为你报名！</p>
                </div>
            </div>

            <div class="row">
                <form role="form" class="form-inline col-xs-12" onsubmit="return order1();" id="form1">
                    <div class="form-group col-xs-12">
                        <label>称呼：</label>
                        <input type="input" name="name" class="form-control" required>
                    </div>

                    <div class="form-group col-xs-12">
                        <label>电话：</label>
                        <input type="input" name="tel" class="form-control" required>
                    </div>
                    <br><br><br>
                    <div class="form-group col-xs-12">
                        <label>地址：</label>
                        <input type="input" name="address" class="form-control" required>
                    </div>

                    <div class="form-group col-xs-12">
                        <label>面积：</label>
                        <input type="input" name="area" class="form-control" required>
                    </div>

                    <input type="hidden" name="from" value="手机官网">
                    <input type="hidden" name="remark" value="宿州开业活动落地页">
                    <br><br><br>
                    <div class="form-group col-xs-12 align-left">
                        <div align="center"><button class="btn" type="submit"></button></div>
                    </div>
                    
                </form>
            </div>
        </div>  
    </div>

    <img class="lazy" data-original="/static/index/static/images/activity/mobile/activity_05.jpg">
    <img class="lazy" data-original="/static/index/static/images/activity/mobile/activity_06.jpg">
    <img class="lazy" data-original="/static/index/static/images/activity/mobile/activity_07.jpg" onClick="scrollToEnd();">
    <img class="lazy" data-original="/static/index/static/images/activity/mobile/activity_08.jpg">
    <img class="lazy" data-original="/static/index/static/images/activity/mobile/activity_09.jpg">
    <img class="lazy" data-original="/static/index/static/images/activity/mobile/activity_10.jpg">
    <img class="lazy" data-original="/static/index/static/images/activity/mobile/activity_11.jpg">
    <img class="lazy" data-original="/static/index/static/images/activity/mobile/activity_12.jpg">
    <img class="lazy" data-original="/static/index/static/images/activity/mobile/activity_13.jpg">
    <img class="lazy" data-original="/static/index/static/images/activity/mobile/activity_14.jpg">

    <div class="user-from user-from2">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <h1 class="align-center">预约报名</h1>
                    <p class="align-center">百平米全包豪装仅需 129800 元！ 名额仅限 68 户！</p>
                    <p class="align-center">请留下你的联系方式，我们会在第一时间为你报名！</p>
                </div>
            </div>

            <div class="row">
                <form role="form" class="form-inline col-xs-12" onsubmit="return order2();" id="form2">
                    <div class="form-group col-xs-12">
                        <label>称呼：</label>
                        <input type="input" name="name" class="form-control" required>
                    </div>

                    <div class="form-group col-xs-12">
                        <label>电话：</label>
                        <input type="input" name="tel" class="form-control" required>
                    </div>
                    <br><br><br>
                    <div class="form-group col-xs-12">
                        <label>地址：</label>
                        <input type="input" name="address" class="form-control" required>
                    </div>

                    <div class="form-group col-xs-12">
                        <label>面积：</label>
                        <input type="input" name="area" class="form-control" required>
                    </div>

                    <input type="hidden" name="from" value="手机官网">
                    <input type="hidden" name="remark" value="宿州开业活动落地页">
                    <br><br><br>
                    <div class="form-group col-xs-12 align-left">
                        <div align="center"><button class="btn" type="submit"></button></div>
                    </div>
                    
                </form>
            </div>
        </div>  
    </div>
</div>
    

<script src="https://cdn.bootcss.com/jquery/3.3.1/jquery.min.js"></script>

<script src="https://cdn.bootcss.com/jquery_lazyload/1.9.7/jquery.lazyload.min.js"></script>

<script class="lazy" src="/static/index/static/js/index_mobile.js" charset="utf-8"></script>

</body>
</html>