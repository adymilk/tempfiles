<?php if (!defined('THINK_PATH')) exit(); /*a:5:{s:79:"/var/www/html/shengteng-group/public/../application/index/view/index/index.html";i:1524020767;s:66:"/var/www/html/shengteng-group/application/index/view/tpl/base.html";i:1523848391;s:66:"/var/www/html/shengteng-group/application/index/view/tpl/head.html";i:1524014591;s:68:"/var/www/html/shengteng-group/application/index/view/tpl/header.html";i:1516330618;s:68:"/var/www/html/shengteng-group/application/index/view/tpl/footer.html";i:1524020063;}*/ ?>
<!DOCTYPE html>
<html lang="zh">

<!--公共模板 head 开始-->
    <head>
    <meta charset="utf-8">
    <!--响应式等比例缩放-->
    <meta name="viewport" content="initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <link href="/static/index/static/images/comm/favicon.ico" rel="icon" type="image/x-icon" />
    <meta name="keywords" content="盛腾|盛腾集团|盛腾家装科技集团官网|盛腾家装怎么样|装修效果图|装修公司|国内整装全包公司|装修设计效果图|装修公司|别墅装修|家庭装修|装修图片|客厅装修效果图|电视墙装修效果图" />
    <meta name="description" content="盛腾家装科技集团是国内首创家装买家模式的大全包装修公司，以工厂店的模式迅速在全国各地建立分公司。秉承让老百姓把装修原本的昂贵、费心、费力，变得更加【省钱】、【省心】、【省力】真正的让业主连一颗螺丝钉都不用买，便可以直接拎包入住！盛腾模式深受咱们老板姓的支持与厚爱，并不断有媒体采访。金杯银杯都不如咱们老百姓的口碑！" />

    <!--动画-->
    <link href="https://cdn.bootcss.com/animate.css/3.5.2/animate.min.css" rel="stylesheet">
    <!--banner 插件 css-->
    <link rel="stylesheet" href="/static/index/lib/css/slide_banner.css">
    <!--bootstrap-->
    <link rel="stylesheet" href="http://cdn.static.runoob.com/libs/bootstrap/3.3.7/css/bootstrap.min.css">
    <!--自定义css-->
    <link rel="stylesheet" href="/static/index/static/css/comm.css">


<!--公共模板 head 结束-->

<!--引入业务相关css 开始-->

    <link rel="stylesheet" href="/static/index/static/css/index.css">
    <script>
    if (navigator.userAgent.match(/(iPhone|Android.*Mobile)/) || navigator.userAgent.match(/MSIE [6,7,8,9]/)) {
      window.location.replace("<?php echo url('index/mobile'); ?>");
  }
</script>

<!--引入业务相关css 结束-->

<!--自定义当前页面title-->
<title>盛腾家装科技集团官网——盛腾家装科技集团</title>
</head>
<body>

<!--公共模块 header 开始-->
    <header>
    <nav class="navbar navbar-inverse nav_bg hidden-xs" role="navigation">

        <div class="container-fluid">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse"
                            data-target="#example-navbar-collapse">
                        <span class="sr-only">切换导航</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand hidden-sm hidden-lg hidden-md" href="<?php echo url('index/index'); ?>">盛腾家装工厂店</a>
                </div>
                <div class="collapse navbar-collapse" id="example-navbar-collapse">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="<?php echo url('index/index'); ?>">HOME首页</a></li>
                        <li><a href="<?php echo url('SelectedCase/index'); ?>">案例精选</a></li>
                        <li><a href="<?php echo url('TeamServices/index'); ?>">团队服务</a></li>
                        <li><a href="<?php echo url('DecorationStrategy/index'); ?>">家装攻略</a></li>
                        <li><a href="<?php echo url('QualityEngineering/index'); ?>">品质工程</a></li>
                        <li><a href="<?php echo url('AllShops/index'); ?>">各大工厂店</a></li>
                        <li><a href="<?php echo url('Comments/index'); ?>">业主评价</a></li>
                        <li><a href="<?php echo url('AboutUs/about_us'); ?>">关于盛腾</a></li>
                        <li><a href="<?php echo url('AboutUs/contact_us'); ?>">联系我们</a></li>
                        <!--<li class="dropdown">-->
                            <!--<a href="#" class="dropdown-toggle" data-toggle="dropdown">-->
                                <!--关于我们 <b class="caret"></b>-->
                            <!--</a>-->
                            <!--<ul class="dropdown-menu">-->
                                <!--<li><a href="<?php echo url('AboutUs/about_us'); ?>">关于盛腾</a></li>-->
                                <!--<li class="divider"></li>-->
                                <!--<li><a href="<?php echo url('AboutUs/contact_us'); ?>">联系我们</a></li>-->
                            <!--</ul>-->
                        <!--</li>-->
                    </ul>
                </div>
            </div>
        </div>
    </nav>
</header>

<!--公共模块 header 结束-->

<!--公共模块 section 开始-->
    



<!--pc 端显示的内容 开始-->
<div class="hidden-xs" id="show-on-pc">
    <!--banner 开始-->
    <div class="banner">
        <!-- slider start -->
        <div class="fnc-slider example-slider">
            <div class="fnc-slider__slides">
                <!-- slide start -->
                <div class="fnc-slide m--blend-green m--active-slide">
                    <a href="<?php echo url('activity/pc'); ?>" target="_blank">
                        <div class="fnc-slide__inner">

                            <div class="fnc-slide__content wow bounceInUp">
                                <h2 class="fnc-slide__heading">
                                    <div class="fnc-slide__heading-line">
                                        <span class="animated zoomInDown">豪装</span>
                                    </div>
                                    <div class="fnc-slide__heading-line">
                                        <span class="animated zoomInDown">不豪价</span>
                                    </div>
                                </h2>

                            </div>
                        </div>
                    </a>
                </div>
                <!-- slide end -->
                <!-- slide start -->
                <div class="fnc-slide m--blend-dark">
                    <div class="fnc-slide__inner">

                        <div class="fnc-slide__content">
                            <h2 class="fnc-slide__heading">
                                <div class="fnc-slide__heading-line">
                                    <span>豪装</span>
                                </div>
                                <div class="fnc-slide__heading-line">
                                    <span>不豪价</span>
                                </div>
                            </h2>

                        </div>
                    </div>
                </div>
                <!-- slide end -->
                <!-- slide start -->
                <div class="fnc-slide m--blend-red">
                        <div class="fnc-slide__inner">
                            <div class="fnc-slide__content">
                                <h2 class="fnc-slide__heading">
                                    <div class="fnc-slide__heading-line">
                                        <span>豪装</span>
                                    </div>
                                    <div class="fnc-slide__heading-line">
                                        <span>不豪价</span>
                                    </div>
                                </h2>

                            </div>
                        </div>
                </div>
                <!-- slide end -->
                <!-- slide start -->
                <div class="fnc-slide m--blend-blue">
                    <a href="<?php echo url('index/business_cooperation'); ?>">
                        <div class="fnc-slide__inner">
                        <div class="fnc-slide__content">
                            <h2 class="fnc-slide__heading">
                                <div class="fnc-slide__heading-line">
                                    <span>豪装</span>
                                </div>
                                <div class="fnc-slide__heading-line">
                                    <span>不豪价</span>
                                </div>
                            </h2>

                        </div>
                    </div>
                    </a>
                </div>
                <!-- slide end -->
            </div>

            <!--底部导航-->
            <nav class="fnc-nav">
                <div class="fnc-nav__bgs">
                    <div class="fnc-nav__bg m--navbg-green m--active-nav-bg"></div>
                    <div class="fnc-nav__bg m--navbg-dark"></div>
                    <div class="fnc-nav__bg m--navbg-red"></div>
                    <div class="fnc-nav__bg m--navbg-blue"></div>
                </div>
                <div class="fnc-nav__controls">
                    <button class="fnc-nav__control">
                        最新活动
                        <span class="fnc-nav__control-progress"></span>
                    </button>
                    <button class="fnc-nav__control">
                        样板房征集
                        <span class="fnc-nav__control-progress"></span>
                    </button>
                    <button class="fnc-nav__control">
                        大全包
                        <span class="fnc-nav__control-progress"></span>
                    </button>
                    <button class="fnc-nav__control">
                        招商加盟
                        <span class="fnc-nav__control-progress"></span>
                    </button>
                </div>
            </nav>
        </div>
        <!-- slider end -->

    </div>
    <!--banner 结束-->
    <!--媒体新闻 开始-->
    <div class="section section1 hidden-xs" id="tvShow">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <h1 class="text-r">全国主流媒体深度推荐品牌</h1>
                    <p class="text-r"><span id="bg_red">全国各地媒体实时报道</span></p>
                    <p class="text-r">用品质见证盛腾</p>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-8 tv_bg">
                    <video src="http://0551shengteng.cn/Public/images/zaijia/599a9d215117a.mp4" controls >你的浏览器不支持html5播放</video>
                    <video src="/uploads/shengteng-group.mp4" controls>你的浏览器不支持html5播放</video>
                    <video src="/uploads/shengteng-group.mp4" controls>你的浏览器不支持html5播放</video>
                    <video src="/uploads/shengteng-group.mp4" controls>你的浏览器不支持html5播放</video>
                    <video src="/uploads/shengteng-group.mp4" controls>你的浏览器不支持html5播放</video>
                    <video src="/uploads/shengteng-group.mp4" controls>你的浏览器不支持html5播放</video>
                    <video src="/uploads/shengteng-group.mp4" controls>你的浏览器不支持html5播放</video>
                </div>
                <div class="col-sm-3 tvs col-sm-offset-1">
                    <ul>
                        <li class="active"><img src="/static/index/static/images/index/anhuiTv-active.png" alt=""></li>
                        <li><img src="/static/index/static/images/index/zhejiangTv.png" alt=""></li>
                        <li><img src="/static/index/static/images/index/education_technology.png" alt=""></li>
                        <li><img src="/static/index/static/images/index/yantaiTv.png" alt=""></li>
                        <li><img src="/static/index/static/images/index/bengbuTv.png" alt=""></li>
                        <li><img src="/static/index/static/images/index/hebeiTv.png" alt=""></li>
                        <li><img src="/static/index/static/images/index/neimengguTv.png" alt=""></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!--媒体新闻 结束-->

    <!--工厂价直达你家 开始-->
    <div class="section section2 hidden-xs" >
        <div class="col-sm-12">
            <img src="/static/index/static/images/index/section2_item01.png" alt="" class="">
            <img src="/static/index/static/images/index/section2_item02.png" alt="" class="">
            <img src="/static/index/static/images/index/section2_item03.png" alt="飞机" class="wow bounceInDown">
            <img src="/static/index/static/images/index/section2_item04.png" alt="" class="">
            <img src="/static/index/static/images/index/section2_item05.png" alt="工厂价" class="wow bounceInLeft">
            <img src="/static/index/static/images/index/section2_item06.png" alt="" class="">

        </div>
    </div>
    <!--工厂价直达你家 结束-->

    <!--真正的全包豪装-->
    <div class="section section3 hidden-xs" >
        <div class="slide_text">
            <ul class="clearfix">
                <li>1.8米大床</li>
                <li>床屏</li>
                <li>床箱</li>
                <li>床头柜</li>
                <li>大衣柜</li>
                <li>单开</li>
                <li>单开</li>
                <li>双开</li>
                <li>单开双控</li>
                <li>水电开槽</li>
                <li>水管</li>
                <li>电管</li>
                <li>电线</li>
                <li>螺栓管</li>
                <li>弯头</li>
                <li>线槽粉平</li>
                <li>水泥</li>
                <li>沙子</li>
                <li>人工</li>
                <li>铺满木地板</li>
                <li>木地板扣条</li>
                <li>收边条</li>
                <li>防潮垫</li>
                <li>胶水</li>
                <li>钉子</li>
                <li>钉子踢脚线</li>
                <li>人工费</li>
                <li>床头柜</li>
                <li>大衣柜</li>
                <li>实木复合免漆门</li>
                <li>一张餐桌</li>
                <li>六把餐椅</li>
                <li>六把餐椅</li>
                <li>主照明</li>
                <li>筒灯</li>
                <li>筒灯</li>
                <li>毛巾架</li>
                <li>抽纸盒</li>
                <li>皂液器</li>
                <li>五金件</li>
                <li>五金件</li>
                <li>1.5米大床</li>
                <li>床头柜</li>
                <li>1.8米大床</li>
                <li>床屏</li>
                <li>床箱</li>
                <li>床头柜</li>
                <li>大衣柜</li>
                <li>大衣柜</li>
                <li>带裤抽</li>
                <li>抽屉</li>
                <li>烤漆门</li>
                <li>门锁</li>
                <li>门吸</li>
                <li>合页</li>
                <li>门套 </li>
                <li>压条</li>
                <li>局部找平</li>
                <li>水泥</li>
                <li>砂浆</li>
                <li>人工</li>
                <li>插座</li>
                <li>底盒</li>
                <li>开关</li>
                <li>双开</li>
                <li>单开双控</li>
                <li>水电开槽</li>
                <li>水管</li>
                <li>电管</li>
                <li>电线</li>
                <li>螺栓管</li>
                <li>弯头</li>
                <li>线槽粉平</li>
                <li>水泥</li>
                <li>沙子</li>
                <li>大衣柜</li>
                <li>带裤抽</li>
                <li>抽屉</li>
                <li>烤漆门</li>
                <li>门锁</li>
                <li>门吸</li>
                <li>合页</li>
                <li>门套 </li>
                <li>压条</li>
                <li>局部找平</li>
                <li>水泥</li>
                <li>砂浆</li>
                <li>人工</li>
                <li>插座</li>
                <li>底盒</li>
                <li>开关</li>
                <li>人工</li>
                <li>铺满木地板</li>
                <li>木地板扣条</li>
                <li>收边条</li>
                <li>防潮垫</li>
                <li>胶水</li>
                <li>钉子</li>
                <li>钉子踢脚线</li>
                <li>人工费</li>
                <li>坐便器</li>
                <li>淋雨花洒</li>
                <li>淋雨隔断</li>
                <li>淋雨隔断挡水台</li>
                <li>浴室柜</li>
                <li>上水软管</li>
                <li>角阀</li>
                <li>龙头</li>
                <li>浴室镜</li>
                <li>水电开槽</li>
                <li>线槽粉平</li>
                <li>局部找平</li>
                <li>防水处理</li>
                <li>门槛石</li>
                <li>地漏</li>
                <li>红砖包下水管</li>
                <li>满铺防滑地砖</li>
                <li>墙砖</li>
                <li>防水门</li>
                <li>门锁</li>
                <li>门吸、合页</li>
                <li>门套</li>
                <li>插座</li>
                <li>插座开关</li>
                <li>集成吊顶</li>
                <li>吊筋</li>
                <li>照明模块</li>
                <li>辅料</li>
                <li>油工</li>
                <li>腻子粉</li>
                <li>石膏粉</li>
                <li>砂纸打磨</li>
                <li>乳胶漆</li>
                <li>局部找平</li>
                <li>搬运工</li>
                <li>运输费</li>
                <li>安装费</li>
                <li>自攻钉</li>
                <li>防锈漆</li>
                <li>轻钢龙骨</li>
                <li>吊筋</li>
                <li>主龙骨</li>
                <li>副龙骨</li>
                <li>边骨</li>
                <li>瓦工</li>
                <li>水泥</li>
                <li>黄沙</li>
                <li>木工</li>
                <li>集成吊顶</li>
                <li>吊筋</li>
                <li>照明模块</li>
                <li>毛巾架</li>
                <li>抽纸盒</li>
                <li>皂液器</li>
                <li>五金件</li>
                <li>五金件</li>
                <li>1.5米大床</li>
                <li>床头柜</li>
                <li>1.8米大床</li>
                <li>床屏</li>
                <li>床箱</li>
                <li>水泥</li>
                <li>黄沙</li>
                <li>安装工</li>
                <li>清洁工</li>
                <li>防水</li>
                <li>打压检验</li>
                <li>水管</li>
                <li>电管</li>
                <li>电线</li>
                <li>网线</li>
                <li>有限电视线</li>
                <li>水电工</li>
                <li>辅料</li>
                <li>木工板</li>
                <li>石膏板</li>
                <li>纸绷带</li>
                <li>木工</li>
                <li>集成吊顶</li>
                <li>吊筋</li>
                <li>照明模块</li>
                <li>毛巾架</li>
                <li>抽纸盒</li>
                <li>皂液器</li>
                <li>五金件</li>
                <li>五金件</li>
                <li>床头柜</li>
                <li>大衣柜</li>
                <li>大衣柜</li>
                <li>带裤抽</li>
                <li>抽屉</li>
                <li>烤漆门</li>
                <li>吊筋</li>
                <li>照明模块</li>
                <li>毛巾架</li>
                <li>抽纸盒</li>
                <li>皂液器</li>
                <li>五金件</li>
                <li>1.5米大床</li>
                <li>床头柜</li>
                <li>1.8米大床</li>
                <li>床屏</li>
                <li>床箱</li>
                <li>水泥</li>
                <li>黄沙</li>
                <li>木工</li>
                <li>集成吊顶</li>
                <li>吊筋</li>
                <li>照明模块</li>
                <li>毛巾架</li>
                <li>抽纸盒</li>
                <li>皂液器</li>
                <li>水泥</li>
                <li>黄沙</li>
                <li>木工</li>
                <li>集成吊顶</li>
                <li>吊筋</li>
                <li>照明模块</li>
                <li>毛巾架</li>
                <li>抽纸盒</li>
                <li>皂液器</li>
                <li>五金件</li>
                <li>五金件</li>
                <li>1.5米大床</li>
                <li>床头柜</li>
                <li>1.8米大床</li>
                <li>床屏</li>
                <li>床箱</li>
                <li>水泥</li>
                <li>满铺防滑地砖</li>
                <li>墙砖</li>
                <li>防水门</li>
                <li>门锁</li>
                <li>门吸、合页</li>
                <li>门套</li>
                <li>插座</li>
                <li>插座开关</li>
                <li>集成吊顶</li>
                <li>吊筋</li>
                <li>照明模块</li>
                <li>辅料</li>
                <li>油工</li>
                <li>腻子粉</li>
                <li>石膏粉</li>
                <li>砂纸打磨</li>
                <li>乳胶漆</li>
                <li>局部找平</li>
                <li>搬运工</li>
                <li>运输费</li>
                <li>安装费</li>
                <li>自攻钉</li>
                <li>防锈漆</li>
                <li>轻钢龙骨</li>
                <li>吊筋</li>
                <li>主龙骨</li>
                <li>副龙骨</li>
                <li>边骨</li>
                <li>瓦工</li>
                <li>水泥</li>
                <li>黄沙</li>
                <li>木工</li>
                <li>集成吊顶</li>
                <li>吊筋</li>
                <li>照明模块</li>

                <li>电管</li>
                <li>电线</li>
                <li>螺栓管</li>
                <li>弯头</li>
                <li>线槽粉平</li>
                <li>水泥</li>
                <li>沙子</li>
                <li>大衣柜</li>
                <li>带裤抽</li>
                <li>抽屉</li>
                <li>烤漆门</li>
                <li>门锁</li>
                <li>门吸</li>
                <li>合页</li>
                <li>门套 </li>
                <li>压条</li>
                <li>局部找平</li>
                <li>水泥</li>
                <li>砂浆</li>
                <li>人工</li>
                <li>插座</li>
                <li>底盒</li>
                <li>开关</li>
                <li>人工</li>
                <li>铺满木地板</li>
                <li>木地板扣条</li>
                <li>收边条</li>
                <li>防潮垫</li>
                <li>胶水</li>
                <li>钉子</li>
                <li>钉子踢脚线</li>
                <li>人工费</li>
                <li>坐便器</li>
                <li>淋雨花洒</li>
                <li>淋雨隔断</li>
                <li>淋雨隔断挡水台</li>
                <li>浴室柜</li>
                <li>上水软管</li>
                <li>角阀</li>
                <li>龙头</li>
                <li>浴室镜</li>
                <li>水电开槽</li>
                <li>线槽粉平</li>
                <li>局部找平</li>
                <li>防水处理</li>
                <li>门槛石</li>
                <li>地漏</li>
                <li>红砖包下水管</li>
                <li>满铺防滑地砖</li>
                <li>墙砖</li>
                <li>防水门</li>
                <li>门锁</li>
                <li>门吸、合页</li>
                <li>门套</li>
                <li>插座</li>
                <li>插座开关</li>
                <li>集成吊顶</li>
                <li>吊筋</li>
                <li>照明模块</li>
                <li>辅料</li>
                <li>油工</li>
                <li>腻子粉</li>
                <li>石膏粉</li>
                <li>砂纸打磨</li>
                <li>乳胶漆</li>
                <li>局部找平</li>
                <li>搬运工</li>
                <li>毛巾架</li>
                <li>抽纸盒</li>
                <li>皂液器</li>
                <li>五金件</li>
                <li>五金件</li>
                <li>1.5米大床</li>
                <li>床头柜</li>
                <li>1.8米大床</li>
                <li>床屏</li>
                <li>床箱</li>
                <li>水泥</li>
                <li>黄沙</li>
                <li>安装工</li>
                <li>清洁工</li>
                <li>防水</li>
                <li>打压检验</li>
                <li>水管</li>
                <li>电管</li>
                <li>电线</li>
                <li>网线</li>
                <li>有限电视线</li>
                <li>水电工</li>
                <li>辅料</li>
                <li>木工板</li>
                <li>石膏板</li>
                <li>纸绷带</li>
                <li>木工</li>
                <li>集成吊顶</li>
                <li>吊筋</li>
                <li>照明模块</li>
                <li>毛巾架</li>
                <li>抽纸盒</li>
                <li>皂液器</li>
                <li>五金件</li>
                <li>五金件</li>
                <li>床头柜</li>
                <li>大衣柜</li>
                <li>大衣柜</li>
                <li>带裤抽</li>
                <li>抽屉</li>
                <li>烤漆门</li>
                <li>吊筋</li>
                <li>照明模块</li>
                <li>毛巾架</li>
                <li>抽纸盒</li>
                <li>皂液器</li>
                <li>五金件</li>
                <li>1.5米大床</li>
                <li>床头柜</li>
                <li>1.8米大床</li>
                <li>床屏</li>
                <li>床箱</li>
                <li>水泥</li>
                <li>黄沙</li>
                <li>木工</li>
                <li>集成吊顶</li>
                <li>吊筋</li>
                <li>照明模块</li>
                <li>毛巾架</li>
                <li>抽纸盒</li>
                <li>皂液器</li>
                <li>地漏</li>
                <li>红砖包下水管</li>
                <li>满铺防滑地砖</li>
                <li>墙砖</li>
                <li>防水门</li>
                <li>门锁</li>
                <li>门吸、合页</li>
                <li>门套</li>
                <li>插座</li>
                <li>插座开关</li>
                <li>集成吊顶</li>
                <li>吊筋</li>
                <li>照明模块</li>
                <li>辅料</li>
                <li>油工</li>
                <li>腻子粉</li>
                <li>石膏粉</li>
                <li>砂纸打磨</li>
                <li>乳胶漆</li>
                <li>局部找平</li>
                <li>搬运工</li>
                <li>运输费</li>
                <li>安装费</li>
                <li>自攻钉</li>
                <li>防锈漆</li>
                <li>轻钢龙骨</li>
                <li>吊筋</li>
                <li>主龙骨</li>
                <li>副龙骨</li>
                <li>边骨</li>
                <li>瓦工</li>
                <li>水泥</li>
                <li>黄沙</li>
                <li>木工</li>
                <li>集成吊顶</li>
                <li>吊筋</li>
                <li>照明模块</li>
                <li>毛巾架</li>
                <li>抽纸盒</li>
                <li>皂液器</li>
                <li>五金件</li>
                <li>五金件</li>
                <li>1.5米大床</li>
                <li>床头柜</li>
                <li>1.8米大床</li>
                <li>床屏</li>
                <li>床箱</li>
                <li>水泥</li>
                <li>黄沙</li>
                <li>安装工</li>
                <li>清洁工</li>
                <li>防水</li>
                <li>打压检验</li>
                <li>水管</li>
                <li>电管</li>
                <li>电线</li>
                <li>网线</li>
                <li>有限电视线</li>
                <li>水电工</li>
                <li>辅料</li>
                <li>木工板</li>
                <li>石膏板</li>
                <li>纸绷带</li>
                <li>木工</li>
                <li>集成吊顶</li>
                <li>吊筋</li>
                <li>照明模块</li>
                <li>毛巾架</li>
                <li>抽纸盒</li>
                <li>皂液器</li>
                <li>五金件</li>
                <li>五金件</li>
                <li>床头柜</li>
                <li>大衣柜</li>
                <li>大衣柜</li>
                <li>带裤抽</li>
                <li>抽屉</li>
                <li>烤漆门</li>
                <li>吊筋</li>
                <li>照明模块</li>
                <li>毛巾架</li>
                <li>抽纸盒</li>
                <li>皂液器</li>
                <li>五金件</li>
                <li>1.5米大床</li>
                <li>床头柜</li>
                <li>1.8米大床</li>
                <li>床屏</li>
                <li>床箱</li>
                <li>水泥</li>
                <li>黄沙</li>
                <li>木工</li>
                <li>集成吊顶</li>
                <li>吊筋</li>
                <li>照明模块</li>
                <li>毛巾架</li>
                <li>抽纸盒</li>
                <li>皂液器</li>
                <li>水泥</li>
                <li>黄沙</li>
                <li>木工</li>
                <li>1.8米大床</li>
                <li>床屏</li>
                <li>床箱</li>
                <li>床头柜</li>
                <li>大衣柜</li>
                <li>单开</li>
                <li>单开</li>
                <li>双开</li>
                <li>单开双控</li>
                <li>水电开槽</li>
                <li>水管</li>
                <li>电管</li>
                <li>电线</li>
                <li>螺栓管</li>
                <li>弯头</li>
                <li>线槽粉平</li>
                <li>水泥</li>
                <li>沙子</li>
                <li>人工</li>
                <li>铺满木地板</li>
                <li>木地板扣条</li>
                <li>收边条</li>
                <li>防潮垫</li>
                <li>胶水</li>
                <li>钉子</li>
                <li>钉子踢脚线</li>
                <li>人工费</li>
                <li>床头柜</li>
                <li>大衣柜</li>
                <li>实木复合免漆门</li>
                <li>一张餐桌</li>
                <li>六把餐椅</li>
                <li>六把餐椅</li>
                <li>主照明</li>
                <li>筒灯</li>
                <li>筒灯</li>
                <li>毛巾架</li>
                <li>抽纸盒</li>
                <li>皂液器</li>
                <li>五金件</li>
                <li>五金件</li>
                <li>1.5米大床</li>
                <li>床头柜</li>
                <li>1.8米大床</li>
                <li>床屏</li>
                <li>床箱</li>
                <li>床头柜</li>
                <li>大衣柜</li>
                <li>大衣柜</li>
                <li>带裤抽</li>
                <li>抽屉</li>
                <li>烤漆门</li>
                <li>门锁</li>
                <li>门吸</li>
                <li>合页</li>
                <li>门套 </li>
                <li>压条</li>
                <li>局部找平</li>
                <li>水泥</li>
                <li>砂浆</li>
                <li>人工</li>
                <li>插座</li>
                <li>底盒</li>
                <li>开关</li>
                <li>双开</li>
                <li>单开双控</li>
                <li>水电开槽</li>
                <li>水管</li>
                <li>运输费</li>
                <li>安装费</li>
                <li>自攻钉</li>
                <li>防锈漆</li>
                <li>轻钢龙骨</li>
                <li>吊筋</li>
                <li>主龙骨</li>
                <li>副龙骨</li>
                <li>边骨</li>
                <li>瓦工</li>
                <li>水泥</li>
                <li>黄沙</li>
                <li>木工</li>
                <li>集成吊顶</li>
                <li>吊筋</li>
                <li>照明模块</li>
                <li>毛巾架</li>
                <li>抽纸盒</li>
                <li>皂液器</li>
                <li>五金件</li>
                <li>五金件</li>
                <li>1.5米大床</li>
                <li>床头柜</li>
                <li>1.8米大床</li>
                <li>床屏</li>
                <li>床箱</li>
                <li>水泥</li>
                <li>黄沙</li>
                <li>安装工</li>
                <li>清洁工</li>
                <li>防水</li>
                <li>打压检验</li>
                <li>水管</li>
                <li>电管</li>
                <li>电线</li>
                <li>网线</li>
                <li>有限电视线</li>
                <li>水电工</li>
                <li>辅料</li>
                <li>木工板</li>
                <li>石膏板</li>
                <li>纸绷带</li>
                <li>木工</li>
                <li>集成吊顶</li>
                <li>吊筋</li>
                <li>照明模块</li>
                <li>毛巾架</li>
                <li>抽纸盒</li>
                <li>皂液器</li>
                <li>五金件</li>
                <li>床头柜</li>
                <li>大衣柜</li>

            </ul>
        </div>


        <div class="center">
            <img src="/static/index/static/images/index/section3_item02.png" alt="字" class="wow zoomInDown">
            <h2>人工、基材、主材、家具连水龙头都包了</h2>
            <h4>不让您多买一粒沙一颗钉</h4>
        </div>
        <div class="center">
            <img src="/static/index/static/images/index/section3_item01.png" alt="床" class="animated infinite bounce">
        </div>
        <div class="center">
            <img src="/static/index/static/images/index/section3_item03.png" alt="光" class="animated infinite flash">
        </div>

    </div>

    <!--白皮书-->
    <div class="section section4 hidden-xs" >
        <div class="container">
            <div class="center">
                <div class="row">
                    <img src="/static/index/static/images/index/section4_item09.png" alt="" class="animated infinite flip">
                </div>
                <div id="r1">
                    <img src="/static/index/static/images/index/section4_item02.png" alt="" >
                </div>
            </div>
            <br>
            <div class="row center">
                <p>盛腾按 <b>白皮书ISO9001规范施工</b></p>
                <p>施工为设计效果保驾护航</p>
            </div>
            <br>
            <div class="row section4_hover">
                <div class="col-sm-4"><img src="/static/index/static/images/index/section4_item04.png" alt=""></div>
                <div class="col-sm-4"><img src="/static/index/static/images/index/section4_item05.png" alt=""></div>
                <div class="col-sm-4"><img src="/static/index/static/images/index/section4_item06.png" alt=""></div>
            </div>
            <div class="row section4_hover">
                <div class="col-sm-4 col-sm-offset-2"><img src="/static/index/static/images/index/section4_item07.png" alt=""></div>
                <div class="col-sm-6"><img src="/static/index/static/images/index/section4_item08.png" alt=""></div>
            </div>
        </div>
    </div>

    <!--大牌联手 品质升级-->
    <div class="section section5 hidden-xs">
        <img src="/static/index/static/images/index/section5_item01.png" alt="大牌联手、品质升级" class="active">
    </div>
</div>
<!--pc 端显示的内容 结束-->

<!--公共模块 section 结束-->

<!--公共模块 footer 开始-->
    <footer class="hidden-xs">
    <div class="container">
        <div class="row">
            <div class="col-sm-6 col-xs-12 clearfix">
                <div class="col-sm-4 col-xs-6">
                    <ul>
                        <li>服务流程</li>
                        <li><a href="">免费预约</a></li>
                        <li><a href="">到店体验</a></li>
                        <li><a href="">量房设计</a></li>
                        <li><a href="">签订合同</a></li>
                        <li><a href="">精准施工</a></li>
                        <li><a href="">竣工验收</a></li>
                        <li><a href="">无忧售后</a></li>
                    </ul>
                </div>
                <div class="col-sm-4 col-xs-6">
                    <ul>
                        <li>服务流程</li>
                        <li><a href="">免费预约</a></li>
                        <li><a href="">到店体验</a></li>
                        <li><a href="">量房设计</a></li>
                        <li><a href="">签订合同</a></li>
                        <li><a href="">精准施工</a></li>
                        <li><a href="">竣工验收</a></li>
                        <li><a href="">无忧售后</a></li>
                    </ul>
                </div>
                <div class="col-sm-4 col-xs-6 hidden-xs">
                    <ul>
                        <li>服务流程</li>
                        <li><a href="">免费预约</a></li>
                        <li><a href="">到店体验</a></li>
                        <li><a href="">量房设计</a></li>
                        <li><a href="">签订合同</a></li>
                        <li><a href="">精准施工</a></li>
                        <li><a href="">竣工验收</a></li>
                        <li><a href="">无忧售后</a></li>
                        </ul>
                </div>
            </div>
            <div class="col-sm-6 col-xs-12">
                <div class="col-sm-4 col-xs-6">
                    <img src="/static/index/static/images/index/wechat01.png" alt="">
                    <p class="center">官方微信</p>
                </div>
                <div class="col-sm-4 col-xs-6">
                    <img src="/static/index/static/images/index/wechat02.png" alt="">
                    <p class="center">盛腾家装商城</p>
                </div>
            </div>
        </div>
        <hr>
        <p class="center">版权所有© 安徽盛腾装饰设计有限公司  皖ICP备17004315号 <script type="text/javascript">var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.write(unescape("%3Cspan id='cnzz_stat_icon_1272836750'%3E%3C/span%3E%3Cscript src='" + cnzz_protocol + "s13.cnzz.com/z_stat.php%3Fid%3D1272836750%26show%3Dpic' type='text/javascript'%3E%3C/script%3E"));</script></p>

    </div>

</footer>

<!--手机端底部tab 开始-->
    <div class="visible-xs">
            <div class="col-xs-12 center bottom_tab">
                <ul class="clearfix">
                    <li class="pull-left active"><a href="<?php echo url('Index/index'); ?>"><div><img src="/static/index/static/images/index/home.png" alt=""></div><div class="center title">首页</div></a></li>
                    <li class="pull-left"><a href="<?php echo url('activity/mobile'); ?>"><div><img src="/static/index/static/images/index/gift.png" alt=""></div><div class="center title">活动</div></a></li>
                    <li class="pull-left"><a href="#"><div class="message img-circle"><img class="animated flash" src="/static/index/static/images/index/message.png" alt="消息"><span class="point"></span></div></a></li>
                    <li class="pull-left"><a href="<?php echo url('Index/free_design'); ?>"><div><img src="/static/index/static/images/index/design.png" alt=""></div><div class="center title">免费设计</div></a></li>
                    <li class="pull-left"><a href="tel:0551-65660788"><div><img src="/static/index/static/images/index/tel.png" alt=""></div><div class="center title">拨打电话</div></a></li>
                </ul>
            </div>
    </div>
<!--手机端底部tab 结束-->

<!--底部悬浮 点击可弹出报价 结束-->
<!--底部弹出报价 开始-->
<div class="quotation hidden-xs">
    <div class="container">
        <div class="row center">
            <img src="/static/index/static/images/comm/quotation_down.png" alt="" class="animated infinite bounce close_quotation">
            <p class="center"><span class="red-font">0</span>&nbsp;元 预约设计免费抢</p>
        </div>
        <br>
        <div class="row">
            <form onsubmit="return footer_submit_form()" class="form-horizontal clearfix text-c" role="form" id="footer_form">
                <div class="col-sm-2 col-sm-offset-1">
                    <select class="form-control input-lg" name="address" required title="选择城市" style="width: 100%">
                        <option>选择城市</option>
                        <option value="合肥">合肥</option>
                        <option value="蚌埠">蚌埠</option>
                        <option value="石家庄">石家庄</option>
                        <option value="杭州">杭州</option>
                        <option value="呼和浩特">呼和浩特</option>
                        <option value="西安">西安</option>
                        <option value="石家庄">石家庄</option>
                        <option value="其他">其他</option>
                    </select>
                </div>

                <div class="col-sm-2">
                    <div class="input-group input-group-lg">
                        <input type="text" minlength="2" class="form-control" placeholder="房屋面积&nbsp;m2" name="area" required>
                    </div>
                </div>
                <div class="col-sm-2">
                    <div class="input-group input-group-lg">
                        <input type="text" minlength="2" class="form-control" placeholder="您的姓名" name="name" required>
                    </div>
                </div>
                <div class="col-sm-2">
                    <div class="input-group input-group-lg">
                        <input type="text" minlength="11" class="form-control" placeholder="您的电话" name="tel" required>
                    </div>
                </div>


                <div class="col-sm-2">
                    <button  class="btn btn-lg btn-danger" type="submit" id="footer_btn_order">立即报名</button>
                </div>
                <input type="hidden" name="from" value="PC">
                <input type="hidden" name="remark" value="底部报价">
            </form>
        </div>
    </div>


</div>
<!--底部弹出报价 结束-->

<!--右侧侧边栏 开始-->
<div class="float_right_menu hidden-xs">
    <div id="logo">
        <img src="/static/index/static/images/comm/logo.png" alt="盛腾logo">
    </div>
    <ul class="clearfix">
        <li>快速导航</li>
        <li id="OnlineConsultation"><div class="center"><img src="/static/index/static/images/comm/slide_right-item02.png" alt="在线咨询"></div>在线咨询</li>
        <li data-toggle="modal" data-target="#myModal"><div class="center"><img src="/static/index/static/images/comm/slide_right-item03.png" alt="预约装修"></div>预约装修</li>
        <li data-toggle="modal" data-target="#myModal"><div class="center"><img src="/static/index/static/images/comm/slide_right-item04.png" alt="免费报价"></div>免费报价</li>
        <li><div class="center"><img src="/static/index/static/images/comm/slide_right-item05.png" alt="返回顶部"></div>返回顶部</li>

    </ul>
</div>
<!--右侧侧边栏 结束-->

<!--弹出模态框 开始-->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                    &times;
                </button>
                <h2 class="modal-title center" id="myModalLabel">
                    预约报名
                </h2>
            </div>
            <div class="modal-body">
                    <form onsubmit="return modal_form()" class="form-horizontal" role="form" id="modal_form" method="post">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label for="name"  type="name" class="col-sm-3 control-label">您的姓名：</label>
                                    <div class="col-sm-8">
                                        <input type="text" minlength="2" class="form-control" id="name" placeholder="您的姓名" name="name" required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="name" class="col-sm-3 control-label">小区名称：</label>
                                    <div class="col-sm-8">
                                        <input type="text" minlength="2"   class="form-control" id="address" placeholder="小区名称" name="address" required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="name" class="col-sm-3 control-label">装修面积：</label>
                                    <div class="col-sm-8">
                                        <input type="text" minlength="2"  class="form-control" id="area" placeholder="装修面积 ㎡" name="area" required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="name" class="col-sm-3 control-label">联系电话：</label>
                                    <div class="col-sm-8">
                                        <input type="tel" minlength="11"   class="form-control" id="tel" placeholder="联系电话" name="tel" required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-md-12">
                                        <p class="bg-success" style="padding: 5px;">我们将会对您的信息进行严格保密，请放心提交!</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <br>
                        <div class="row">
                            <div class="col-sm-12">
                                <p class="text"><button type="submit" class="btn btn-lg btn-danger btn-block" id="modal_form_btn">马上预约</button></p>
                            </div>
                        </div>
                        <input type="hidden" name="from" value="PC">
                        <input type="hidden" name="remark" value="弹出模态框">
                    </form>
            </div>

        </div>
    </div>
</div>
    <!--弹出模态框 结束-->
<!--引入CDN-->
<script src="https://cdn.bootcss.com/jquery/3.2.1/jquery.min.js"></script>
<script src="http://cdn.static.runoob.com/libs/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<!--wow.js 依赖animated.css 滑动位置触发动画库-->
<script src="https://cdn.bootcss.com/wow/1.1.2/wow.min.js"></script>
<script src="http://static.runoob.com/assets/jquery-validation-1.14.0/dist/jquery.validate.min.js"></script>
<script src="http://static.runoob.com/assets/jquery-validation-1.14.0/dist/localization/messages_zh.js"></script>
<!--图标css-->
<link href="https://cdn.bootcss.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
<!--百度商桥 开始-->
<script>
    var _hmt = _hmt || [];
    (function() {
        var hm = document.createElement("script");
        hm.src = "https://hm.baidu.com/hm.js?5cbf9a484044f67aa33310ccaab66f91";
        var s = document.getElementsByTagName("script")[0];
        s.parentNode.insertBefore(hm, s);
    })();
</script>

<!--百度商桥 结束-->

<!--百度推送 开始-->
<script>
    (function(){
        var bp = document.createElement('script');
        var curProtocol = window.location.protocol.split(':')[0];
        if (curProtocol === 'https') {
            bp.src = 'https://zz.bdstatic.com/linksubmit/push.js';
        }
        else {
            bp.src = 'http://push.zhanzhang.baidu.com/push.js';
        }
        var s = document.getElementsByTagName("script")[0];
        s.parentNode.insertBefore(bp, s);
    })();
</script>
<!--百度推送 结束-->
<!--360推送-->
<script>(function(){
    var src = (document.location.protocol == "http:") ? "http://js.passport.qihucdn.com/11.0.1.js?36f8e7ad6866e1a44dab6f0af5ac4de7":"https://jspassport.ssl.qhimg.com/11.0.1.js?36f8e7ad6866e1a44dab6f0af5ac4de7";
    document.write('<script src="' + src + '" id="sozz"><\/script>');
})();
</script>

<!--公共页面通用js-->
<!--顶部 banner 动画-->
<script src="/static/index/lib/js/slide_banner.js"></script>

<script>
    // 底部弹出报价
    $('#alert-order-btn').click(function () {
        $('#alert-order-btn').hide();
        $('.quotation').fadeIn();
    });

    // 隐藏底部报价
    $('.quotation .close_quotation').click(function () {
        $('.quotation').fadeOut();
        $('#alert-order-btn').show();
    });

    //返回顶部
    $('.float_right_menu ul li:last').click(function () {
        $("html,body").animate({scrollTop:0}, 800);
    });

    //底部提交用户预约设计信息
    function footer_submit_form() {
        $.ajax({
            type: "POST",
            url: "<?php echo url('Index/orderAdd'); ?>",
            data : $("#footer_form").serialize(),
            beforeSend:function(){
                $('#footer_form').attr('onsubmit','return false;');
                $('#footer_btn_order').html("数据提交中...");
            },
            success: function(data) {
                alert(data.msg);
                $('#footer_btn_order').html("预约成功").removeClass('btn-danger').addClass('btn-success');
            },
            error:function (data) {
                alert(data.msg);
            }
        });
        return false;
    }


    //右侧提交用户预约设计信息
    function submit_form() {
        $.ajax({
            type: "POST",
            url: "<?php echo url('Index/orderAdd'); ?>",
            data : $("#selected_case_detail_form").serialize(),
            beforeSend:function(){
                $('#selected_case_detail_form').attr('onsubmit','return false;');
                $('#selected_case_detail_btn_order').html("数据提交中...");
            },
            success: function(data) {
                alert(data.msg);
                $('#selected_case_detail_btn_order').html("预约成功").removeClass('btn-danger').addClass('btn-success');
            },
            error:function (data) {
                alert(data.msg);
            }
        });
        return false;
    }

    //模态框表单验证
    $('#myModal').validate();
    //模态框提交预约信息
    function modal_form() {
        $.ajax({
            type: "POST",
            url: "<?php echo url('Index/orderAdd'); ?>",
            data : $("#modal_form").serialize(),
            beforeSend:function(){
                $('#modal_form').attr('onsubmit','return false;');
                $('#modal_form_btn').html("数据提交中...");
            },
            success: function(data) {
                alert(data.msg);
                $('#modal_form_btn').html("预约成功").removeClass('btn-danger').addClass('btn-success');
            },
            error:function (data) {
                alert(data.msg);
            }
        });
        return false;
    }

    /**
     * 截取url参数方法
     * @description 参数 name 为url 参数名
     */
    function getQueryString(name) {
        var reg = new RegExp('(^|&)' + name + '=([^&]*)(&|$)', 'i');
        var r = window.location.search.substr(1).match(reg);
        if (r != null) {
            return unescape(r[2]);
        }
        return null;
    }

    //点击在线咨询
    $('#OnlineConsultation, .livechat-girl , .message, .get-ticket,.order_design').click(function () {
        $('#nb_icon_wrap').click();
    });

    $('#nb_icon_wrap').css('opacity','0');


    $('.livechat-girl').hover(function () {
        $('.livechat-hint').removeClass('hide_hint').addClass('show_hint');
    },function () {
        $('.livechat-hint').addClass('hide_hint').removeClass('show_hint');
    });

    //    左侧咨询按钮动画
    $(function(){
        function hide() {
            $('.animated-circles').removeClass('animated');
        }
        function show(){
            $('.animated-circles').addClass('animated');
        }
        setInterval(show,3000);
        setInterval(hide,6000);
    });
    
//    返回上一页
    $('.go-back').click(function () {
        history.back();
    });

//    底部点击active 样式
    $('.bottom_tab ul li').click(function () {
        var i = $(this).index();
        localStorage.setItem('cur-bottom_tab',i);
    });

    if (localStorage.getItem('cur-bottom_tab') !== null){
        var i = localStorage.getItem('cur-bottom_tab');
        $('.bottom_tab ul li').eq(i).addClass('active').siblings().removeClass('active');
    }

</script>
<!--公共模块 footer 结束-->

<!--业务相关 js 开始-->
    
<script>
    $(document).ready(function () {
        $('.section4_hover img').addClass('wow bounceInLeft');
        $('.section5_hover img').addClass('wow rotateIn');

        // 初始化wow 动画
        new WOW().init();


//        随机整数
        function rnd(n, m){
            var random = Math.floor(Math.random()*(m-n+1)+n);
            return random;
        }


        var section3 = jQuery('.section3').offset().top - 1000;

        $(window).scroll(function(){
            if ($(document).scrollTop() > section3){
                var li = $(".section3 ul li");
                li.eq(rnd(0,li.length)).addClass("active animated flash infinite");
                li.eq(rnd(0,li.length)).addClass("active animated flash infinite");
                li.eq(rnd(0,li.length)).addClass("active animated flash infinite");
                li.eq(rnd(0,li.length)).addClass("active animated flash infinite");

                // setInterval(function () {
                //
                // },2000);

                // setInterval(function () {
                //     li.eq(rnd(0,li.length)).css("color","rgba(255,255,255,.15)");
                // },700);
            }
    });

        //section4 白皮书 鼠标经过 动画
        $('.section4_hover img,.section5_hover img').hover(function () {
            $(this).removeAttr("style");
            $(this).removeClass('wow bounceInLeft');
            $(this).removeClass('wow rotateIn');
            $(this).addClass('animated pulse');
        },function () {
            $(this).removeClass('animated pulse');
        });


        //section1 选择电视节目媒体（Tab切换）
        $('.section1 ul li').click(function () {
            $('video').trigger('pause');
            var imgArray_active = [
                "/static/index/static/images/index/anhuiTv-active.png","/static/index/static/images/index/zhejiangTv-active.png",
                "/static/index/static/images/index/education_technology-active.png",
                "/static/index/static/images/index/yantaiTv-active.png","/static/index/static/images/index/bengbuTv-active.png",
                "/static/index/static/images/index/hebeiTv-active.png","/static/index/static/images/index/neimengguTv-active.png"
            ];
            var imgArray = [
                "/static/index/static/images/index/anhuiTv.png","/static/index/static/images/index/zhejiangTv.png",
                "/static/index/static/images/index/education_technology.png",
                "/static/index/static/images/index/yantaiTv.png","/static/index/static/images/index/bengbuTv.png",
                "/static/index/static/images/index/hebeiTv.png","/static/index/static/images/index/neimengguTv.png"
            ];
            var i = $(this).index();//定义下标
            $(this).addClass("active").siblings().removeClass("active");//当前点击添加 active 类,其余兄弟元素移除 active 类
            $('#tvShow').find('video').eq(i).show().siblings().hide();//显示当前Tab对应的 video ，其他隐藏
            $('.section1 ul li').eq(i).find('img').attr('src',imgArray_active[i]);


            switch (i) {
                case 0:
                    $('.section1 ul li').eq(1).find('img').attr('src',imgArray[1]);
                    $('.section1 ul li').eq(2).find('img').attr('src',imgArray[2]);
                    $('.section1 ul li').eq(3).find('img').attr('src',imgArray[3]);
                    $('.section1 ul li').eq(4).find('img').attr('src',imgArray[4]);
                    $('.section1 ul li').eq(5).find('img').attr('src',imgArray[5]);
                    $('.section1 ul li').eq(6).find('img').attr('src',imgArray[6]);
                    break;

                case 1:
                    $('.section1 ul li').eq(0).find('img').attr('src',imgArray[0]);
                    $('.section1 ul li').eq(2).find('img').attr('src',imgArray[2]);
                    $('.section1 ul li').eq(3).find('img').attr('src',imgArray[3]);
                    $('.section1 ul li').eq(4).find('img').attr('src',imgArray[4]);
                    $('.section1 ul li').eq(5).find('img').attr('src',imgArray[5]);
                    $('.section1 ul li').eq(6).find('img').attr('src',imgArray[6]);
                    break;

                case 2:
                    $('.section1 ul li').eq(0).find('img').attr('src',imgArray[0]);
                    $('.section1 ul li').eq(1).find('img').attr('src',imgArray[1]);
                    $('.section1 ul li').eq(3).find('img').attr('src',imgArray[3]);
                    $('.section1 ul li').eq(4).find('img').attr('src',imgArray[4]);
                    $('.section1 ul li').eq(5).find('img').attr('src',imgArray[5]);
                    $('.section1 ul li').eq(6).find('img').attr('src',imgArray[6]);

                    break;

                case 3:
                    $('.section1 ul li').eq(0).find('img').attr('src',imgArray[0]);
                    $('.section1 ul li').eq(1).find('img').attr('src',imgArray[1]);
                    $('.section1 ul li').eq(2).find('img').attr('src',imgArray[2]);
                    $('.section1 ul li').eq(4).find('img').attr('src',imgArray[4]);
                    $('.section1 ul li').eq(5).find('img').attr('src',imgArray[5]);
                    $('.section1 ul li').eq(6).find('img').attr('src',imgArray[6]);
                    break;

                case 4:
                    $('.section1 ul li').eq(0).find('img').attr('src',imgArray[0]);
                    $('.section1 ul li').eq(1).find('img').attr('src',imgArray[1]);
                    $('.section1 ul li').eq(2).find('img').attr('src',imgArray[2]);
                    $('.section1 ul li').eq(3).find('img').attr('src',imgArray[3]);
                    $('.section1 ul li').eq(5).find('img').attr('src',imgArray[5]);
                    $('.section1 ul li').eq(6).find('img').attr('src',imgArray[6]);
                    break;

                case 5:
                    $('.section1 ul li').eq(0).find('img').attr('src',imgArray[0]);
                    $('.section1 ul li').eq(1).find('img').attr('src',imgArray[1]);
                    $('.section1 ul li').eq(2).find('img').attr('src',imgArray[2]);
                    $('.section1 ul li').eq(3).find('img').attr('src',imgArray[3]);
                    $('.section1 ul li').eq(4).find('img').attr('src',imgArray[4]);
                    $('.section1 ul li').eq(6).find('img').attr('src',imgArray[6]);
                    break;

                case 6:
                    $('.section1 ul li').eq(0).find('img').attr('src',imgArray[0]);
                    $('.section1 ul li').eq(1).find('img').attr('src',imgArray[1]);
                    $('.section1 ul li').eq(2).find('img').attr('src',imgArray[2]);
                    $('.section1 ul li').eq(3).find('img').attr('src',imgArray[3]);
                    $('.section1 ul li').eq(4).find('img').attr('src',imgArray[4]);
                    $('.section1 ul li').eq(5).find('img').attr('src',imgArray[5]);
                    break;
                default:
                    break;
            }

        });

        //section5 图片自动播放
        var imgArray = ["/static/index/static/images/index/section5_item02.png", "/static/index/static/images/index/section5_item01.png"];
        var index=0;
        setInterval(function(){
            $(".section5 img").attr("src",imgArray[index]);
            if(index>=imgArray.length){
                index=0;
            }
            else{
                index++;
            }
        },3000);


    });
</script>


<!--业务相关 js 结束-->
</body>
</html>