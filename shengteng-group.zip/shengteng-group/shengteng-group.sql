/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50165
Source Host           : localhost:3306
Source Database       : shengteng-group

Target Server Type    : MYSQL
Target Server Version : 50165
File Encoding         : 65001

Date: 2018-01-05 16:56:39
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for tbl_auth_group
-- ----------------------------
DROP TABLE IF EXISTS `tbl_auth_group`;
CREATE TABLE `tbl_auth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` char(100) NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `rules` char(80) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tbl_auth_group
-- ----------------------------
INSERT INTO `tbl_auth_group` VALUES ('1', '创始人', '1', '7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29');
INSERT INTO `tbl_auth_group` VALUES ('2', '设计部', '1', '11,12,15,16,19,29');

-- ----------------------------
-- Table structure for tbl_auth_group_access
-- ----------------------------
DROP TABLE IF EXISTS `tbl_auth_group_access`;
CREATE TABLE `tbl_auth_group_access` (
  `uid` mediumint(8) unsigned NOT NULL,
  `group_id` mediumint(8) unsigned NOT NULL,
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`),
  KEY `uid` (`uid`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tbl_auth_group_access
-- ----------------------------
INSERT INTO `tbl_auth_group_access` VALUES ('1001', '1');
INSERT INTO `tbl_auth_group_access` VALUES ('1002', '2');

-- ----------------------------
-- Table structure for tbl_auth_rule
-- ----------------------------
DROP TABLE IF EXISTS `tbl_auth_rule`;
CREATE TABLE `tbl_auth_rule` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(80) NOT NULL DEFAULT '',
  `title` char(20) NOT NULL DEFAULT '',
  `type` tinyint(1) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `condition` char(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tbl_auth_rule
-- ----------------------------
INSERT INTO `tbl_auth_rule` VALUES ('7', 'WebsiteSetting-website_seo', '网站 seo 信息', '1', '1', '');
INSERT INTO `tbl_auth_rule` VALUES ('8', 'WebsiteSetting-all_shops_list', '全国门店列表', '1', '1', '');
INSERT INTO `tbl_auth_rule` VALUES ('10', 'WebsiteSetting-edit_shop_information', '修改门店信息', '1', '1', '');
INSERT INTO `tbl_auth_rule` VALUES ('9', 'WebsiteSetting-add_shop', '新增门店', '1', '1', '');
INSERT INTO `tbl_auth_rule` VALUES ('11', 'WebsiteSetting-decoration_case_list', '装修案例列表', '1', '1', '');
INSERT INTO `tbl_auth_rule` VALUES ('12', 'WebsiteSetting-add_decoration_case', '添加装修案例', '1', '1', '');
INSERT INTO `tbl_auth_rule` VALUES ('13', 'WebsiteSetting-edit_decoration_case', '编辑装修案例', '1', '1', '');
INSERT INTO `tbl_auth_rule` VALUES ('14', 'WebsiteSetting-del_decoration_case', '删除装修案例', '1', '1', '');
INSERT INTO `tbl_auth_rule` VALUES ('15', 'WebsiteSetting-designer_list', '设计师列表', '1', '1', '');
INSERT INTO `tbl_auth_rule` VALUES ('16', 'WebsiteSetting-add_designer', '添加设计师', '1', '1', '');
INSERT INTO `tbl_auth_rule` VALUES ('17', 'WebsiteSetting-edit_designer', '修改设计师信息', '1', '1', '');
INSERT INTO `tbl_auth_rule` VALUES ('18', 'WebsiteSetting-del_designer', '删除设计师', '1', '1', '');
INSERT INTO `tbl_auth_rule` VALUES ('19', 'Index-index', '后台首页', '1', '1', '');
INSERT INTO `tbl_auth_rule` VALUES ('20', 'DataCenter-order_manager', '预约订单列表', '1', '1', '');
INSERT INTO `tbl_auth_rule` VALUES ('21', 'DataCenter-orderAdd', '来自客户预约报名', '1', '1', '');
INSERT INTO `tbl_auth_rule` VALUES ('22', 'DataCenter-delOrderById', '客户预约订单删除', '1', '1', '');
INSERT INTO `tbl_auth_rule` VALUES ('23', 'NewsManager-menu_manager_news', '新闻动态列表', '1', '1', '');
INSERT INTO `tbl_auth_rule` VALUES ('24', 'NewsManager-article_add_page', '添加新闻 OR 百科 页面', '1', '1', '');
INSERT INTO `tbl_auth_rule` VALUES ('25', 'NewsManager-insert_news', '写入新闻 OR 百科 到数据库', '1', '1', '');
INSERT INTO `tbl_auth_rule` VALUES ('26', 'NewsManager-delNewsById', '删除新闻 OR 百科', '1', '1', '');
INSERT INTO `tbl_auth_rule` VALUES ('27', 'NewsManager-article_edit_page', '修改新闻页面', '1', '1', '');
INSERT INTO `tbl_auth_rule` VALUES ('28', 'NewsManager-update_news', '处理新闻修改', '1', '1', '');
INSERT INTO `tbl_auth_rule` VALUES ('29', 'WebsiteSetting-is_Exist_Designer', '判断用户输入的设计师是否存在', '1', '1', '');

-- ----------------------------
-- Table structure for tbl_baike
-- ----------------------------
DROP TABLE IF EXISTS `tbl_baike`;
CREATE TABLE `tbl_baike` (
  `id` int(30) NOT NULL AUTO_INCREMENT COMMENT '新闻ID',
  `thumbnail` varchar(255) DEFAULT NULL COMMENT '缩略图',
  `title` varchar(50) NOT NULL COMMENT '新闻标题',
  `author` varchar(11) DEFAULT NULL COMMENT '新闻作者',
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `views` char(100) DEFAULT '0' COMMENT '浏览次数',
  `description` varchar(50) DEFAULT NULL COMMENT '新闻简介',
  `content` text COMMENT '新闻内容',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '新闻发布状态',
  `category` varchar(255) DEFAULT NULL COMMENT '百科分类',
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `id_2` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=utf8 COMMENT='装修百科';

-- ----------------------------
-- Records of tbl_baike
-- ----------------------------
INSERT INTO `tbl_baike` VALUES ('14', null, '嘻嘻嘻我的', '死神', '2017-11-07 14:12:26', null, '是是是', '<p>奋斗法法风格备份V的vv个&nbsp;</p>', '1', null);
INSERT INTO `tbl_baike` VALUES ('16', null, '惊呆！大新闻！', '小枫', '2017-11-07 14:37:18', null, '涨工资啦', '<p>工资涨啦！</p><pre class=\"brush:html;toolbar:false\">html\r\nht</pre><p><br/></p>', '1', null);
INSERT INTO `tbl_baike` VALUES ('9', null, '测试文章标题', '作者', '2017-11-07 08:39:33', '2', '文章描述', '<p><strong>大幅度哥哥额而发如果</strong></p>', '1', null);
INSERT INTO `tbl_baike` VALUES ('18', '20171222\\c9fc2972f69af5f7585c6223f2f57263.jpg', '国庆中秋来送礼啦！36件家具家电和黄金免费送！', '是', '2017-11-07 16:53:10', '0', '  心系祖国，情系百姓，在建国68年之际，特供68户优惠名额，百平米整装只需11万元', '<p style=\"white-space: normal; text-align: center;\"><span style=\"font-size: 18px;\">&nbsp;</span></p><p style=\"white-space: normal;\"><span style=\"font-size: 18px; font-family: 宋体;\">这个国庆中秋去哪里？圣托里尼看潮汐，真奢侈！</span></p><p style=\"white-space: normal;\"><span style=\"font-size: 18px;\"><span style=\"font-family: 宋体;\">这个国庆中秋去哪里？</span><span style=\"font-family: 宋体;\">窝在家里看韩剧，真屌丝！</span></span></p><p style=\"white-space: normal;\"><span style=\"font-size: 18px;\"><span style=\"font-family: 宋体;\">这个国庆中秋去哪里？</span><span style=\"font-family: 宋体;\">小区池塘看落叶，真无趣！</span></span></p><p style=\"white-space: normal;\"><span style=\"font-size: 18px;\">&nbsp;</span></p><p style=\"white-space: normal;\"><span style=\"font-size: 18px;\"><span style=\"font-family: 宋体;\">这个国庆中秋去哪里？</span><span style=\"font-family: 宋体;\">去盛腾家装工厂店，真</span>........</span></p><p style=\"white-space: normal;\"><span style=\"font-size: 18px;\">&nbsp;</span></p><p style=\"white-space: normal;\"><span style=\"font-size: 18px;\"><span style=\"font-family: 宋体;\">去哪里？</span><span style=\"font-family: 宋体;\">去盛腾家装啊！</span></span></p><p style=\"white-space: normal;\"><span style=\"font-size: 18px;\">&nbsp;</span></p><p style=\"white-space: normal;\"><span style=\"font-size: 18px;\"><span style=\"font-family: 宋体;\">喜逢佳节，装修还能抢黄金，从</span>24<span style=\"font-family: 宋体;\">号开始，每天都有黄金抽，这么好的事情，为什么不去？</span></span></p><p style=\"white-space: normal;\"><span style=\"font-size: 18px;\">&nbsp;</span></p><p style=\"white-space: normal;\"><span style=\"font-size: 18px;\"><span style=\"font-family: 宋体;\">心系祖国，情系百姓，在建国</span>68<span style=\"font-family: 宋体;\">年之际，特供</span>68<span style=\"font-family: 宋体;\">户优惠名额，百平米整装只需</span>11<span style=\"font-family: 宋体;\">万元，这么有爱的公司，为什么不去？</span></span></p><p style=\"white-space: normal;\"><span style=\"font-size: 18px;\">&nbsp;</span></p><p style=\"white-space: normal;\"><span style=\"font-size: 18px;\"><span style=\"font-size: 16px; font-family: 宋体;\">与安徽公共频道合作，</span><span style=\"font-family: 宋体;\">活动当天更有知名主持人亲临现场，由公共频道全程监督，这么正规的活动，为什么不去？</span></span></p><p style=\"white-space: normal;\"><span style=\"font-size: 18px;\">&nbsp;</span></p><p style=\"white-space: normal;\"><span style=\"font-family: 宋体; font-size: 18px;\">当然，这都不算什么！</span></p><p style=\"white-space: normal;\"><span style=\"font-size: 18px;\">&nbsp;</span></p><p style=\"white-space: normal;\"><span style=\"font-size: 18px; font-family: 宋体;\">他们还有一站式全包服务，人工、基材、主材到软装等统统全包，不用你出一份力！</span></p><p style=\"white-space: normal;\"><span style=\"font-size: 18px;\">&nbsp;</span></p><p style=\"white-space: normal;\"><span style=\"font-size: 18px;\"><span style=\"font-family: 宋体;\">他们还有一线大品牌助阵，像西蒙、多乐士等基材，科勒、</span>TOTO<span style=\"font-family: 宋体;\">、东鹏、马可波罗等主材任你选</span></span></p><p style=\"white-space: normal;\"><span style=\"font-size: 18px;\">&nbsp;</span></p><p style=\"white-space: normal;\"><span style=\"font-size: 18px; font-family: 宋体;\">他们还有首席团队设计，装修效果包满意，不让业主多花一分冤枉钱！</span></p><p style=\"white-space: normal;\"><span style=\"font-size: 18px;\">&nbsp;</span></p><p style=\"white-space: normal;\"><span style=\"font-size: 18px;\"><strong><span style=\"font-family: 宋体;\">精装样板房提前看、家装大神亲临指导</span></strong><strong><span style=\"font-family: 宋体;\"></span></strong></span></p><p style=\"white-space: normal;\"><span style=\"font-family: 宋体; font-size: 18px;\">整个装修全程，有人帮你量房、有人帮你看材料、有人帮你跑工地、有人为你画图等都有专业人员为你服务！</span></p><p style=\"white-space: normal;\"><span style=\"font-size: 18px;\">&nbsp;</span></p><p style=\"white-space: normal;\"><span style=\"font-family: 宋体; font-size: 18px;\">不仅如此，更有多种风格的样板房提供观看，总有一款是你的菜！当然，本次活动还有各路家装精兵强将坐镇，软装大师、空间大师、规划大师、色彩大师应有尽有，只为给你打造一个完美的家！</span></p><p style=\"white-space: normal;\"><span style=\"font-size: 18px;\">&nbsp;</span></p><p style=\"white-space: normal;\"><span style=\"font-size: 18px;\"><strong><span style=\"font-family: 宋体;\">成功抢定公益名额的业主，立享三重大礼：</span></strong><strong><span style=\"font-family: 宋体;\"></span></strong></span></p><p style=\"white-space: normal;\"><span style=\"font-size: 18px;\">&nbsp;</span></p><p style=\"white-space: normal;\"><span style=\"font-family: 宋体; font-size: 18px;\">大礼一：百平米整装１１万最后一波机会，抢完价格调整到１２万以上，仅限６８户名额。</span></p><p style=\"white-space: normal;\"><span style=\"font-size: 18px;\">&nbsp;</span></p><p style=\"white-space: normal;\"><span style=\"font-family: 宋体; font-size: 18px;\">大礼二：赠送全房品牌家具：沙发、茶几、电视柜；主卧大床、２床头柜、大衣柜、次卧、大床、２床头柜，大衣柜；餐桌、６把餐椅、书桌、书椅、书柜；斗柜、鞋柜！总共２６件全房家具免费送！</span></p><p style=\"white-space: normal;\"><span style=\"font-size: 18px;\">&nbsp;</span></p><p style=\"white-space: normal;\"><span style=\"font-size: 18px;\"><span style=\"font-family: 宋体;\">大礼三：</span>4k<span style=\"font-family: 宋体;\">液晶电视机、美的智能空调、三开门冰箱、变频滚筒洗衣机、热水器、燃气灶、抽油烟机、电磁炉、电饭煲、微波炉等十大家电免费送！</span></span></p><p style=\"white-space: normal;\"><span style=\"font-size: 18px;\">&nbsp;</span></p><p style=\"white-space: normal;\"><span style=\"font-size: 18px;\"><span style=\"font-family: 宋体;\">顺便提醒一句，此次机会难得，即日起至</span>10<span style=\"font-family: 宋体;\">月</span>3<span style=\"font-family: 宋体;\">号，百平米整装全包</span>11<span style=\"font-family: 宋体;\">万元！</span>3<span style=\"font-family: 宋体;\">号之后将不会再有，价格将调整到</span>12<span style=\"font-family: 宋体;\">万以上！</span></span></p><p style=\"white-space: normal;\"><span style=\"font-size: 18px;\">&nbsp;</span></p><p style=\"white-space: normal;\"><span style=\"font-size: 18px;\"><span style=\"font-family: 宋体;\">还有名额只有</span>68<span style=\"font-family: 宋体;\">户，只有</span>68<span style=\"font-family: 宋体;\">户！只有</span>68<span style=\"font-family: 宋体;\">户！</span></span></p><p style=\"white-space: normal;\"><span style=\"font-size: 18px;\">&nbsp;</span></p><p style=\"white-space: normal;\"><span style=\"font-family: 宋体; font-size: 18px;\">对了，关注公共频道还能抢黄金！抢黄金！抢黄金！现在，抓紧机会报名吧！</span></p><p style=\"white-space: normal;\"><span style=\"font-family: 宋体; font-size: 18px;\"><br/></span></p><p style=\"white-space: normal;\"><span style=\"font-size: 18px; color: rgb(255, 0, 0);\"><strong><span style=\"font-family: 宋体;\">抢定热线：0551-65660788</span></strong><strong><span style=\"font-family: 宋体;\"></span></strong></span></p><p style=\"white-space: normal; text-align: center;\">&nbsp;</p><p><br/></p>', '1', '家装指南');
INSERT INTO `tbl_baike` VALUES ('21', '没有上传过图片', 'DVD', '的', '2017-11-15 17:03:21', '0', '的', '<p>cscscs</p>', '1', null);

-- ----------------------------
-- Table structure for tbl_branch-company
-- ----------------------------
DROP TABLE IF EXISTS `tbl_branch-company`;
CREATE TABLE `tbl_branch-company` (
  `company_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '分公司id',
  `company_name` varchar(20) NOT NULL COMMENT '分公司名称',
  `thumbnail` varchar(255) DEFAULT NULL COMMENT '店面门头图片',
  `address` varchar(60) NOT NULL COMMENT '分公司地址',
  `tel` varchar(30) NOT NULL COMMENT '分公司电话',
  `city` varchar(20) NOT NULL DEFAULT '空' COMMENT '门店所属城市',
  `count_case` varchar(255) DEFAULT '0' COMMENT '案例总数',
  `count_designers` varchar(255) DEFAULT '0' COMMENT '设计师总数',
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '数据创建时间',
  PRIMARY KEY (`company_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='盛腾集团分公司汇总表';

-- ----------------------------
-- Records of tbl_branch-company
-- ----------------------------
INSERT INTO `tbl_branch-company` VALUES ('1', '合肥盛腾家装工厂店', '20180103\\74d7f52a6bc21f2cab67c7709de120d1.png', '合肥市史河路与潜山路交口', '0551-65660788', '合肥', '0', '0', '2018-01-05 11:15:31');
INSERT INTO `tbl_branch-company` VALUES ('2', '蚌埠盛腾家装工厂店', '20180103\\ec39375ac2a902d7b286d43e25ebf7fa.png', '蚌埠市东海大道凤凰国际大厦A座', '0552-7108777  6832233', '蚌埠', '0', '0', '2018-01-04 17:25:40');
INSERT INTO `tbl_branch-company` VALUES ('3', '呼和浩特盛腾家装工厂店', '20180103\\82a35c7b89f156a1bc4247c118fd06ba.png', '呼和浩特新城区哲里木路84号（三十四中南）', '0471-6532200 6532211', '呼和浩特', '2', '1', '2018-01-05 11:14:11');
INSERT INTO `tbl_branch-company` VALUES ('4', '烟台盛腾家装工厂店', '20180103\\1a4608505ae2bc1029745bfb690d1a6b.png', '烟台市南大街与西炮台路交叉口', '0535-3831133 6832233', '烟台', '0', '0', '2018-01-04 17:25:42');
INSERT INTO `tbl_branch-company` VALUES ('5', '石家庄盛腾家装工厂店', '20180103\\2025747056057ae7f6bcb52cfce3274d.png', '桥西区中山路与休门街交叉口向南', '0311-86833688 86833988', '石家庄', '0', '0', '2018-01-04 16:17:29');
INSERT INTO `tbl_branch-company` VALUES ('6', '西安盛腾家装工厂店', '20180103\\7e3f9b72eb10b1505aa31191065e9f6c.png', '西安市南二环太白立交桥西北角', '0311-86833688 86833988', '西安', '0', '0', '2018-01-04 16:17:31');

-- ----------------------------
-- Table structure for tbl_decoration_case
-- ----------------------------
DROP TABLE IF EXISTS `tbl_decoration_case`;
CREATE TABLE `tbl_decoration_case` (
  `case_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '装修案例ID',
  `style` varchar(255) NOT NULL COMMENT '装修风格',
  `type` varchar(255) NOT NULL COMMENT '房屋户型',
  `area` varchar(255) NOT NULL DEFAULT '' COMMENT '面积',
  `community_name` varchar(255) NOT NULL COMMENT '小区名称',
  `case_city` varchar(255) NOT NULL COMMENT '所属城市',
  `price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '价格',
  `company_id` varchar(255) NOT NULL COMMENT '装修公司',
  `designer_id` varchar(255) NOT NULL COMMENT '设计师在设计师表中的ID',
  `construction_captain` varchar(255) NOT NULL COMMENT '施工队长',
  `case_photo1` varchar(255) DEFAULT NULL COMMENT '案例图片主图',
  `case_photo2` varchar(255) DEFAULT NULL COMMENT '案例图片副图',
  `case_photo3` varchar(255) DEFAULT NULL COMMENT '案例图片副图',
  `case_photo4` varchar(255) DEFAULT NULL COMMENT '案例图片副图',
  `design_concept` varchar(255) NOT NULL COMMENT '设计理念',
  `case_create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '数据创建时间',
  PRIMARY KEY (`case_id`)
) ENGINE=MyISAM AUTO_INCREMENT=101 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tbl_decoration_case
-- ----------------------------
INSERT INTO `tbl_decoration_case` VALUES ('47', '其他', '三居室', '140', '绿城玫瑰园', '合肥', '18.20', '1', '15', '朱文明', '20171228\\433db95cae089865b6ef0e8ca6066bdc.jpg', '20171228\\433db95cae089865b6ef0e8ca6066bdc.jpg', '20171228\\cd3259f8c88391eb3e585d55fb5714fc.jpg', '20171228\\cd3259f8c88391eb3e585d55fb5714fc.jpg', '整个空间贯穿隐喻的表现手法来渲染空灵写意的东方意境。利用富有变化的色彩与软装陈设。讲求意境，拒绝铺陈，达到东方精神境界的追求，让静谧自然，清幽静默如一股清泉般静静的流淌在整个空间。', '2017-12-28 10:14:57');
INSERT INTO `tbl_decoration_case` VALUES ('54', '欧式', '其他', '151', '六安香格里拉25#401', '合肥', '244000.00', '1', '27', '王业勇', '20171228\\7495649f4aff4d7619dd4bde6a36b2c3.jpg', '20171228\\7495649f4aff4d7619dd4bde6a36b2c3.jpg', '20171228\\7495649f4aff4d7619dd4bde6a36b2c3.jpg', '20171228\\7495649f4aff4d7619dd4bde6a36b2c3.jpg', '欧式风格不但沿用古典欧式风格不但的主元素，融入了现代的生活的元素。欧式的居室不仅仅有的不只是奢华大气，更多的是惬意以及浪漫。经过完美的典线，精雕细镂的细节的处理，带给家人数不尽的舒畅触感。', '2017-12-28 12:31:43');
INSERT INTO `tbl_decoration_case` VALUES ('46', '其他', '三居室', '110.57', '蓝鼎星河府', '合肥', '15.60', '1', '14', '章忠', '20171228\\64989a77fee6eafd856a5cc1fb040ebc.jpg', '20171228\\64989a77fee6eafd856a5cc1fb040ebc.jpg', '20171228\\72c5a772d680a5ad83129ba73123ece8.jpg', '20171228\\72c5a772d680a5ad83129ba73123ece8.jpg', '在古典元素与线条上以简约诠释，同时保留古典主义精神，以欧式家具、摆饰或混搭妆点，融入典雅具质感的氛围，同时满足屋主除了希望有温暖舒适的要求外，更像是一种多元化的思考方式，将怀古的浪漫情怀与现代人对生活的需求相结合，兼容华贵典雅与时尚现代。', '2017-12-28 09:49:06');
INSERT INTO `tbl_decoration_case` VALUES ('48', '欧式', '三居室', '108', '金寨新江新城', '合肥', '15.58', '1', '16', '朱文明', '20171228\\871341a8e58b8c610dd3f00294a826da.jpg', '20171228\\b00b9dd1d61256e8fa3bda9219c0ae77.jpg', '20171228\\b00b9dd1d61256e8fa3bda9219c0ae77.jpg', '20171228\\b00b9dd1d61256e8fa3bda9219c0ae77.jpg', '设计来源于生活，设计来源于沟通，设计来源于发现，设计来源于共同的共鸣', '2017-12-28 10:27:59');
INSERT INTO `tbl_decoration_case` VALUES ('49', '欧式', '别墅', '350', '元一高尔夫', '合肥', '70.00', '1', '17', '李德强', '20171228\\3d587c139d7dc18f1dcad1e19936bb1f.jpg', '20171228\\29a423daf0f29f405d30a92c263b7a92.jpg', '20171228\\29a423daf0f29f405d30a92c263b7a92.jpg', '20171228\\29a423daf0f29f405d30a92c263b7a92.jpg', '深 邃 的 色 彩，饱 满 而 热 烈\r\n质 感 的 空 间，沉 稳 而 优 雅\r\n于 静 谧 中 享 受 自 由\r\n于 声 色 中 不 动 声 色\r\n美 好 的 生 活，不 过 是\r\n时 光 静 好 ，岁 月 如 歌', '2017-12-28 10:32:39');
INSERT INTO `tbl_decoration_case` VALUES ('50', '简欧', '三居室', '141', '湖畔徽映阁', '合肥', '18.00', '1', '20', '李明玉', '20171228\\4e11289d38983781fc560536a3bd0a10.png', '20171228\\4e11289d38983781fc560536a3bd0a10.png', '20171228\\4e11289d38983781fc560536a3bd0a10.png', '20171228\\4e11289d38983781fc560536a3bd0a10.png', '自然品质的物质家园不是简单地将自然要素引入室内，而是结合地方的自然环境特征进行创造性地营造', '2017-12-28 10:33:34');
INSERT INTO `tbl_decoration_case` VALUES ('51', '现代简约', '三居室', '115', '大名城', '合肥', '15.00', '1', '22', '何平', '20171228\\50a9940ba706c4132f9583baa8e8c5ea.jpg', '20171228\\50a9940ba706c4132f9583baa8e8c5ea.jpg', '20171228\\50a9940ba706c4132f9583baa8e8c5ea.jpg', '20171228\\50a9940ba706c4132f9583baa8e8c5ea.jpg', '人为生活而设计，设计为生活而存在', '2017-12-28 10:54:09');
INSERT INTO `tbl_decoration_case` VALUES ('52', '地中海', '三居室', '128', '蓝天小区', '合肥', '21.00', '1', '21', '李德强', '20171228\\0afbf5aff29fd855284a5d69c64ccc7f.jpg', '20171228\\0afbf5aff29fd855284a5d69c64ccc7f.jpg', '20171228\\0afbf5aff29fd855284a5d69c64ccc7f.jpg', '20171228\\0afbf5aff29fd855284a5d69c64ccc7f.jpg', '一个愉悦的空间、一种尊贵的生活、一方独享的天地，都在这里寻求最合适的表达', '2017-12-28 11:18:09');
INSERT INTO `tbl_decoration_case` VALUES ('53', '欧式', '三居室', '150', '合肥恒盛豪庭', '合肥', '25.00', '1', '24', '郭中全', '20171228\\4369cfc096698d282928cdec436fd483.jpg', '20171228\\f5626b237261f183d2945ddf36ea482e.jpg', '20171228\\f5626b237261f183d2945ddf36ea482e.jpg', '20171228\\f5626b237261f183d2945ddf36ea482e.jpg', '针对本案户型特点、业主风格喜好及生活需求，设计了充满豪华、尊贵且充满浪漫主义色彩的三居室大户型。欧式风格本身具有豪华、华丽的特点，本案大面积运用石材铺贴、干挂，欧式造型，石膏线等等欧式常用材料和设计特点，结合精美的地毯，多彩的织物以及欧式壁挂，装饰画等等软装的配饰，其结果在满足居室豪华感的同时，包含浪漫、典雅的特点，充满了文化气息。业主十分喜爱，十分满意。', '2017-12-28 11:30:10');
INSERT INTO `tbl_decoration_case` VALUES ('55', '现代简约', '三居室', '103', '信达天御', '合肥', '14.60', '1', '25', '蒋海涛', '20171228\\5343828a7a68ba465f888073593d5a28.jpg', '20171228\\5343828a7a68ba465f888073593d5a28.jpg', '20171228\\5343828a7a68ba465f888073593d5a28.jpg', '20171228\\5343828a7a68ba465f888073593d5a28.jpg', '简单 舒适远远比堆砌一些华而不实的装饰更让人放松，家本就该有家的样子', '2017-12-28 13:39:54');
INSERT INTO `tbl_decoration_case` VALUES ('56', '现代简约', '三居室', '121', '橡树湾', '合肥', '137818.00', '1', '28', '龚学荣', '20171228\\3233ed42e0e946cde3f2325725092d68.jpg', '20171228\\3233ed42e0e946cde3f2325725092d68.jpg', '20171228\\3233ed42e0e946cde3f2325725092d68.jpg', '20171228\\3233ed42e0e946cde3f2325725092d68.jpg', '合理划分空间，使设计融入生活，营造自然、品味、格调。', '2017-12-28 16:50:59');
INSERT INTO `tbl_decoration_case` VALUES ('57', '其他', '三居室', '135', '公园道壹号', '合肥', '190000.00', '1', '29', '龚学荣', '20171228\\a24662f9ab39c0850490450f8a6393aa.jpg', '20171228\\2903a8ad3e601bfd86a049b9de182718.jpg', '20171228\\2903a8ad3e601bfd86a049b9de182718.jpg', '20171228\\2903a8ad3e601bfd86a049b9de182718.jpg', '人可以改变环境，环境也可以影响人，而设计则可以改变人和环境', '2017-12-28 17:19:35');
INSERT INTO `tbl_decoration_case` VALUES ('58', '田园', '其他', '200', '盛世长安', '石家庄', '26.00', '5', '30', '张帅帅', '20171228\\ebaccea633176fff134d5ceb492526d1.jpg', '20171228\\690133a22bef0143a77620feb73c2d0e.jpg', '20171228\\690133a22bef0143a77620feb73c2d0e.jpg', '20171228\\690133a22bef0143a77620feb73c2d0e.jpg', '主张回归自然是田园风格的主格调。家具是用杉木清水，带有原木的痕迹的门和茶几无不透露着自然风格。构成一篇静溢的乡村图画。用原砖和拉毛处理的墙面，将一幅具有自然风格的景致图发挥的邻里尽致。坐下来泡茶看上一部电影，好好享受着视听的冲击。柔柔的白色灯光暖融融的从后面倾洒下来，一派悠闲，仿佛置身在自然的田园中享受着来自月光的滋润。陶醉在自然风格的家居中。', '2017-12-28 17:21:31');
INSERT INTO `tbl_decoration_case` VALUES ('59', '雅典主义', '三居室', '130', '星河盛世', '石家庄', '17.00', '5', '31', '张飞', '20171228\\4eae37839bd52cd20165c6d216e4d458.jpg', '20171228\\4eae37839bd52cd20165c6d216e4d458.jpg', '20171228\\5df8c1ffa42eb64673c479047ee19e90.jpg', '20171228\\5df8c1ffa42eb64673c479047ee19e90.jpg', '新中式风格，也被称作现代中式风格。新中式风格设计，既是中国传统风格文化与现代时尚元素的融合与碰撞，又是在中国当代文化理解基础上的现代设计。', '2017-12-28 17:24:19');
INSERT INTO `tbl_decoration_case` VALUES ('60', '现代简约', '三居室', '120', '紫晶悦城', '石家庄', '16.00', '5', '32', '赵敦文', '20171228\\b287a5e391034e1bb50484b3279f4829.jpg', '20171228\\4532b8fa11caa40960857ceb1bf10e50.jpg', '20171228\\4532b8fa11caa40960857ceb1bf10e50.jpg', '20171228\\4532b8fa11caa40960857ceb1bf10e50.jpg', '简约主义是由上个世纪80年代中期对复古风潮的叛逆和极简美学的基础上发展起来的，90年代初期，现代简约建筑风格开始融入室内设计领域。以简洁的表现形式来满足人们对空间环境那种感性的、本能的和理性的需求，这是当今国际社会流行的设计风格——简洁明快的简约主义。', '2017-12-28 17:27:46');
INSERT INTO `tbl_decoration_case` VALUES ('61', '雅典主义', '三居室', '145', '保利花园', '石家庄', '19.00', '5', '33', '张献振', '20171228\\cc950b93dc16f3af518670706ce6453d.jpg', '20171228\\14d95414d63614bf894b08d8a9040da9.jpg', '20171228\\14d95414d63614bf894b08d8a9040da9.jpg', '20171228\\14d95414d63614bf894b08d8a9040da9.jpg', '中式风格是以宫廷建筑为代表的中国古典建筑的室内装饰设计艺术风格，气势恢弘、壮丽华贵、高空间、大进深、雕梁画柱、金碧辉煌，造型讲究对称，色彩讲究对比，装饰材料以木材为主，图案多龙、凤、龟、狮等，精雕细琢、瑰丽奇巧。但中式风格的装修造价较高，且缺乏现代气息，只能在家居中点缀使用。', '2017-12-28 17:31:23');
INSERT INTO `tbl_decoration_case` VALUES ('62', '现代简约', '三居室', '130', '润德天悦城', '石家庄', '17.00', '5', '34', '邢军华', '20171228\\4e1961520b02505b4fc4b8f43db2a67d.jpg', '20171228\\3b07a539bb414f5849b82a8b3f1c6fb2.jpg', '20171228\\3b07a539bb414f5849b82a8b3f1c6fb2.jpg', '20171228\\3b07a539bb414f5849b82a8b3f1c6fb2.jpg', '简约主义是由上个世纪80年代中期对复古风潮的叛逆和极简美学的基础上发展起来的，90年代初期，现代简约建筑风格开始融入室内设计领域。以简洁的表现形式来满足人们对空间环境那种感性的、本能的和理性的需求，这是当今国际社会流行的设计风格——简洁明快的简约主义。', '2017-12-28 17:34:39');
INSERT INTO `tbl_decoration_case` VALUES ('63', '雅典主义', '三居室', '112', '国赫红珊湾', '石家庄', '15.00', '5', '35', '刘碧涛', '20171228\\7cf758c8b8c9bbd9e435696a86c3ee9e.jpg', '20171228\\2c1956e17da80c4421c14e0013086567.jpg', '20171228\\2c1956e17da80c4421c14e0013086567.jpg', '20171228\\2c1956e17da80c4421c14e0013086567.jpg', '新中式风格，也被称作现代中式风格。新中式风格设计，既是中国传统风格文化与现代时尚元素的融合与碰撞，又是在中国当代文化理解基础上的现代设计。', '2017-12-28 17:37:22');
INSERT INTO `tbl_decoration_case` VALUES ('64', '田园', '二居室', '102', '瑞城', '石家庄', '14.00', '5', '36', '韩正森', '20171228\\391fdae7e87cc0fa41ca0551204d287c.jpg', '20171228\\dbb4296afca46928cd0eae8c745e4e50.jpg', '20171228\\dbb4296afca46928cd0eae8c745e4e50.jpg', '20171228\\dbb4296afca46928cd0eae8c745e4e50.jpg', '田园风格是通过装饰装修表现出田园的气息，不过这里的田园并非农村的田园，而是一种贴近自然，向往自然的风格。田园风格倡导\"回归自然\"。', '2017-12-28 17:39:19');
INSERT INTO `tbl_decoration_case` VALUES ('65', '乡村', '二居室', '98', '和平时光', '石家庄', '13.00', '5', '37', '郭情茂', '20171228\\8f38e7a3340cc16e5228c466be85880d.jpg', '20171228\\35029ab0562d214c4d92d2db20bdaaad.jpg', '20171228\\35029ab0562d214c4d92d2db20bdaaad.jpg', '20171228\\35029ab0562d214c4d92d2db20bdaaad.jpg', '美式风格有着欧罗巴的奢侈与贵气，但又结合了美洲大陆这块水土的不羁，这样结合的结果是剔除了许多羁绊，但又能找寻文化根基的新的怀旧、贵气加大气而又不失自在与随意的风格。', '2017-12-28 17:41:05');
INSERT INTO `tbl_decoration_case` VALUES ('66', '地中海', '二居室', '92', '中山华府', '石家庄', '12.00', '5', '40', '王靖博', '20171228\\276e92b3797358a2c471a998bae2ccaf.jpg', '20171228\\276e92b3797358a2c471a998bae2ccaf.jpg', '20171228\\c1ff7f593fbc5d45dda7dffa2d6d2fbb.jpg', '20171228\\c1ff7f593fbc5d45dda7dffa2d6d2fbb.jpg', '在装修风格里地中海风格无疑是比较特别的一个风格，地中海风格代表着烂漫与特色，深受很多人喜欢，对于地中海来说，白色和蓝色是两个主打，最好还要有造型别致的拱廊和细细小小的石砾。在打造地中海风格的家居时，配色是一个主要的方面，要给人一种阳光而自然的感觉。', '2017-12-28 17:44:20');
INSERT INTO `tbl_decoration_case` VALUES ('67', '雅典主义', '三居室', '115', '恒大御景半岛', '石家庄', '15.00', '5', '41', '汪志伟', '20171228\\b516bf18bf3ce31094dadb475fbb5324.jpg', '20171228\\b516bf18bf3ce31094dadb475fbb5324.jpg', '20171228\\b516bf18bf3ce31094dadb475fbb5324.jpg', '20171228\\b516bf18bf3ce31094dadb475fbb5324.jpg', '新中式风格，也被称作现代中式风格。新中式风格设计，既是中国传统风格文化与现代时尚元素的融合与碰撞，又是在中国当代文化理解基础上的现代设计。', '2017-12-28 17:45:42');
INSERT INTO `tbl_decoration_case` VALUES ('68', '现代简约', '二居室', '90', '润德天悦城', '石家庄', '12.00', '5', '42', '张帅帅', '20171228\\1eb76c1c2d20b3185122b0990aa36b37.jpg', '20171228\\683069ce5845201fc5f6271a50b22661.jpg', '20171228\\683069ce5845201fc5f6271a50b22661.jpg', '20171228\\683069ce5845201fc5f6271a50b22661.jpg', '简约主义是由上个世纪80年代中期对复古风潮的叛逆和极简美学的基础上发展起来的，90年代初期，现代简约建筑风格开始融入室内设计领域。以简洁的表现形式来满足人们对空间环境那种感性的、本能的和理性的需求，这是当今国际社会流行的设计风格——简洁明快的简约主义。', '2017-12-28 17:46:45');
INSERT INTO `tbl_decoration_case` VALUES ('69', '雅典主义', '三居室', '130', '国赫红珊湾', '石家庄', '17.00', '5', '43', '赵敦文', '20171228\\904eccc27db76526071b4e0a8f08ffe5.jpg', '20171228\\a0f9e102e985c9afb4353941307d35a5.jpg', '20171228\\a0f9e102e985c9afb4353941307d35a5.jpg', '20171228\\a0f9e102e985c9afb4353941307d35a5.jpg', '新中式风格，也被称作现代中式风格。新中式风格设计，既是中国传统风格文化与现代时尚元素的融合与碰撞，又是在中国当代文化理解基础上的现代设计。', '2017-12-28 17:48:03');
INSERT INTO `tbl_decoration_case` VALUES ('70', '现代简约', '二居室', '100', '瑞城', '石家庄', '13.00', '5', '44', '连俊杰', '20171228\\aa873afb25024e0466234889b5789d60.jpg', '20171228\\3a859c01fcdcd8a811f1673166195ff6.jpg', '20171228\\3a859c01fcdcd8a811f1673166195ff6.jpg', '20171228\\3a859c01fcdcd8a811f1673166195ff6.jpg', '新中式风格，也被称作现代中式风格。新中式风格设计，既是中国传统风格文化与现代时尚元素的融合与碰撞，又是在中国当代文化理解基础上的现代设计。', '2017-12-28 17:49:03');
INSERT INTO `tbl_decoration_case` VALUES ('71', '现代简约', '二居室', '96', '星河盛世', '石家庄', '13.00', '5', '45', '程海涛', '20171228\\f9ab6f68567cff291c7d0884cae58198.jpg', '20171228\\2b1c37a6e7817bcab06aafcd778a7b57.jpg', '20171228\\2b1c37a6e7817bcab06aafcd778a7b57.jpg', '20171228\\2b1c37a6e7817bcab06aafcd778a7b57.jpg', '新中式风格，也被称作现代中式风格。新中式风格设计，既是中国传统风格文化与现代时尚元素的融合与碰撞，又是在中国当代文化理解基础上的现代设计。', '2017-12-28 17:50:08');
INSERT INTO `tbl_decoration_case` VALUES ('72', '雅典主义', '别墅', '300', '恒大御景半岛', '石家庄', '39.00', '5', '46', '张飞', '20171228\\8ab7016a48107bb558ff8f921562025c.jpg', '20171228\\8ab7016a48107bb558ff8f921562025c.jpg', '20171228\\8ab7016a48107bb558ff8f921562025c.jpg', '20171228\\8ab7016a48107bb558ff8f921562025c.jpg', '美式风格有着欧罗巴的奢侈与贵气，但又结合了美洲大陆这块水土的不羁，这样结合的结果是剔除了许多羁绊，但又能找寻文化根基的新的怀旧、贵气加大气而又不失自在与随意的风格。', '2017-12-28 17:51:45');
INSERT INTO `tbl_decoration_case` VALUES ('73', '雅典主义', '别墅', '400', '恒大御景半岛', '石家庄', '50.00', '5', '47', '张献振', '20171228\\073c35255db2abcd6d87589a0bfe6e7a.jpg', '20171228\\073c35255db2abcd6d87589a0bfe6e7a.jpg', '20171228\\073c35255db2abcd6d87589a0bfe6e7a.jpg', '20171228\\073c35255db2abcd6d87589a0bfe6e7a.jpg', '新中式风格，也被称作现代中式风格。新中式风格设计，既是中国传统风格文化与现代时尚元素的融合与碰撞，又是在中国当代文化理解基础上的现代设计。', '2017-12-28 17:53:07');
INSERT INTO `tbl_decoration_case` VALUES ('74', '现代简约', '二居室', '80', '新世界公馆', '合肥', '95000.00', '1', '23', '吴道全', '20171229\\7ee2c323961db1032af4b1cbbf9cea81.jpg', '20171229\\a388ca6ac937c428cd7c33f3731f722b.jpg', '20171229\\a388ca6ac937c428cd7c33f3731f722b.jpg', '20171229\\a388ca6ac937c428cd7c33f3731f722b.jpg', '业主是毕业没多久的上班族，喜欢现代简约风格，是打算装修婚房。所以我在设计方案的时候既要满足业主年轻的审美需求，又要为婚后小夫妻的日常生活实用性考虑。', '2017-12-29 11:23:29');
INSERT INTO `tbl_decoration_case` VALUES ('75', '现代简约', '三居室', '92.13', '文一名门华府', '合肥', '11.00', '1', '49', '丁涛', '20171229\\8ae0b5d9fb59484550d14994bfaa2f94.png', '20171229\\8ae0b5d9fb59484550d14994bfaa2f94.png', '20171229\\8ae0b5d9fb59484550d14994bfaa2f94.png', '20171229\\8ae0b5d9fb59484550d14994bfaa2f94.png', '简约不等于简单，它是经过深思熟虑后经过创新得出设计和思路的延展，不是简单“堆砌”和平淡的“摆放”，不像有些设计师粗浅的理解的“直白”，比如床头背景设计有些简约到只有一个十字挂件，但是它凝结着设计师的独具匠心，既美观又实用。', '2017-12-29 15:44:39');
INSERT INTO `tbl_decoration_case` VALUES ('76', '现代简约', '三居室', '100', '和昌中央城邦', '合肥', '12.00', '1', '50', '吴道全', '20171229\\09290ec4108a51d3224766ab2ddc350a.JPG', '20171229\\09290ec4108a51d3224766ab2ddc350a.JPG', '20171229\\4003d71961eb6adc8aac3f11848e5b1d.JPG', '20171229\\4003d71961eb6adc8aac3f11848e5b1d.JPG', '现代简约风格的装修风格迎合了年轻人的喜爱，都市忙碌生活，早已经让我们烦腻了灯红酒绿，我们更喜欢的一个安静，祥和，用看上去明朗宽敞舒适的家，来消除工作的疲惫，忘却都市的喧闹。这也是现在流行的装修风格之一。', '2017-12-29 16:37:01');
INSERT INTO `tbl_decoration_case` VALUES ('95', '其他', '三居室', '140', '华润熙云府', '合肥', '20.00', '1', '60', '郭中全', '20171230\\e5951fbc1a386fec927c4455ef46d78447848.jpg', '20171230\\e5951fbc1a386fec927c4455ef46d78466269.jpg', '20171230\\4b85327999e692bde82d7c73a07358343776.jpg', '20171230\\4b85327999e692bde82d7c73a073583467930.jpg', '简约而不简单，时尚而不花哨，存其韵，留其味！', '2017-12-30 15:06:52');
INSERT INTO `tbl_decoration_case` VALUES ('78', '其他', '其他', '140', '悠然蓝山', '合肥', '20.00', '1', '53', '郝文峰', '20171229\\9f2a49c9b85a8e5572b207a3f720c001.png', '20171229\\9f2a49c9b85a8e5572b207a3f720c001.png', '20171229\\9f2a49c9b85a8e5572b207a3f720c001.png', '20171229\\9f2a49c9b85a8e5572b207a3f720c001.png', '回归', '2017-12-29 17:31:55');
INSERT INTO `tbl_decoration_case` VALUES ('79', '其他', '三居室', '140', '栖霞山庄', '合肥', '21.00', '1', '54', '王业勇', '20171229\\9a8889236f115d21d05730f1d0be9593.jpg', '20171229\\9a8889236f115d21d05730f1d0be9593.jpg', '20171229\\9a8889236f115d21d05730f1d0be9593.jpg', '20171229\\9a8889236f115d21d05730f1d0be9593.jpg', '木色运用，\r\n\r\n倍具文人气质，\r\n\r\n色调文化的运用结合人文气质的符号余元，\r\n\r\n把兼备现代与传统的新中式发挥的淋漓尽致。\r\n', '2017-12-29 17:52:01');
INSERT INTO `tbl_decoration_case` VALUES ('80', '其他', '三居室', '140', '栖霞山庄', '合肥', '21.00', '1', '54', '王业勇', '20171229\\6fe10242798d663e81d64ba83ad375b0.jpg', '20171229\\6fe10242798d663e81d64ba83ad375b0.jpg', '20171229\\6fe10242798d663e81d64ba83ad375b0.jpg', '20171229\\6fe10242798d663e81d64ba83ad375b0.jpg', '木色运用，\r\n\r\n倍具文人气质，\r\n\r\n色调文化的运用结合人文气质的符号余元，\r\n\r\n把兼备现代与传统的新中式发挥的淋漓尽致。\r\n', '2017-12-29 17:52:12');
INSERT INTO `tbl_decoration_case` VALUES ('81', '其他', '三居室', '140', '栖霞山庄', '合肥', '21.00', '1', '54', '王业勇', '20171229\\b0625b1de71b2af4d1a41065178b8b6c.jpg', '20171229\\b0625b1de71b2af4d1a41065178b8b6c.jpg', '20171229\\b0625b1de71b2af4d1a41065178b8b6c.jpg', '20171229\\b0625b1de71b2af4d1a41065178b8b6c.jpg', '木色运用，\r\n\r\n倍具文人气质，\r\n\r\n色调文化的运用结合人文气质的符号余元，\r\n\r\n把兼备现代与传统的新中式发挥的淋漓尽致。\r\n', '2017-12-29 17:52:38');
INSERT INTO `tbl_decoration_case` VALUES ('82', '其他', '三居室', '146', '建业领翔', '合肥', '21.30', '1', '55', '王业勇', '20171229\\e3f0ae37609e7d1c514fab8ec6aae8c7.JPG', '20171229\\e3f0ae37609e7d1c514fab8ec6aae8c7.JPG', '20171229\\e3f0ae37609e7d1c514fab8ec6aae8c7.JPG', '20171229\\e3f0ae37609e7d1c514fab8ec6aae8c7.JPG', '设计是恒久的，在经过很长一段岁月后仍然具有耐看的质感。', '2017-12-29 18:04:27');
INSERT INTO `tbl_decoration_case` VALUES ('83', '其他', '三居室', '146', '建业领翔', '合肥', '21.30', '1', '55', '王业勇', '20171229\\2a1c38df9e7a0629be3a78c3d4e925ad.JPG', '20171229\\2a1c38df9e7a0629be3a78c3d4e925ad.JPG', '20171229\\2a1c38df9e7a0629be3a78c3d4e925ad.JPG', '20171229\\2a1c38df9e7a0629be3a78c3d4e925ad.JPG', '设计是恒久的，在经过很长一段岁月后仍然具有耐看的质感。', '2017-12-29 18:04:32');
INSERT INTO `tbl_decoration_case` VALUES ('94', '乡村', '二居室', '100', '信地华地城', '合肥', '17.00', '1', '51', '和平', '20171230\\e6e3f913ff6af72d2ecc19158d8d625b99518.jpg', '20171230\\e6e3f913ff6af72d2ecc19158d8d625b35559.jpg', '20171230\\e3ca90b0b24dd851abf2739bbb87214a35025.jpg', '20171230\\e3ca90b0b24dd851abf2739bbb87214a20065.jpg', '设计是从内心发出的声音，是一种灵魂对生活的感悟', '2017-12-30 13:54:40');
INSERT INTO `tbl_decoration_case` VALUES ('92', '欧式', '别墅', '220', '天弘国际', '合肥', '32.00', '1', '56', '朱文明', '20171230\\9324238477fba18ab6907f02143c3dce18197.png', '20171230\\9324238477fba18ab6907f02143c3dce31644.png', '20171230\\9324238477fba18ab6907f02143c3dce42559.png', '20171230\\9324238477fba18ab6907f02143c3dce5825.png', '一生二，二生三，三生所有！', '2017-12-30 13:32:47');
INSERT INTO `tbl_decoration_case` VALUES ('93', '欧式', '三居室', '131', '旭辉御府', '合肥', '23.00', '1', '57', '汪发明', '20171230\\a79dc0bddd9bc5c1bbb6cca4abe9c28c28254.jpg', '20171230\\f1f5db30b5a52b28d66da1b3ab1ad1d374003.jpg', '20171230\\f1f5db30b5a52b28d66da1b3ab1ad1d398466.jpg', '20171230\\f1f5db30b5a52b28d66da1b3ab1ad1d385445.jpg', '设计是有是生命的，我的家装不是一种设计，而是一种生活。', '2017-12-30 13:39:00');
INSERT INTO `tbl_decoration_case` VALUES ('100', '田园', '二居室', '135', '湖光小区', '蚌埠', '13.60', '2', '61', '李白', '20171231\\65f5d868755e259707ac81666d71d06d96954.jpg', '20171231\\32f80a0e6c4371461af4b188add9c56d76424.jpg', '20171231\\bfd9fbf6b4e7926231b4910089ca1c7f94481.jpg', '20171231\\571f51854a24e4a117eb58118e1ff90599064.jpg', '设计理念	设计理念	', '2017-12-31 16:33:00');

-- ----------------------------
-- Table structure for tbl_designer
-- ----------------------------
DROP TABLE IF EXISTS `tbl_designer`;
CREATE TABLE `tbl_designer` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '设计师id',
  `name` varchar(10) NOT NULL COMMENT '设计师姓名',
  `position` varchar(255) NOT NULL DEFAULT '0' COMMENT '设计师职位',
  `company` varchar(20) NOT NULL COMMENT '所属店面',
  `years` int(10) NOT NULL DEFAULT '0' COMMENT '设计师工作经验',
  `avatar` varchar(100) NOT NULL COMMENT '设计师头像',
  `introduction` varchar(300) NOT NULL COMMENT '设计师自我介绍',
  `motto` varchar(255) DEFAULT '' COMMENT '个性签名',
  `numbers` int(11) DEFAULT '0' COMMENT '作品数量',
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '数据添加时间',
  PRIMARY KEY (`id`),
  KEY `belong_shops` (`company`)
) ENGINE=MyISAM AUTO_INCREMENT=62 DEFAULT CHARSET=utf8 COMMENT='设计师人员统计表';

-- ----------------------------
-- Records of tbl_designer
-- ----------------------------
INSERT INTO `tbl_designer` VALUES ('29', '马锦', '首席设计师', '合肥盛腾家装工厂店', '4', '20171228\\3c1ea1ee709ef56e09b4b8a6110234bc.png', '为积极，舒适，简单生活而设计，既不是傲慢的炫耀，也不是浅薄的放任', '原来设计真的可以改变生活', '1', '2017-12-28 17:19:35');
INSERT INTO `tbl_designer` VALUES ('28', '徐明', '设计总监', '合肥盛腾家装工厂店', '2', '20171228\\0157eb5a243d28b055cfa0649862de31.jpg', '我的设计中，有一半是有节制的发挥想象，有15%是完全疯狂的创意，剩下的则是为了面包和黄油设计的。\r\n以人为本，从心出发！', '用极简的线条勾勒出灵动的空间！', '1', '2017-12-28 16:50:59');
INSERT INTO `tbl_designer` VALUES ('14', '彭祝平', '设计总监', '合肥盛腾家装工厂店', '4', '20171228\\54d679f0d53c02663d349d44649b16c5.png', '  对待工作认真负责，善于沟通、协调有较强的组织能力与团队精神；活泼开朗、乐观上进、有爱心并善于施教并行；上进心强、勤于学习能不断提高自身的能力与综合素质。\r\n  在未来的工作中，我将以充沛的精力，刻苦钻研的精神来努力工作，稳定地提高自己的工作能力，与企业同步发展。', '让设计赞美生命，以遇见更好的自己。', '1', '2017-12-28 09:49:06');
INSERT INTO `tbl_designer` VALUES ('15', '余祥杰', '设计总监', '合肥盛腾家装工厂店', '6', '20171228\\04de09c5d61cda6fe781f3ef35d6cec3.jpg', '用最少的投入,来最大化的美化和利用现有空间，一切随心,有心去感悟空间。 生活是设计的来源。', '设计源于生活，服务于生活', '1', '2017-12-28 10:14:57');
INSERT INTO `tbl_designer` VALUES ('16', '吴金凤', '设计总监', '合肥盛腾家装工厂店', '1', '20171228\\41270f06e576a4837d2d925fb744959f.jpg', '热爱设计，有很深的设计底蕴和手绘功底以及丰富谈判技巧，对时尚有着敏锐的嗅觉！做事追求完美，责任心强，有较强的沟通及协调能力。沟通能力强，有亲和', '设计的未来在于把对过去的尊崇无形地蕴于对明天的憧憬', '1', '2017-12-28 10:27:59');
INSERT INTO `tbl_designer` VALUES ('17', '史欢欢', '设计总监', '合肥盛腾家装工厂店', '8', '20171228\\d0009de0aee5edb9046671246839269a.jpg', '人为的设计生活方式，是为了努力去创造一种更好的生活状态 \r\n设计源于生活，生活因设计而改变！成就空间和谐，让设计物有所值，让细节缔造完美！', '居家设计一定要结合生活结合，离开生活，空间只是一个形式、一个没有灵魂的驱壳而已', '1', '2017-12-28 10:32:39');
INSERT INTO `tbl_designer` VALUES ('18', '缪龙', '设计总监', '合肥盛腾家装工厂店', '6', '20171228\\6af4b8cb601d61aab2a9d8571346d604.jpg', '设计来源于生活，也要回归于生活、回归自然。', '“因设计而生活,为生活而设计”,最永恒的设计作品总是来源于生活的点点滴滴....', '0', '2017-12-28 10:11:28');
INSERT INTO `tbl_designer` VALUES ('19', '缪龙', '设计总监', '合肥盛腾家装工厂店', '8', '20171228\\fd34989d9875ad0190e662a907adf2e7.jpg', '设计源于生活，设计也要回归生活回归自然。', '“因设计而生活,为生活而设计”,最永恒的设计作品总是来源于生活的点点滴滴....', '0', '2017-12-28 10:14:10');
INSERT INTO `tbl_designer` VALUES ('20', '李明玉', '设计总监', '合肥盛腾家装工厂店', '5', '20171228\\7323879b87dfd4cdb8e2d59ab2706313.png', '室内是建筑的灵魂，是人与环境的联系，是人类艺术与物质文明的结合', '创造未来，领选于时代潮流', '1', '2017-12-28 10:33:34');
INSERT INTO `tbl_designer` VALUES ('21', '左学飞', '设计总监', '合肥盛腾家装工厂店', '5', '20171228\\2b1725881795eb842c1b7909b79966a5.jpg', '当人们的空间被各种物质挤压的时候，也就失去了本质，我们要去掉一切虚假的、表面的、无用的东西，而剩下真实的、本质的、必不可少的东西，因而得到更多的空间、更多的舒适、更多的效率、更多的美。', '少就是多，简洁就是丰富。', '1', '2017-12-28 11:18:09');
INSERT INTO `tbl_designer` VALUES ('22', '邵雪银', '设计总监', '合肥盛腾家装工厂店', '5', '20171228\\111c6cdad6a7c4d8d8334c7b902c14ef.jpg', '无论你是否喜欢你的客户，你都要让自己喜欢上他，应该只有这样做这个设计才是你愿意做的事情', '好与不好，客户认可最重要', '1', '2017-12-28 10:54:09');
INSERT INTO `tbl_designer` VALUES ('23', '龚金芝', '设计总监', '合肥盛腾家装工厂店', '1', '20171228\\78840aa1f5e47793e8342067cc9ff012.JPG', '诚实守信、责任心强、仔细认真、工作踏实、对自己严格要求、具有团队精神。虽对设计类经验不足，但接受能力强，自我信心十足。', '人总是各有苦衷且不甘平庸', '1', '2017-12-29 11:23:29');
INSERT INTO `tbl_designer` VALUES ('24', '刘飞', '设计总监', '合肥盛腾家装工厂店', '5', '20171228\\3373eae664e21a6dee7952901e00cec3.jpg', '作为设计对待设计要简约而不简单，舒适却不昂贵，美丽却不失梦幻。出其不意的设计，带来实实在在的享受。', '简约而不简单，舒适却不昂贵。', '1', '2017-12-28 11:30:10');
INSERT INTO `tbl_designer` VALUES ('25', '张中林', '设计总监', '合肥盛腾家装工厂店', '2', '20171228\\23e602aa3d8d342887fac264b508474a.JPG', '设计是追求生活品味生活的概念。', '让灵感自由释放，创造一个渴望的空间。', '1', '2017-12-28 13:39:54');
INSERT INTO `tbl_designer` VALUES ('26', '钱淼', '设计总监', '合肥盛腾家装工厂店', '3', '20171228\\cb8d55ea208632091a7252294b9a6d55.jpg', '您赏识的目光，就是我未来的开始。现代家庭室内设计必须满足人在视觉、听觉、体感、触觉、嗅觉等多方面的要求。对自己严格要求，就是对客户负责。', '从实用的角度，到超载的发挥，构成艺术的主体', '0', '2017-12-28 11:39:39');
INSERT INTO `tbl_designer` VALUES ('27', '张昇', '设计总监', '合肥盛腾家装工厂店', '4', '20171228\\3e5e7d1c1ecc2a7b01f127df54a5b5df.png', '本人勤奋好学、诚信肯干、乐观、自强、对生活充满激-情。工作认真负责，从大局出发，善于人际沟通，善于组织团队协作，对工作充满热情。处理问题头脑清晰、快捷有效。性格开朗。有创新意识、有钉子精神。', '设计源于生活，细节成就品质', '1', '2017-12-28 12:31:43');
INSERT INTO `tbl_designer` VALUES ('30', '陈静波', '首席设计师', '石家庄盛腾家装工厂店', '6', '20171228\\2749969f1e52fc0b5dfcd75db1890433.JPG', '设计源于生活', '设计源于生活', '1', '2017-12-28 17:21:31');
INSERT INTO `tbl_designer` VALUES ('31', '陈鹏', '主任设计师', '石家庄盛腾家装工厂店', '5', '20171228\\eda61b3ef0ad049fdfcb307034499027.JPG', '设计来自生活的点点滴滴', '设计来自生活的点点滴滴', '1', '2017-12-28 17:24:19');
INSERT INTO `tbl_designer` VALUES ('32', '程鹏举', '主任设计师', '石家庄盛腾家装工厂店', '7', '20171228\\d0ff89ded1926ce61e4f89aa35621c04.JPG', '成功的设计应该符合个人需求', '成功的设计应该符合个人需求', '1', '2017-12-28 17:27:46');
INSERT INTO `tbl_designer` VALUES ('33', '崔哲源', '主任设计师', '石家庄盛腾家装工厂店', '6', '20171228\\c3155a5c57282ae6aa2f8c67791c04b4.jpg', '用心设计，真诚服务', '用心设计，真诚服务', '1', '2017-12-28 17:31:23');
INSERT INTO `tbl_designer` VALUES ('34', '高伟科', '设计部长', '石家庄盛腾家装工厂店', '8', '20171228\\d74594f6ac68b24efad74322fc91ea58.JPG', '用设计改变生活', '用设计改变生活', '1', '2017-12-28 17:34:39');
INSERT INTO `tbl_designer` VALUES ('35', '高欣', '主任设计师', '石家庄盛腾家装工厂店', '5', '20171228\\024175a2dd39492041f4a7ac3c299d0c.JPG', '用有限的空间，做无限的设计', '用有限的空间，做无限的设计', '1', '2017-12-28 17:37:22');
INSERT INTO `tbl_designer` VALUES ('36', '耿佳欣', '主任设计师', '石家庄盛腾家装工厂店', '5', '20171228\\ec9fed554ef01471cec450967fb8b832.JPG', '好的设计作品，是使人生活得更为幸福的设计作品。', '好的设计作品，是使人生活得更为幸福的设计作品。', '1', '2017-12-28 17:39:19');
INSERT INTO `tbl_designer` VALUES ('37', '胡南', '主任设计师', '石家庄盛腾家装工厂店', '6', '20171228\\ba88def674939e6fa53166e14bfff868.JPG', '一切围绕为人的生活、生产活动创造美好的室内环境。', '一切围绕为人的生活、生产活动创造美好的室内环境。', '1', '2017-12-28 17:41:05');
INSERT INTO `tbl_designer` VALUES ('38', '李燕茹', '首席设计师', '石家庄盛腾家装工厂店', '7', '20171228\\9b4946dad0598f0659e9a19a89eb25c0.JPG', '设计师是做设计给人用，不是做给自己看，或者让朋友称赞。', '设计师是做设计给人用，不是做给自己看，或者让朋友称赞。', '0', '2017-12-28 17:31:58');
INSERT INTO `tbl_designer` VALUES ('39', '李燕茹', '首席设计师', '石家庄盛腾家装工厂店', '7', '20171228\\fd3d22a8bc8df3864c2912e8d8b7bfcd.JPG', '设计师是做设计给人用，不是做给自己看，或者让朋友称赞。', '设计师是做设计给人用，不是做给自己看，或者让朋友称赞。', '0', '2017-12-28 17:32:07');
INSERT INTO `tbl_designer` VALUES ('40', '马江波', '主任设计师', '石家庄盛腾家装工厂店', '7', '20171228\\a4faaddc20147677ba716d66245f9406.JPG', '合理划分空间，让设计融入生活，营造自然，品味，格调。', '合理划分空间，让设计融入生活，营造自然，品味，格调。', '1', '2017-12-28 17:44:20');
INSERT INTO `tbl_designer` VALUES ('41', '马瑞良', '主任设计师', '石家庄盛腾家装工厂店', '4', '20171228\\2dc3166bc79ce61a5e45843b3906430f.JPG', '持之以恒的学习是设计的来源，责任感是设计的原则，而灵感是设计的升华。', '持之以恒的学习是设计的来源，责任感是设计的原则，而灵感是设计的升华。', '1', '2017-12-28 17:45:42');
INSERT INTO `tbl_designer` VALUES ('42', '史建坤', '主任设计师', '石家庄盛腾家装工厂店', '5', '20171228\\0d9a19ad5ba56f3d9590fc12758b962d.JPG', '人为生活而设计，设计为生活而存在。', '人为生活而设计，设计为生活而存在。', '1', '2017-12-28 17:46:45');
INSERT INTO `tbl_designer` VALUES ('43', '苏影', '设计部长', '石家庄盛腾家装工厂店', '7', '20171228\\c5cad96fced14077f13956d027211ece.JPG', '有效规划布局，合理使用空间，以小博大，画龙点睛，创造美味家居生活！', '有效规划布局，合理使用空间，以小博大，画龙点睛，创造美味家居生活！', '1', '2017-12-28 17:48:03');
INSERT INTO `tbl_designer` VALUES ('44', '王伟华', '主任设计师', '石家庄盛腾家装工厂店', '5', '20171228\\ae6e6ea9cb83a1d4df0e9e76b83cab3b.jpg', '装饰美的享受是属于客户的，创意的快乐是属于设计师的', '装饰美的享受是属于客户的，创意的快乐是属于设计师的', '1', '2017-12-28 17:49:03');
INSERT INTO `tbl_designer` VALUES ('45', '王晓军', '首席设计师', '石家庄盛腾家装工厂店', '8', '20171228\\0b7a6daa665ab720412bf36f546a647f.JPG', '用极其简单的线条勾勒出最具灵性的空间。', '用极其简单的线条勾勒出最具灵性的空间。', '1', '2017-12-28 17:50:08');
INSERT INTO `tbl_designer` VALUES ('46', '王杨', '主任设计师', '石家庄盛腾家装工厂店', '6', '20171228\\919b4e806406c46d7d50264223e6855e.JPG', '设计就是以人为本，遵守自然法则，缔造经典家装。', '设计就是以人为本，遵守自然法则，缔造经典家装。', '1', '2017-12-28 17:51:45');
INSERT INTO `tbl_designer` VALUES ('47', '王义', '设计部长', '石家庄盛腾家装工厂店', '8', '20171228\\9eb5e71ce05e9938a3c8b185736f80c8.jpg', '设计是恒久的，在经过很长一段岁月后仍然具有耐看的质感。', '设计是恒久的，在经过很长一段岁月后仍然具有耐看的质感。', '1', '2017-12-28 17:53:07');
INSERT INTO `tbl_designer` VALUES ('48', '米钱', '主任设计师', '合肥盛腾家装工厂店', '3', '20171229\\4afca0bc8961e485818bed9b6c07906c.jpg', '设计的核心是一种创造行为，设计要求新、求异、求变、求不同，否则设计将不能称之为设计。而这个“新”有着不同的层次，它可以是改良性的，也可以是创造性的。但无论如何，只有新颖的设计才会在大浪淘沙中闪烁出与众不同的光芒，迈出走向成功的第一步。', '一切设计由概念出发，围绕功能进行细节设计。', '0', '2017-12-29 10:09:01');
INSERT INTO `tbl_designer` VALUES ('49', '徐冬阳', '实习设计师', '合肥盛腾家装工厂店', '2', '20171229\\597e817e12bc93c18a884cb88ec5b7cc.jpg', '设计源于生活，生活因设计而改变！成就空间和谐，让设计物有所值，让细节缔造完美！我的设计中，有一半是有节制地发挥想象，有15%是完全疯狂的创意，剩下的则是为了面包和黄油的设计。', '合理划分空间，让设计融入生活，营造自然，品味，格调。', '1', '2017-12-29 15:44:39');
INSERT INTO `tbl_designer` VALUES ('50', '汪晓雪', '实习设计师', '合肥盛腾家装工厂店', '2', '20171229\\d4fa4a04f79095ee410f930d612aee86.jpg', '性格低调，比较细心，责任感强，有进取心。对工作认真严谨，做事踏实稳重，有上进心。能很快适应快节奏的工作;能与各部门的同事精诚合作;领悟学习能力强，极具上进心，不畏惧压力和挑战。', '我的设计中，有一半是有节制地发挥想象，有15%是完全疯狂的创意，剩下的则是为了面包和黄油的设计。', '1', '2017-12-29 16:37:01');
INSERT INTO `tbl_designer` VALUES ('51', '李雪', '主任设计师', '合肥盛腾家装工厂店', '1', '20171229\\50033a4f0881bb91fb35d0c95e6dac26.png', '      持之以恒的学习是设计的来源，责任感是设计的原则，而灵感是设计的升华。没有人拒绝一部为之所想所优的设计作品。也没有人拒绝一位为其所思所顾的设计师。', '对设计的认知，才是好的开始。', '1', '2017-12-30 13:54:40');
INSERT INTO `tbl_designer` VALUES ('57', '李月', '主任设计师', '合肥盛腾家装工厂店', '3', '169073.jpg', '成为一个优秀的设计师是我的梦想，我一直认为设计并不只是简单，每个人都是设计师，想要把设计做好，那么就要把心融入进去，把设计当成自己生命，只有这样我们才能创造出好的作品，就像我说的我设计的不是家装，而是家。', '我设计的不是家装，而是家的感觉。', '1', '2017-12-30 13:39:00');
INSERT INTO `tbl_designer` VALUES ('56', '王鹏', '设计部长', '合肥盛腾家装工厂店', '5', '184134.jpg', '设计是拒绝任何规划与典范的，本质就是不断的超越与探索。热爱自由的时间、热爱自然所带给你的灵感。当你认知了这个世界，就更加懂得设计从不墨守成规。', '生命不是要超越别人，而是超越自己！', '1', '2017-12-30 13:32:47');
INSERT INTO `tbl_designer` VALUES ('53', '陈亚', '主任设计师', '合肥盛腾家装工厂店', '3', '20171229\\3e513906ffc3395d09cc244d963b29af.png', '比别人多一点执着，你就会创造奇迹', '人为生活而设计，设计为生活而存在', '1', '2017-12-29 17:31:55');
INSERT INTO `tbl_designer` VALUES ('54', '唐新', '首席设计师', '合肥盛腾家装工厂店', '4', '20171229\\0786dbcdf355af7441ac89d53074004b.jpg', '认真对待每一个客户，耐心服务', '设计是一种追求完美的生活态度，设计是一种追求品味的生活概  念   ', '3', '2017-12-29 17:52:38');
INSERT INTO `tbl_designer` VALUES ('55', '潘博超', '首席设计师', '合肥盛腾家装工厂店', '4', '20171229\\28af5b3809ed6599be753ffa9d5f5582.JPG', '我深信卓越的创意作品，永远是一个成功代理商前进巨轮的中轴-过去是，现在是，未来亦如是。', '持之以恒的学习是设计的来源，责任感是设计的原则，而灵感是设计的升华。', '2', '2017-12-29 18:04:32');
INSERT INTO `tbl_designer` VALUES ('60', '钱园', '设计部长', '合肥盛腾家装工厂店', '7', '20171230\\7ca002879347cb16b670b8555d38badd17880.jpg', '用所见所闻所感用心打造每一个属于你们独一无二的家！享受你们的生活，从你们的生活中享受属于我的成就感！', '设计是一种生活态度', '1', '2017-12-30 15:06:52');
INSERT INTO `tbl_designer` VALUES ('59', '谢西楼', '首席设计师', '合肥盛腾家装工厂店', '5', '20171230\\24fc841f21afdcc1ee5ba76a3e819f54.jpg', '我是一名设计师，可是设计师不代表是一个很会设计的人，而是一个保持设计概念来过生活的人、活下去的人。就类似是一个在园子里收拾整理的园丁一样，我每天都在园子里做设计的果实，所以不论是设计一件好的产品、或是整理设计的概念、思考设计的本质、抑或以写作去传播设计理论，都是一个设计师必须要做的工作。', '设计是一种追求完美的生活态度，设计是一种追求品位的生活概念', '0', '2017-12-30 11:45:49');
INSERT INTO `tbl_designer` VALUES ('61', '测试设计师', '设计总监', '蚌埠盛腾家装工厂店', '1', '20171230\\41e028eb87904a592af534a7df2857be26090.jpg', '自我评价', '个性签名', '5', '2017-12-31 16:33:00');

-- ----------------------------
-- Table structure for tbl_news
-- ----------------------------
DROP TABLE IF EXISTS `tbl_news`;
CREATE TABLE `tbl_news` (
  `id` int(30) NOT NULL AUTO_INCREMENT COMMENT '新闻ID',
  `thumbnail` varchar(255) DEFAULT NULL COMMENT '缩略图',
  `title` varchar(50) NOT NULL COMMENT '新闻标题',
  `author` varchar(11) DEFAULT NULL COMMENT '新闻作者',
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `views` char(100) DEFAULT '0' COMMENT '浏览次数',
  `description` varchar(255) DEFAULT NULL COMMENT '新闻简介',
  `content` text COMMENT '新闻内容',
  `category` varchar(255) DEFAULT NULL COMMENT '新闻分类',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '新闻发布状态',
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `id_2` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=utf8 COMMENT='网站新闻';

-- ----------------------------
-- Records of tbl_news
-- ----------------------------
INSERT INTO `tbl_news` VALUES ('14', '20171222\\41b7c271d29a6049f4433196daf3b25f.png', '嘻嘻嘻我的', '死神', '2017-11-07 14:12:26', null, '是是是', '<p><img src=\"/ueditor/php/upload/image/20171215/1513309191689455.png\" title=\"1513309191689455.png\" alt=\"10.png\"/></p>', '家具风水', '1');
INSERT INTO `tbl_news` VALUES ('16', '', '惊呆！大新闻！', '小枫', '2017-11-07 14:37:18', null, '涨工资啦', '<p>惊呆！大新闻！xxxx</p>', null, '1');
INSERT INTO `tbl_news` VALUES ('9', '20171223\\b5089a9b8828944780cf3026b0ab3557.jpg', '亮眼！习近平新时代中国特色社会主义经济思想', '作者', '2017-11-07 08:39:33', '2', '【学习进行时】中【学习进行时】中央经济【学习进行时】中央经济工作会议12月18日至20日在北京举行。会议首次提出习近【学习进行时】中央经济【学习进行时】中央经济工作会议12月18日至20日在北京举行。会议首次提出习近【学习进行时】中央经济【学习进行时】中央经济工作会议12月18日至20日在北京举行。会议首次提出习近【学习进行时】中央经济【学习进行时】中央经济工作会议12月18日至20日在北京举行。会议首次提出习近【学习进行时】中央经济【学习进行时】中央经济工作会议12月18日至20日在北京举行。会议首次提', '<p>亮眼！习近平新时代中国特色社会主义经济思想</p><p><span class=\"sub-time\"><span class=\"h-time\" style=\"margin-right: 20px;\">2017-12-22 15:10:06</span>&nbsp;</span><span class=\"sub-src\">来源：&nbsp;<span class=\"aticle-src\">新华网</span></span></p><p><br/></p><p><br/></p><p style=\"margin-top: 0px; margin-bottom: 15px; padding: 0px;\"><span style=\"font-size: 12pt;\"><span style=\"font-family:楷体\"><span style=\"font-size: 14pt;\"><span style=\"font-size: 12pt;\"><span style=\"font-size: 12pt;\">　　【学习进行时】</span><span style=\"font-size: 12pt;\">中央经济工作会议12月18日至20日在北京举行。会议首次提出习近平新时代中国特色社会主义经济思想，成为各界关注的焦点。这一思想有何特点？内涵是什么？对我国经济发展有何重要意义？新华社《学习进行时》原创品牌栏目“讲习所”今天推出文章，为您解读。</span></span></span></span></span></p><p style=\"margin-top: 0px; margin-bottom: 15px; padding: 0px;\"><span style=\"font-size: 12pt;\"><span style=\"font-family:仿宋\"><span style=\"font-size: 12pt;\"><span style=\"font-size: 12pt; font-family: 微软雅黑;\"><span style=\"font-size: 12pt;\"><span style=\"font-family:微软雅黑\"><span style=\"font-size: 12pt;\"><span style=\"font-weight: 600 !important;\"><a style=\"outline: none; color: rgb(51, 51, 51); position: relative; display: block;\"><img id=\"{6466D34B-EEEB-4943-B110-E18F49A22C15}\" title=\"\" alt=\"（时政）习近平在中央经济工作会议上发表重要讲话\" align=\"center\" src=\"/ueditor/php/upload/image/20171223/1513993836751291.jpg\" sourcedescription=\"网上抓取的文件\" sourcename=\"本地文件\" style=\"border: 0px; vertical-align: middle; display: block; width: auto; text-align: center; margin: 0px auto;\"/></a></span></span></span></span></span></span></span></span></p><p><span style=\"color:navy;font-family:楷体;font-size: 12pt;\"><span style=\"font-size: 12pt;\"><span style=\"font-size: 12pt;\"><span style=\"font-weight: 600 !important;\">　　</span>12月18日至20日，中央经济工作会议在北京举行。中共中央总书记、国家主席、中央军委主席习近平发表重要讲话。新华社记者 谢环驰 摄</span></span></span></p><p style=\"margin-top: 0px; margin-bottom: 15px; padding: 0px; font-size: 12pt;\"><img src=\"/ueditor/php/upload/image/20171223/1513994540191749.jpg\" title=\"1513994540191749.jpg\" alt=\"1-141113001224.jpg\"/></p><p style=\"margin-top: 0px; margin-bottom: 15px; padding: 0px; font-size: 12pt;\"><span style=\"font-size: 12pt; font-family: 微软雅黑;\"><span style=\"font-size: 12pt;\"><span style=\"font-family:微软雅黑\"><span style=\"font-size: 12pt;\"><span style=\"font-size: 12pt;\"><span style=\"font-size: 12pt;\">　　12月18日至20日</span><span style=\"font-size: 12pt;\">举行的</span><span style=\"font-size: 12pt;\">中央经济工作会议，最大亮点就是提出了</span><span style=\"font-size: 12pt;\">习近平新时代中国特色社会主义经济思想。</span></span></span></span></span></span></p><p style=\"margin-top: 0px; margin-bottom: 15px; padding: 0px; font-size: 12pt;\"><span style=\"font-size: 12pt;\"><span style=\"font-family:微软雅黑\"><span style=\"font-size: 12pt;\"><span style=\"font-size: 12pt;\"><span style=\"font-size: 12pt;\">　　这个经济思想是</span><span style=\"font-size: 12pt;\">习近平新时代中国特色社会主义思想</span><span style=\"font-size: 12pt;\">的重要组成部分。</span></span></span></span></span></p><p style=\"margin-top: 0px; margin-bottom: 15px; padding: 0px; font-size: 12pt;\"><span style=\"font-size: 12pt; font-family: 微软雅黑;\"><span style=\"font-size: 12pt;\"><span style=\"font-family:微软雅黑\"><span style=\"font-size: 12pt;\"><span style=\"font-size: 12pt;\"><strong><span style=\"font-size: 12pt;\"><span style=\"color:navy\">　　三大</span></span></strong><span style=\"color:navy\"><strong><span style=\"font-size: 12pt;\">特点</span></strong><strong><span style=\"font-size: 12pt;\">：观大势、谋全局、干实事</span></strong></span></span></span></span></span></span></p><p style=\"margin-top: 0px; margin-bottom: 15px; padding: 0px; font-size: 12pt;\"><span style=\"font-size: 12pt; font-family: 微软雅黑;\"><span style=\"font-family:微软雅黑;font-size: 12pt;\">　　中央经济工作会议指出，五年来，我们坚持观大势、谋全局、干实事，成功驾驭了我国经济发展大局，在实践中形成了以新发展理念为主要内容的习近平新时代中国特色社会主义经济思想。</span></span></p><p style=\"margin-top: 0px; margin-bottom: 15px; padding: 0px; font-size: 12pt;\"><span style=\"font-size: 12pt;\"><span style=\"font-family:微软雅黑\"><span style=\"font-size: 12pt;\"><span style=\"font-size: 12pt;\"><span style=\"font-size: 12pt;\">　　“观大势、谋全局、干实事”，这</span><span style=\"font-size: 12pt;\">三</span><span style=\"font-size: 12pt;\">个关键词不但高度概括了习近平新时代中国特色社会主义经济思想的形成过程，</span><span style=\"font-size: 12pt;\">同时</span><span style=\"font-size: 12pt;\">也</span><span style=\"font-size: 12pt;\">体现</span><span style=\"font-size: 12pt;\">了它的</span><span style=\"font-size: 12pt;\">三</span><span style=\"font-size: 12pt;\">个突出特点。</span></span></span></span></span></p><p style=\"margin-top: 0px; margin-bottom: 15px; padding: 0px; font-size: 12pt;\"><span style=\"font-size: 12pt;\"><strong><span style=\"font-size: 12pt; font-family: 微软雅黑;\"><span style=\"font-family:微软雅黑;font-size: 12pt;\">　　·<span style=\"color:navy;font-family:楷体\">观大势</span></span></span></strong><strong style=\"font-family: 楷体;\"></strong></span></p><p style=\"margin-top: 0px; margin-bottom: 15px; padding: 0px; font-size: 12pt;\"><span style=\"font-size: 12pt;\"><span style=\"font-family:微软雅黑\"><span style=\"font-size: 12pt;\"><span style=\"font-size: 12pt;\"><span style=\"font-size: 12pt;\">　　中国经济正在经历一个优化升级的节点。十八大以来，习近平从时间和空间大角度审视我国发展，2014年</span><span style=\"font-size: 12pt;\">5月</span><span style=\"font-size: 12pt;\">在河南考察时，首次提出“新常态”这一概念。同年12月，习近平主持中央政治局会议，作出“我国进入经济发展新常态”这一重要论断。</span></span></span></span></span></p><p style=\"margin-top: 0px; margin-bottom: 15px; padding: 0px; font-size: 12pt;\"><span style=\"font-size: 12pt;\"><span style=\"font-family:微软雅黑\"><span style=\"font-size: 12pt;\"><span style=\"font-size: 12pt;\"><span style=\"font-size: 12pt;\">　　“新常态”，就是“大势”。新常态下，我国经济发展表现出速度变化、结构优化、动力转换这</span><span style=\"font-size: 12pt;\">三个特点</span><span style=\"font-size: 12pt;\">。这些变化是经济发展阶段性特征的必然要求，是我国经济由高速增长阶段转向高质量发展阶段的必经过程。</span></span></span></span></span></p><p style=\"margin-top: 0px; margin-bottom: 15px; padding: 0px; font-size: 12pt;\"><span style=\"font-size: 12pt;\"><span style=\"font-family:微软雅黑\"><span style=\"font-size: 12pt;\"><span style=\"font-size: 12pt;\"><span style=\"font-size: 12pt;\">　　“明者因时而变，知者随世而制”。身处这样的大势，就要因势而谋、因势而动、因势而进。深入理解习近平对经济工作的一系列重要阐述和</span><span style=\"font-size: 12pt;\">战略谋划，适应新常态、把握新常态、引领新常态，</span><span style=\"font-size: 12pt;\">实现</span><span style=\"font-size: 12pt;\">高质量发展，</span><span style=\"font-size: 12pt;\">始终是内在的</span><span style=\"font-size: 12pt;\">总要求</span><span style=\"font-size: 12pt;\">和大逻辑</span><span style=\"font-size: 12pt;\">。</span></span></span></span></span></p><p style=\"margin-top: 0px; margin-bottom: 15px; padding: 0px; font-size: 12pt;\"><strong><span style=\"font-size: 12pt; font-family: 微软雅黑;\"><span style=\"font-family:微软雅黑;font-size: 12pt;\"><span style=\"font-size: 12pt;\"><span style=\"font-size: 12pt;\">　　·<span style=\"color:navy;font-family:楷体\">谋全局</span></span></span></span></span></strong></p><p style=\"margin-top: 0px; margin-bottom: 15px; padding: 0px; font-size: 12pt;\"><span style=\"font-size: 12pt;\"><span style=\"font-family:微软雅黑\"><span style=\"font-size: 12pt;\"><span style=\"font-size: 12pt;\"><span style=\"font-size: 12pt;\">　　发展理念是管全局、管根本、管方向、管长远的行动指引</span><span style=\"font-size: 12pt;\">。十八大以来，习近平提出创新、协调、绿色、开放、共享的新发展理念。这五大理念相互贯通、相互促进，不是解决一个两个具体的发展问题，而是从全局整体上破解发展难题、增强发展动力、厚植发展优势。</span></span></span></span></span></p><p style=\"margin-top: 0px; margin-bottom: 15px; padding: 0px; font-size: 12pt;\"><span style=\"font-size: 12pt; font-family: 微软雅黑;\"><span style=\"font-family:微软雅黑;font-size: 12pt;\">　　十八届五中全会，新发展理念作为“十三五”规划的灵魂，贯穿和统领着整份文件，这就是要以明确的发展思路、发展方向、发展着力点统筹起方方面面的工作，谋划“十三五”乃至更长时期我国发展的全局。</span></span></p><p style=\"margin-top: 0px; margin-bottom: 15px; padding: 0px; font-size: 12pt;\"><span style=\"font-size: 12pt;\"><strong><span style=\"font-size: 12pt; font-family: 微软雅黑;\"><span style=\"font-family:微软雅黑;font-size: 12pt;\">　　·<span style=\"color:navy;font-family:楷体\">干实事</span></span></span></strong><strong style=\"font-family: 楷体;\"></strong></span></p><p style=\"margin-top: 0px; margin-bottom: 15px; padding: 0px; font-size: 12pt;\"><span style=\"font-size: 12pt; font-family: 微软雅黑;\"><span style=\"font-family:微软雅黑;font-size: 12pt;\">　　“实干兴邦”是习近平治国理政的内在要求。习近平常说，“一分部署，九分落实”。五年来，抓发展，他强调不简单以GDP增长率论英雄；抓产业，他强调要防止脱实向虚；抓环保，他强调要专项督察、推动落实……求真务实的精神，始终是习近平抓各项工作的一条红线。</span></span></p><p style=\"margin-top: 0px; margin-bottom: 15px; padding: 0px; font-size: 12pt;\"><span style=\"font-size: 12pt; font-family: 微软雅黑;\"><span style=\"font-family:微软雅黑;font-size: 12pt;\">　　这五年，我国经济年均增长7.1%，国内生产总值从54万亿元增长到80万亿元，稳居世界第二，对世界经济增长贡献率超过30%。这五年，经济结构出现重大变革，经济体制改革持续推进，对外开放深入发展，人民获得感、幸福感明显增强，生态环境状况明显好转，我国经济发展取得历史性成就、发生历史性变革，迈进了新时代。</span></span></p><p style=\"margin-top: 0px; margin-bottom: 15px; padding: 0px; font-size: 12pt;\"><span style=\"font-size: 12pt; font-family: 微软雅黑;\"><span style=\"font-family:微软雅黑;font-size: 12pt;\">　　这是“干实事”所取得的丰硕成果。</span></span></p><p style=\"margin-top: 0px; margin-bottom: 15px; padding: 0px; font-size: 12pt;\"><span style=\"font-size: 12pt; font-family: 微软雅黑;\"><span style=\"font-family:微软雅黑;font-size: 12pt;\">　　面对我国发展要跨越的一大重要关口，中央经济工作会议对打好三大攻坚战作出强力部署，围绕推动高质量发展，安排了八项重点工作。“干实事”就要锲而不舍，“一张蓝图绘到底”。</span></span></p><p style=\"margin-top: 0px; margin-bottom: 15px; padding: 0px; font-size: 12pt;\"><span style=\"font-size: 12pt; font-family: 微软雅黑;\"><strong><span style=\"font-size: 12pt;\"><span style=\"font-family:微软雅黑;font-size: 12pt;\"><span style=\"color:navy;font-size: 12pt;\">　　“七个坚持”：紧密联系、自成体系</span></span></span></strong></span></p><p style=\"margin-top: 0px; margin-bottom: 15px; padding: 0px; font-size: 12pt;\"><span style=\"font-size: 12pt; font-family: 微软雅黑;\"><span style=\"font-family:微软雅黑;font-size: 12pt;\">　　中央经济工作会议提出“七个坚持”，构成习近平新时代中国特色社会主义经济思想的七方面内涵。</span></span></p><p style=\"margin-top: 0px; margin-bottom: 15px; padding: 0px; font-size: 12pt;\"><span style=\"font-size: 12pt; font-family: 微软雅黑;\"><span style=\"font-family:微软雅黑;font-size: 12pt;\">　　“七个坚持”紧密联系，既有认识论，又有方法论，组成一个完整体系。</span></span></p><p style=\"margin-top: 0px; margin-bottom: 15px; padding: 0px; font-size: 12pt;\"><span style=\"font-size: 12pt;\"><span style=\"font-family:微软雅黑\"><span style=\"font-size: 12pt;\"><span style=\"font-size: 12pt;\"><strong><span style=\"font-size: 12pt;\">　　·<span style=\"color:navy;font-family:楷体\">“坚持加强党对经济工作的集中统一领导”居于首位，是总领性、根本性的。</span></span></strong><strong style=\"font-family: 楷体; color: navy;\"></strong></span></span></span></span></p><p style=\"margin-top: 0px; margin-bottom: 15px; padding: 0px; font-size: 12pt;\"><span style=\"font-size: 12pt; font-family: 微软雅黑;\"><span style=\"font-family:微软雅黑;font-size: 12pt;\">　　在习近平新时代中国特色社会主义思想的十四条基本方略中，首先就强调坚持党对一切工作的领导。</span></span></p><p style=\"margin-top: 0px; margin-bottom: 15px; padding: 0px; font-size: 12pt;\"><span style=\"font-size: 12pt; font-family: 微软雅黑;\"><span style=\"font-family:微软雅黑;font-size: 12pt;\">　　五年来，以习近平同志为核心的党中央把方向、谋大局、定政策、促改革，始终总揽全局、协调各方，推动我国经济发展取得历史性成就、发生历史性变革，为其他领域改革发展提供了重要物质条件。</span></span></p><p style=\"margin-top: 0px; margin-bottom: 15px; padding: 0px; font-size: 12pt;\"><span style=\"font-size: 12pt; font-family: 微软雅黑;\"><span style=\"font-family:微软雅黑;font-size: 12pt;\">　　面对愈益复杂的国际国内经济环境，坚持加强党对经济工作的集中统一领导，显得愈加重要。</span></span></p><p style=\"margin-top: 0px; margin-bottom: 15px; padding: 0px; font-size: 12pt;\"><strong><span style=\"font-size: 12pt; font-family: 微软雅黑;\"><span style=\"font-family:微软雅黑;font-size: 12pt;\"><span style=\"font-size: 12pt;\"><span style=\"font-size: 12pt;\">　　·<span style=\"color:navy;font-family:楷体\">“坚持以人民为中心的发展思想”是经济发展的根本目的。</span></span></span></span></span></strong></p><p style=\"margin-top: 0px; margin-bottom: 15px; padding: 0px; font-size: 12pt;\"><span style=\"font-size: 12pt; font-family: 微软雅黑;\"><span style=\"font-family:微软雅黑;font-size: 12pt;\">　　明确为什么人、靠什么人，是一切发展的前提。坚持以人民为中心的发展思想，就是明确发展为了人民、发展依靠人民、发展成果由人民共享。</span></span></p><p style=\"margin-top: 0px; margin-bottom: 15px; padding: 0px; font-size: 12pt;\"><span style=\"font-size: 12pt; font-family: 微软雅黑;\"><span style=\"font-family:微软雅黑;font-size: 12pt;\">　　5年来，以习近平同志为核心的党中央把人民放在最高位置，将以人民为中心的发展思想贯穿到统筹推进“五位一体”总体布局和协调推进“四个全面”战略布局之中。</span></span></p><p style=\"margin-top: 0px; margin-bottom: 15px; padding: 0px; font-size: 12pt;\"><span style=\"font-size: 12pt; font-family: 微软雅黑;\"><span style=\"font-family:微软雅黑;font-size: 12pt;\">　　人民拥护不拥护、赞成不赞成、高兴不高兴、答应不答应，过去、现在、将来都是衡量一切工作得失的根本标准。纵观习近平提出的一系列新的重要思想、重要观点、重大判断、重大举措，本质上都是为了实现人民对美好生活的向往。</span></span></p><p style=\"margin-top: 0px; margin-bottom: 15px; padding: 0px; font-size: 12pt;\"><span style=\"font-size: 12pt;\"><span style=\"font-family:微软雅黑\"><span style=\"font-size: 12pt;\"><span style=\"font-size: 12pt;\"><strong><span style=\"font-size: 12pt;\">　　·<span style=\"color:navy;font-family:楷体\">后五个“坚持”是实现高质量发展的重要途径。</span></span></strong><strong style=\"font-family: 楷体; color: navy;\"></strong></span></span></span></span></p><p style=\"margin-top: 0px; margin-bottom: 15px; padding: 0px; font-size: 12pt;\"><span style=\"font-size: 12pt; font-family: 微软雅黑;\"><span style=\"font-family:微软雅黑;font-size: 12pt;\">　　党的十九大指出，进入新时代，我国社会主要矛盾已经转化为人民日益增长的美好生活需要和不平衡不充分的发展之间的矛盾。在新时代，我国经济的基本特征就是已由高速增长阶段转向高质量发展阶段。</span></span></p><p style=\"margin-top: 0px; margin-bottom: 15px; padding: 0px; font-size: 12pt;\"><span style=\"font-size: 12pt; font-family: 微软雅黑;\"><span style=\"font-family:微软雅黑;font-size: 12pt;\">　　坚持适应把握引领经济发展新常态，立足大局，把握规律；</span></span></p><p style=\"margin-top: 0px; margin-bottom: 15px; padding: 0px; font-size: 12pt;\"><span style=\"font-size: 12pt; font-family: 微软雅黑;\"><span style=\"font-family:微软雅黑;font-size: 12pt;\">　　坚持使市场在资源配置中起决定性作用，更好发挥政府作用，坚决扫除经济发展的体制机制障碍；</span></span></p><p style=\"margin-top: 0px; margin-bottom: 15px; padding: 0px; font-size: 12pt;\"><span style=\"font-size: 12pt; font-family: 微软雅黑;\"><span style=\"font-family:微软雅黑;font-size: 12pt;\">　　坚持适应我国经济发展主要矛盾变化完善宏观调控，相机抉择，开准药方，把推进供给侧结构性改革作为经济工作的主线；</span></span></p><p style=\"margin-top: 0px; margin-bottom: 15px; padding: 0px; font-size: 12pt;\"><span style=\"font-size: 12pt; font-family: 微软雅黑;\"><span style=\"font-family:微软雅黑;font-size: 12pt;\">　　坚持问题导向部署经济发展新战略，对我国经济社会发展变革产生了深远影响；</span></span></p><p style=\"margin-top: 0px; margin-bottom: 15px; padding: 0px; font-size: 12pt;\"><span style=\"font-size: 12pt; font-family: 微软雅黑;\"><span style=\"font-family:微软雅黑;font-size: 12pt;\">　　坚持正确工作策略和方法，主要是稳中求进，保持战略定力、坚持底线思维，一步一个脚印向前迈进。</span></span></p><p><br/></p>', '家装设计', '1');
INSERT INTO `tbl_news` VALUES ('21', '20171222\\7e213ed78072de99d5e1bc5f3bafaa42.jpg', '订单', '订单', '2017-11-17 13:55:19', '0', '订单', '<p>的</p>', '家装指南', '1');
INSERT INTO `tbl_news` VALUES ('22', '20171222\\899a41206578fa8bdfd0e4c146def78a.png', '所属所属', '所属', '2017-11-17 13:57:42', '0', '是', '<p>所属</p>', '家装指南', '1');
INSERT INTO `tbl_news` VALUES ('23', '20171222\\30b33ebdf74e4f07c11b03fabce7f85a.png', '幸运抢红包活动开始了!', '所属', '2017-11-17 14:02:16', '0', '所属', '<p>所属</p>', '家装指南', '1');
INSERT INTO `tbl_news` VALUES ('24', 'D:\\phpStudy\\WWW\\shengteng_latest\\public\\uploads\\20171117\\e58ab463d4aa736c01a79b6ec49402e9.png', '测试文章标题', '订单', '2017-11-17 14:05:22', '0', '订单', '<p>滚滚滚</p>', null, '1');
INSERT INTO `tbl_news` VALUES ('25', '没有上传过图片', '测试文章标题', '订单', '2017-11-17 14:07:25', '0', '订单', '<p>的点点滴滴多</p>', null, '1');
INSERT INTO `tbl_news` VALUES ('26', '没有上传过图片', '对对对', '订单', '2017-11-19 09:58:22', '0', '订单', '<p><img src=\"/ueditor/php/upload/image/20171215/1513317156789676.png\" title=\"1513317156789676.png\" alt=\"1.png\"/></p>', null, '1');
INSERT INTO `tbl_news` VALUES ('27', 'D:\\phpStudy\\WWW\\shengteng-group\\public\\uploads\\20171222\\eb2743fc7f407e32ef7ba63b893a3017.png', '测试', '管理员', '2017-12-22 15:12:05', '0', '文章简介：文章简介：文章简介：', '<p><span style=\"color: rgb(51, 51, 51); font-family: &quot;Microsoft Yahei&quot;, &quot;Hiragino Sans GB&quot;, &quot;Helvetica Neue&quot;, Helvetica, tahoma, arial, &quot;WenQuanYi Micro Hei&quot;, Verdana, sans-serif, 宋体; font-size: 12px; font-weight: 700; background-color: rgb(255, 255, 255);\"><img src=\"/ueditor/php/upload/image/20171222/1513927421130592.png\" title=\"1513927421130592.png\" alt=\"selected_case_detail_form_banner.png\"/>文章简介：</span><span style=\"color: rgb(51, 51, 51); font-family: &quot;Microsoft Yahei&quot;, &quot;Hiragino Sans GB&quot;, &quot;Helvetica Neue&quot;, Helvetica, tahoma, arial, &quot;WenQuanYi Micro Hei&quot;, Verdana, sans-serif, 宋体; font-size: 12px; font-weight: 700; background-color: rgb(255, 255, 255);\">文章简介：</span><span style=\"color: rgb(51, 51, 51); font-family: &quot;Microsoft Yahei&quot;, &quot;Hiragino Sans GB&quot;, &quot;Helvetica Neue&quot;, Helvetica, tahoma, arial, &quot;WenQuanYi Micro Hei&quot;, Verdana, sans-serif, 宋体; font-size: 12px; font-weight: 700; background-color: rgb(255, 255, 255);\">文章简介：</span></p>', '家装指南', '1');
INSERT INTO `tbl_news` VALUES ('28', '20171222\\7148577f02baa59bd7fc6db170af00a9.jpg', '的点点滴滴多', '管理员', '2017-12-22 16:39:09', '0', '文章简介：文章简介：文章简介：文章简介：文章简介：文章简介：文章简介：文章简介：文章简介：文章简介：', '<p><span style=\"color: rgb(51, 51, 51); font-family: &quot;Microsoft Yahei&quot;, &quot;Hiragino Sans GB&quot;, &quot;Helvetica Neue&quot;, Helvetica, tahoma, arial, &quot;WenQuanYi Micro Hei&quot;, Verdana, sans-serif, 宋体; font-size: 12px; font-weight: 700; text-align: center; background-color: rgb(255, 255, 255);\">文章简介：</span><span style=\"color: rgb(51, 51, 51); font-family: &quot;Microsoft Yahei&quot;, &quot;Hiragino Sans GB&quot;, &quot;Helvetica Neue&quot;, Helvetica, tahoma, arial, &quot;WenQuanYi Micro Hei&quot;, Verdana, sans-serif, 宋体; font-size: 12px; font-weight: 700; text-align: center; background-color: rgb(255, 255, 255);\">文章简介：</span><span style=\"color: rgb(51, 51, 51); font-family: &quot;Microsoft Yahei&quot;, &quot;Hiragino Sans GB&quot;, &quot;Helvetica Neue&quot;, Helvetica, tahoma, arial, &quot;WenQuanYi Micro Hei&quot;, Verdana, sans-serif, 宋体; font-size: 12px; font-weight: 700; text-align: center; background-color: rgb(255, 255, 255);\">文章简介：</span><span style=\"color: rgb(51, 51, 51); font-family: &quot;Microsoft Yahei&quot;, &quot;Hiragino Sans GB&quot;, &quot;Helvetica Neue&quot;, Helvetica, tahoma, arial, &quot;WenQuanYi Micro Hei&quot;, Verdana, sans-serif, 宋体; font-size: 12px; font-weight: 700; text-align: center; background-color: rgb(255, 255, 255);\">文章简介：</span><span style=\"color: rgb(51, 51, 51); font-family: &quot;Microsoft Yahei&quot;, &quot;Hiragino Sans GB&quot;, &quot;Helvetica Neue&quot;, Helvetica, tahoma, arial, &quot;WenQuanYi Micro Hei&quot;, Verdana, sans-serif, 宋体; font-size: 12px; font-weight: 700; text-align: center; background-color: rgb(255, 255, 255);\">文章简介：</span><span style=\"background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-family: &quot;Microsoft Yahei&quot;, &quot;Hiragino Sans GB&quot;, &quot;Helvetica Neue&quot;, Helvetica, tahoma, arial, &quot;WenQuanYi Micro Hei&quot;, Verdana, sans-serif, 宋体; font-size: 12px; font-weight: 700; text-align: center;\">文章简介：</span><span style=\"color: rgb(51, 51, 51); font-family: &quot;Microsoft Yahei&quot;, &quot;Hiragino Sans GB&quot;, &quot;Helvetica Neue&quot;, Helvetica, tahoma, arial, &quot;WenQuanYi Micro Hei&quot;, Verdana, sans-serif, 宋体; font-size: 12px; font-weight: 700; text-align: center; background-color: rgb(255, 255, 255);\">文章简介：</span><span style=\"color: rgb(51, 51, 51); font-family: &quot;Microsoft Yahei&quot;, &quot;Hiragino Sans GB&quot;, &quot;Helvetica Neue&quot;, Helvetica, tahoma, arial, &quot;WenQuanYi Micro Hei&quot;, Verdana, sans-serif, 宋体; font-size: 12px; font-weight: 700; text-align: center; background-color: rgb(255, 255, 255);\">文章简介：</span><span style=\"background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-family: &quot;Microsoft Yahei&quot;, &quot;Hiragino Sans GB&quot;, &quot;Helvetica Neue&quot;, Helvetica, tahoma, arial, &quot;WenQuanYi Micro Hei&quot;, Verdana, sans-serif, 宋体; font-size: 12px; font-weight: 700; text-align: center;\">文章简介：</span><span style=\"background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-family: &quot;Microsoft Yahei&quot;, &quot;Hiragino Sans GB&quot;, &quot;Helvetica Neue&quot;, Helvetica, tahoma, arial, &quot;WenQuanYi Micro Hei&quot;, Verdana, sans-serif, 宋体; font-size: 12px; font-weight: 700; text-align: center;\">文章简介：</span><span style=\"background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-family: &quot;Microsoft Yahei&quot;, &quot;Hiragino Sans GB&quot;, &quot;Helvetica Neue&quot;, Helvetica, tahoma, arial, &quot;WenQuanYi Micro Hei&quot;, Verdana, sans-serif, 宋体; font-size: 12px; font-weight: 700; text-align: center;\">文章简介：</span><span style=\"color: rgb(51, 51, 51); font-family: &quot;Microsoft Yahei&quot;, &quot;Hiragino Sans GB&quot;, &quot;Helvetica Neue&quot;, Helvetica, tahoma, arial, &quot;WenQuanYi Micro Hei&quot;, Verdana, sans-serif, 宋体; font-size: 12px; font-weight: 700; text-align: center; background-color: rgb(255, 255, 255);\">文章简介：</span><span style=\"background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-family: &quot;Microsoft Yahei&quot;, &quot;Hiragino Sans GB&quot;, &quot;Helvetica Neue&quot;, Helvetica, tahoma, arial, &quot;WenQuanYi Micro Hei&quot;, Verdana, sans-serif, 宋体; font-size: 12px; font-weight: 700; text-align: center;\">文章简介：</span><span style=\"color: rgb(51, 51, 51); font-family: &quot;Microsoft Yahei&quot;, &quot;Hiragino Sans GB&quot;, &quot;Helvetica Neue&quot;, Helvetica, tahoma, arial, &quot;WenQuanYi Micro Hei&quot;, Verdana, sans-serif, 宋体; font-size: 12px; font-weight: 700; text-align: center; background-color: rgb(255, 255, 255);\">文章简介：</span><span style=\"background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-family: &quot;Microsoft Yahei&quot;, &quot;Hiragino Sans GB&quot;, &quot;Helvetica Neue&quot;, Helvetica, tahoma, arial, &quot;WenQuanYi Micro Hei&quot;, Verdana, sans-serif, 宋体; font-size: 12px; font-weight: 700; text-align: center;\">文章简介：</span><span style=\"background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-family: &quot;Microsoft Yahei&quot;, &quot;Hiragino Sans GB&quot;, &quot;Helvetica Neue&quot;, Helvetica, tahoma, arial, &quot;WenQuanYi Micro Hei&quot;, Verdana, sans-serif, 宋体; font-size: 12px; font-weight: 700; text-align: center;\">文章简介：</span><span style=\"background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-family: &quot;Microsoft Yahei&quot;, &quot;Hiragino Sans GB&quot;, &quot;Helvetica Neue&quot;, Helvetica, tahoma, arial, &quot;WenQuanYi Micro Hei&quot;, Verdana, sans-serif, 宋体; font-size: 12px; font-weight: 700; text-align: center;\">文章简介：</span><span style=\"color: rgb(51, 51, 51); font-family: &quot;Microsoft Yahei&quot;, &quot;Hiragino Sans GB&quot;, &quot;Helvetica Neue&quot;, Helvetica, tahoma, arial, &quot;WenQuanYi Micro Hei&quot;, Verdana, sans-serif, 宋体; font-size: 12px; font-weight: 700; text-align: center; background-color: rgb(255, 255, 255);\">文章简介：</span><span style=\"background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-family: &quot;Microsoft Yahei&quot;, &quot;Hiragino Sans GB&quot;, &quot;Helvetica Neue&quot;, Helvetica, tahoma, arial, &quot;WenQuanYi Micro Hei&quot;, Verdana, sans-serif, 宋体; font-size: 12px; font-weight: 700; text-align: center;\">文章简介：</span><span style=\"background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-family: &quot;Microsoft Yahei&quot;, &quot;Hiragino Sans GB&quot;, &quot;Helvetica Neue&quot;, Helvetica, tahoma, arial, &quot;WenQuanYi Micro Hei&quot;, Verdana, sans-serif, 宋体; font-size: 12px; font-weight: 700; text-align: center;\">文章简介：</span><span style=\"color: rgb(51, 51, 51); font-family: &quot;Microsoft Yahei&quot;, &quot;Hiragino Sans GB&quot;, &quot;Helvetica Neue&quot;, Helvetica, tahoma, arial, &quot;WenQuanYi Micro Hei&quot;, Verdana, sans-serif, 宋体; font-size: 12px; font-weight: 700; text-align: center; background-color: rgb(255, 255, 255);\">文章简介：</span></p>', '家装指南', '1');

-- ----------------------------
-- Table structure for tbl_order
-- ----------------------------
DROP TABLE IF EXISTS `tbl_order`;
CREATE TABLE `tbl_order` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '表ID',
  `name` varchar(30) DEFAULT NULL COMMENT '预约姓名',
  `tel` char(20) NOT NULL COMMENT '预约电话',
  `addr` varchar(100) DEFAULT NULL COMMENT '预约地址',
  `area` int(10) DEFAULT NULL COMMENT '预约房屋面积',
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '提交时间',
  `from` varchar(20) DEFAULT '空' COMMENT '订单来自',
  `remark` varchar(50) DEFAULT '无' COMMENT '客户预约表备注',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=50 DEFAULT CHARSET=utf8 COMMENT='客户在线预约报名表';

-- ----------------------------
-- Records of tbl_order
-- ----------------------------
INSERT INTO `tbl_order` VALUES ('27', '李树霞', '17604788812', '呼和浩特中海凯旋门', '127', '2017-12-02 19:39:27', '手机', '新年家装铁锤行动');
INSERT INTO `tbl_order` VALUES ('26', '张得良', '18604715903', '华茂名居', '159', '2017-12-01 21:57:38', '手机', '新年家装铁锤行动');
INSERT INTO `tbl_order` VALUES ('28', '马敏', '13195625887', '安徽省铜陵市狮子山区铜井路栖凤名城', '117', '2017-12-03 08:12:50', '手机', '新年家装铁锤行动');
INSERT INTO `tbl_order` VALUES ('30', '葛海峰', '13734746155', '乌兰察布集宁区', '158', '2017-12-04 17:07:16', '手机', '新年家装铁锤行动');
INSERT INTO `tbl_order` VALUES ('31', '郑先生', '15029950922', '西安曲江', '121', '2017-12-08 19:56:26', '手机', '新年家装铁锤行动');
INSERT INTO `tbl_order` VALUES ('32', '郑', '15029950922', '西安', '121', '2017-12-09 07:26:44', '手机', '新年家装铁锤行动');
INSERT INTO `tbl_order` VALUES ('33', '陆唯安', '13805605616', '滨湖高速时代广场', '65', '2017-12-09 07:31:23', '手机', '新年家装铁锤行动');
INSERT INTO `tbl_order` VALUES ('34', '倪玉凤', '13365686307', '六安市裕安区平安小区', '118', '2017-12-09 19:52:35', '手机', '新年家装铁锤行动');
INSERT INTO `tbl_order` VALUES ('35', '李女士', '17686018393', '万光府前花园', '135', '2017-12-09 23:50:56', '手机', '新年家装铁锤行动');
INSERT INTO `tbl_order` VALUES ('36', '李洪波', '15184710861', '观澜国际B', '113', '2017-12-11 12:17:59', '手机', '新年家装铁锤行动');
INSERT INTO `tbl_order` VALUES ('37', '李洪波', '15184710861', '观澜国际B区1-1-701号', '113', '2017-12-11 12:29:23', '手机', '新年家装铁锤行动');
INSERT INTO `tbl_order` VALUES ('38', '李子文', '18905525718', '蚌埠市淮上区上河时代(北区)', '0', '2017-12-13 19:12:28', '手机', '新年家装铁锤行动');
INSERT INTO `tbl_order` VALUES ('39', '谷伟业', '18132046111', '石家庄栾城', '127', '2017-12-14 20:17:59', '手机', '新年家装铁锤行动');
INSERT INTO `tbl_order` VALUES ('40', '莫蕾娜', '13606631676', '萧山区世纪外滩花园（水博园旁）', '90', '2017-12-15 21:23:33', '手机', '新年家装铁锤行动');
INSERT INTO `tbl_order` VALUES ('41', '吕志勇', '13805562480', '无锡', '121', '2017-12-16 15:46:41', '手机', '新年家装铁锤行动');
INSERT INTO `tbl_order` VALUES ('42', '王计英', '15369054411', '河北省邯郸市馆陶县', '140', '2017-12-17 22:49:40', '手机', '新年家装铁锤行动');
INSERT INTO `tbl_order` VALUES ('43', '王瑞', '15385955552', '安徽六安柏庄春暖花开', '86', '2017-12-18 11:54:27', '手机', '新年家装铁锤行动');
INSERT INTO `tbl_order` VALUES ('44', '王伟', '15375352502', '滨湖顺园', '135', '2017-12-18 20:30:34', '手机', '新年家装铁锤行动');
INSERT INTO `tbl_order` VALUES ('45', '王伟', '15375352502', '滨湖顺园', '135', '2017-12-18 21:00:18', '手机', '新年家装铁锤行动');
INSERT INTO `tbl_order` VALUES ('46', '崔美英', '15848182794', '呼和浩特市 富兴巷', '68', '2017-12-19 23:23:28', '手机', '新年家装铁锤行动');
INSERT INTO `tbl_order` VALUES ('47', '王合喜', '15345587038', '颍上县瀚海御水兰亭', '128', '2017-12-21 21:17:22', '手机', '新年家装铁锤行动');
INSERT INTO `tbl_order` VALUES ('48', '你猜', '18888888', '安徽', '4150', '2017-12-22 16:53:13', 'PC', '合肥');
INSERT INTO `tbl_order` VALUES ('49', '孙其晖', '13856548887', '巢湖市琥珀新天地', '86', '2017-12-22 21:06:07', '手机', '新年家装铁锤行动');

-- ----------------------------
-- Table structure for tbl_user
-- ----------------------------
DROP TABLE IF EXISTS `tbl_user`;
CREATE TABLE `tbl_user` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `userName` varchar(20) NOT NULL COMMENT '用户名称',
  `userPass` varchar(10) NOT NULL COMMENT '用户密码',
  `group` varchar(255) DEFAULT NULL COMMENT '用户组',
  `lastLoginTime` varchar(30) DEFAULT NULL COMMENT '上次登陆时间',
  `registerTime` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '注册时间',
  `userLoginNums` int(10) DEFAULT '0' COMMENT '用户登陆次数',
  `userRole` varchar(20) NOT NULL COMMENT '用户角色',
  `userDesc` varchar(20) DEFAULT NULL COMMENT '角色描述',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1003 DEFAULT CHARSET=utf8 COMMENT='用户信息表';

-- ----------------------------
-- Records of tbl_user
-- ----------------------------
INSERT INTO `tbl_user` VALUES ('1001', '创始人', 'root', null, '1510707276', '2017-11-15 08:54:36', '0', '超级管理员', '拥有最高的权限');
INSERT INTO `tbl_user` VALUES ('1002', '设计部', '123', '1', null, '2017-12-24 10:57:21', '0', '', null);

-- ----------------------------
-- Table structure for tbl_website_seo
-- ----------------------------
DROP TABLE IF EXISTS `tbl_website_seo`;
CREATE TABLE `tbl_website_seo` (
  `id` int(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(50) DEFAULT NULL COMMENT '网站名称',
  `url` varchar(30) DEFAULT NULL COMMENT '网站网址',
  `desc` text COMMENT '网站描述',
  `keywords` text COMMENT '网站关键词',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='网站信息表';

-- ----------------------------
-- Records of tbl_website_seo
-- ----------------------------
INSERT INTO `tbl_website_seo` VALUES ('1', '盛腾家装工厂店,让装修省钱省心省力,工厂化工厂价装修,比传统装修省一半。', 'www.0551shengteng.com', '盛腾家装合肥工厂店是全国第九家公司，首创第五代买家模式,合肥大全包装修装饰公司！预算=决算！包含全房人工、基材、主材、家具、家电，全房灯饰窗帘，拎包即可入住！', '盛腾||家居装饰|装修公司|合肥盛腾家装|合肥装修|装修知识|装修技巧|合肥家装公司|安徽家装公司|盛腾家装怎么样|家装公司|房子装修|新房装修|好看装修|效果图|装修样板');
